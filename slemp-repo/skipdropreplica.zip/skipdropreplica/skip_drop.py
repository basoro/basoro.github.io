import time
import json
import pymysql

# Load config dari config.json
with open("/var/www/panel/data/config.json", "r") as f:
    config = json.load(f)

MYSQL_CONFIG = {
    "host": config["mysql"]["host"],
    "user": config["mysql"]["user"],
    "password": config["mysql"]["password"],
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor
}

def skip_drop_events():
    conn = pymysql.connect(**MYSQL_CONFIG)
    cursor = conn.cursor()
    cursor.execute("SHOW SLAVE STATUS")
    status = cursor.fetchone()
    if status and status.get("Last_SQL_Error") and "DROP" in status["Last_SQL_Error"].upper():
        print(f"[SKIP] DROP event terdeteksi: {status['Last_SQL_Error']}")
        cursor.execute("SET GLOBAL SQL_SLAVE_SKIP_COUNTER = 1")
        cursor.execute("START SLAVE SQL_THREAD")
        conn.commit()
    cursor.close()
    conn.close()

if __name__ == "__main__":
    while True:
        skip_drop_events()
        time.sleep(1)  # cek tiap detik
