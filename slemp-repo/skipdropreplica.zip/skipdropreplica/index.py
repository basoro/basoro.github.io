#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import psutil
import signal
import pymysql  
from flask import request, jsonify

class SkipDropReplicaPlugin:
    def __init__(self):
        self.name = "Skip Drop Replica" 
        self.version = "1.0.0"
    
    def action(self):
        """Menambahkan konfigurasi supervisor dan menjalankan perintah yang diperlukan"""
        try:
            # Konfigurasi supervisor yang akan ditambahkan
            supervisor_config = """
[program:skip_drop]
command=/usr/bin/python3 /var/www/panel/plugins/skipdropreplica/skip_drop.py
autostart=true
autorestart=true
stderr_logfile=/var/log/skip_drop.err.log
stdout_logfile=/var/log/skip_drop.out.log
"""
            
            # Path file supervisor
            supervisor_file = "/etc/supervisor/conf.d/supervisord.conf"
            
            # Baca file supervisor yang ada
            if os.path.exists(supervisor_file):
                with open(supervisor_file, 'r') as f:
                    existing_content = f.read()
                
                # Cek apakah konfigurasi skip_drop sudah ada
                if "[program:skip_drop]" not in existing_content:
                    # Tambahkan konfigurasi baru
                    with open(supervisor_file, 'a') as f:
                        f.write(supervisor_config)
                    
                    # Jalankan perintah supervisor
                    os.system("supervisorctl reread")
                    os.system("supervisorctl update")
                    os.system("supervisorctl start skip_drop")
                    
                    return {'success': True, 'message': 'Konfigurasi supervisor berhasil ditambahkan dan skip_drop service telah dimulai'}
                else:
                    return {'success': True, 'message': 'Konfigurasi skip_drop sudah ada di supervisor'}
            else:
                return {'success': False, 'message': 'File supervisor tidak ditemukan'}
                
        except Exception as e:
            return {'success': False, 'message': f'Error: {str(e)}'}
    
    def start_service(self):
        """Memulai service skip_drop"""
        try:
            result = os.system("supervisorctl start skip_drop")
            if result == 0:
                return {'success': True, 'message': 'Skip drop service berhasil dimulai'}
            else:
                return {'success': False, 'message': 'Gagal memulai skip drop service'}
        except Exception as e:
            return {'success': False, 'message': f'Error: {str(e)}'}
    
    def stop_service(self):
        """Menghentikan service skip_drop"""
        try:
            result = os.system("supervisorctl stop skip_drop")
            if result == 0:
                return {'success': True, 'message': 'Skip drop service berhasil dihentikan'}
            else:
                return {'success': False, 'message': 'Gagal menghentikan skip drop service'}
        except Exception as e:
            return {'success': False, 'message': f'Error: {str(e)}'}
    
    def restart_service(self):
        """Restart service skip_drop"""
        try:
            result = os.system("supervisorctl restart skip_drop")
            if result == 0:
                return {'success': True, 'message': 'Skip drop service berhasil direstart'}
            else:
                return {'success': False, 'message': 'Gagal merestart skip drop service'}
        except Exception as e:
            return {'success': False, 'message': f'Error: {str(e)}'}
    
    def get_status(self):
        """Mendapatkan status service dan konfigurasi"""
        try:
            # Cek status supervisor
            supervisor_configured = os.path.exists("/etc/supervisor/conf.d/supervisord.conf")
            if supervisor_configured:
                with open("/etc/supervisor/conf.d/supervisord.conf", 'r') as f:
                    content = f.read()
                    supervisor_configured = "[program:skip_drop]" in content
            
            # Cek status service
            service_running = False
            try:
                result = os.popen("supervisorctl status skip_drop").read()
                service_running = "RUNNING" in result
            except:
                service_running = False
            
            # Baca log file untuk events skipped
            events_skipped = 0
            logs = []
            try:
                if os.path.exists("/var/log/skip_drop.out.log"):
                    with open("/var/log/skip_drop.out.log", 'r') as f:
                        log_lines = f.readlines()[-20:]  # Ambil 20 baris terakhir
                        logs = [line.strip() for line in log_lines if line.strip()]
                        # Hitung events yang di-skip
                        events_skipped = sum(1 for line in logs if "[SKIP]" in line)
            except:
                pass
            
            return {
                'success': True,
                'data': {
                    'supervisor_configured': supervisor_configured,
                    'service_running': service_running,
                    'events_skipped': events_skipped,
                    'logs': logs
                }
            }
        except Exception as e:
            return {'success': False, 'message': f'Error: {str(e)}'}
    
    def skip_drop_replica(self):
        """Fungsi utama untuk skip drop replica - compatibility dengan action lama"""
        return self.get_status()
            
# Instance plugin
plugin = SkipDropReplicaPlugin()

def main():
    """Fungsi utama untuk menangani request"""
    try:
        # Get action from form data (set by app.py based on endpoint)
        action = request.form.get('action', '')
        
        if action == 'skip_drop_replica':
            return jsonify(plugin.skip_drop_replica())
        elif action == 'setup_supervisor':
            return jsonify(plugin.action())
        elif action == 'start_service':
            return jsonify(plugin.start_service())
        elif action == 'stop_service':
            return jsonify(plugin.stop_service())
        elif action == 'restart_service':
            return jsonify(plugin.restart_service())
        elif action == 'get_status':
            return jsonify(plugin.get_status())
                
        else:
            return jsonify({'success': False, 'message': f'Action tidak dikenali: {action}'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

if __name__ == '__main__':
    main()