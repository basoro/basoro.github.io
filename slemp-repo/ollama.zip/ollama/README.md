# Ollama Manager Plugin

Plugin untuk mengelola Ollama models dan konfigurasi melalui SLEMP Panel.

## Fitur

- **Auto Installation**: Instalasi otomatis Ollama untuk sistem Linux dengan dialog konfirmasi
- **Real-time Installation Progress**: Progress bar dan status real-time selama proses instalasi
- **Status Monitoring**: Monitoring status service Ollama secara real-time
- **Model Management**: Download, list, dan hapus model AI
- **Chat Interface**: Interface chat sederhana untuk berinteraksi dengan model
- **Configuration**: Pengaturan host dan port Ollama
- **Real-time Updates**: Update status dan informasi secara real-time

## Instalasi

### Persyaratan
- Python 3.7+
- Akses internet untuk download Ollama dan model
- Sistem operasi Linux (untuk instalasi otomatis)

### Langkah Instalasi

#### Instalasi Otomatis (Linux)

1. Buka plugin Ollama di SLEMP
2. Jika Ollama belum terinstall, akan muncul peringatan dengan tombol "Install Ollama"
3. Klik tombol "Install Ollama" untuk membuka dialog konfirmasi
4. Pada dialog konfirmasi, klik "Install" untuk memulai proses instalasi
5. Monitor progress instalasi secara real-time melalui progress bar dan status message
6. Tunggu hingga instalasi selesai (service akan otomatis dijalankan)
7. Dialog akan tertutup otomatis dan status akan diperbarui

#### Instalasi Manual (macOS/Windows)

1. Klik tombol "Install Ollama" (akan muncul dialog dengan instruksi manual)
2. Download Ollama dari [https://ollama.com/download](https://ollama.com/download)
3. Install sesuai petunjuk untuk sistem operasi Anda
4. Jalankan Ollama service
5. Refresh status di plugin SLEMP

#### Instalasi Manual
1. **Install Ollama**:
   ```bash
   # Linux
   curl -fsSL https://ollama.com/install.sh | sh
   
   # macOS - Download dari https://ollama.com/download
   ```

2. **Start Ollama Service**:
   ```bash
   ollama serve
   ```

3. **Akses Plugin**: Buka SLEMP Panel dan navigasi ke plugin Ollama

## Menjalankan Ollama

```bash
# Start Ollama service
ollama serve

# Pull model (contoh)
ollama pull llama2
ollama pull codellama
```

## Penggunaan Plugin

1. **Status Check**: Plugin akan otomatis mengecek status Ollama service
2. **Pull Model**: Gunakan tombol "Pull New Model" untuk download model baru
3. **Test Model**: Klik "Test" pada model untuk mencoba dengan prompt default
4. **Chat Interface**: Pilih model dan masukkan prompt untuk generate response
5. **Delete Model**: Hapus model yang tidak diperlukan

## Model yang Tersedia

Beberapa model populer yang bisa di-pull:

- `llama2` - Model general purpose
- `codellama` - Model untuk coding
- `mistral` - Model yang efisien
- `neural-chat` - Model untuk conversation
- `starcode` - Model untuk code generation

## API Endpoints

- `GET /api/plugins/ollama/status` - Cek status instalasi dan service Ollama
- `POST /api/plugins/ollama/install` - Install Ollama secara otomatis
- `GET /api/plugins/ollama/models` - List model yang terinstall
- `POST /api/plugins/ollama/models` - Pull model baru
- `DELETE /api/plugins/ollama/models` - Hapus model
- `POST /api/plugins/ollama/generate` - Generate response dari model
- `GET /api/plugins/ollama/config` - Get konfigurasi
- `POST /api/plugins/ollama/config` - Update konfigurasi

## Troubleshooting

### Service tidak berjalan
```bash
# Cek status
ps aux | grep ollama

# Start service
ollama serve
```

### API tidak tersedia
```bash
# Cek port
netstat -tlnp | grep 11434

# Test API
curl http://localhost:11434/api/tags
```

### Model tidak bisa di-pull
```bash
# Cek koneksi internet
ping ollama.ai

# Pull manual via CLI
ollama pull model_name
```

## Konfigurasi Environment

Variabel environment yang bisa dikonfigurasi:

- `OLLAMA_HOST` - Host Ollama (default: localhost)
- `OLLAMA_PORT` - Port Ollama (default: 11434)
- `OLLAMA_MODELS` - Path model directory
- `OLLAMA_KEEP_ALIVE` - Keep alive duration
- `OLLAMA_NUM_PARALLEL` - Parallel requests

## Lisensi

Plugin ini dikembangkan oleh SLEMP Team dan menggunakan lisensi yang sama dengan SLEMP Panel.