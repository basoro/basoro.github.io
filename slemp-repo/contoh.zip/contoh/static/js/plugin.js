/**
 * Plugin Contoh - JavaScript Functions
 * SLEMP Plugin System
 */

// Plugin namespace
const PluginContoh = {
    // Plugin configuration
    config: {
        name: 'contoh',
        version: '1.0.0',
        debug: false
    },
    
    // Initialize plugin
    init: function() {
        console.log(`Plugin ${this.config.name} v${this.config.version} initialized`);
        this.bindEvents();
        this.loadSettings();
        this.showWelcomeMessage();
    },
    
    // Bind event listeners
    bindEvents: function() {
        // Form submission
        const forms = document.querySelectorAll('.plugin-form');
        forms.forEach(form => {
            form.addEventListener('submit', this.handleFormSubmit.bind(this));
        });
        
        // Button clicks
        const buttons = document.querySelectorAll('.plugin-btn');
        buttons.forEach(button => {
            button.addEventListener('click', this.handleButtonClick.bind(this));
        });
        
        // Input changes
        const inputs = document.querySelectorAll('.plugin-input');
        inputs.forEach(input => {
            input.addEventListener('change', this.handleInputChange.bind(this));
        });
    },
    
    // Handle form submission
    handleFormSubmit: function(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        this.log('Form submitted:', data);
        this.showNotification('Form berhasil disubmit!', 'success');
    },
    
    // Handle button clicks
    handleButtonClick: function(event) {
        const button = event.target;
        const action = button.dataset.action;
        
        if (action) {
            this.executeAction(action, button);
        }
    },
    
    // Handle input changes
    handleInputChange: function(event) {
        const input = event.target;
        const value = input.value;
        
        this.log('Input changed:', { name: input.name, value: value });
        this.validateInput(input);
    },
    
    // Execute plugin actions
    executeAction: function(action, element) {
        this.log('Executing action:', action);
        
        switch (action) {
            case 'test':
                this.testFunction();
                break;
            case 'save':
                this.saveSettings();
                break;
            case 'reset':
                this.resetSettings();
                break;
            case 'export':
                this.exportData();
                break;
            case 'import':
                this.importData();
                break;
            default:
                this.showNotification(`Aksi '${action}' tidak dikenali`, 'warning');
        }
    },
    
    // Test function
    testFunction: function() {
        this.showNotification('Test function executed!', 'info');
        
        // Simulate async operation
        this.showLoading('Testing...');
        setTimeout(() => {
            this.hideLoading();
            this.showNotification('Test completed successfully!', 'success');
        }, 2000);
    },
    
    // Save settings
    saveSettings: function() {
        const settings = this.getFormData('.settings-form');
        localStorage.setItem('plugin_contoh_settings', JSON.stringify(settings));
        this.showNotification('Pengaturan berhasil disimpan!', 'success');
    },
    
    // Reset settings
    resetSettings: function() {
        if (confirm('Apakah Anda yakin ingin mereset pengaturan?')) {
            localStorage.removeItem('plugin_contoh_settings');
            this.loadDefaultSettings();
            this.showNotification('Pengaturan berhasil direset!', 'info');
        }
    },
    
    // Load settings
    loadSettings: function() {
        const saved = localStorage.getItem('plugin_contoh_settings');
        if (saved) {
            const settings = JSON.parse(saved);
            this.applySettings(settings);
        } else {
            this.loadDefaultSettings();
        }
    },
    
    // Load default settings
    loadDefaultSettings: function() {
        const defaults = {
            theme: 'default',
            language: 'id',
            notifications: true,
            debug: false
        };
        this.applySettings(defaults);
    },
    
    // Apply settings to form
    applySettings: function(settings) {
        Object.keys(settings).forEach(key => {
            const input = document.querySelector(`[name="${key}"]`);
            if (input) {
                if (input.type === 'checkbox') {
                    input.checked = settings[key];
                } else {
                    input.value = settings[key];
                }
            }
        });
    },
    
    // Export data
    exportData: function() {
        const data = {
            settings: JSON.parse(localStorage.getItem('plugin_contoh_settings') || '{}'),
            timestamp: new Date().toISOString(),
            version: this.config.version
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `plugin-contoh-export-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showNotification('Data berhasil diekspor!', 'success');
    },
    
    // Import data
    importData: function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = (event) => {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const data = JSON.parse(e.target.result);
                        if (data.settings) {
                            localStorage.setItem('plugin_contoh_settings', JSON.stringify(data.settings));
                            this.loadSettings();
                            this.showNotification('Data berhasil diimpor!', 'success');
                        } else {
                            this.showNotification('Format file tidak valid!', 'error');
                        }
                    } catch (error) {
                        this.showNotification('Error parsing file!', 'error');
                    }
                };
                reader.readAsText(file);
            }
        };
        input.click();
    },
    
    // Get form data
    getFormData: function(selector) {
        const form = document.querySelector(selector);
        if (!form) return {};
        
        const formData = new FormData(form);
        return Object.fromEntries(formData.entries());
    },
    
    // Validate input
    validateInput: function(input) {
        const value = input.value;
        const type = input.type;
        let isValid = true;
        let message = '';
        
        // Basic validation
        if (input.required && !value.trim()) {
            isValid = false;
            message = 'Field ini wajib diisi';
        } else if (type === 'email' && value && !this.isValidEmail(value)) {
            isValid = false;
            message = 'Format email tidak valid';
        } else if (type === 'url' && value && !this.isValidUrl(value)) {
            isValid = false;
            message = 'Format URL tidak valid';
        }
        
        // Update UI
        this.updateInputValidation(input, isValid, message);
        
        return isValid;
    },
    
    // Update input validation UI
    updateInputValidation: function(input, isValid, message) {
        const container = input.closest('.form-group') || input.parentElement;
        const errorElement = container.querySelector('.error-message');
        
        // Remove existing error
        if (errorElement) {
            errorElement.remove();
        }
        
        // Update input styling
        input.classList.remove('border-red-500', 'border-green-500');
        input.classList.add(isValid ? 'border-green-500' : 'border-red-500');
        
        // Add error message
        if (!isValid && message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message text-red-500 text-sm mt-1';
            errorDiv.textContent = message;
            container.appendChild(errorDiv);
        }
    },
    
    // Show notification
    showNotification: function(message, type = 'info', duration = 3000) {
        const colors = {
            info: 'bg-blue-100 border-blue-500 text-blue-700',
            success: 'bg-green-100 border-green-500 text-green-700',
            warning: 'bg-yellow-100 border-yellow-500 text-yellow-700',
            error: 'bg-red-100 border-red-500 text-red-700'
        };
        
        const icons = {
            info: '📊',
            success: '✅',
            warning: '⚠️',
            error: '❌'
        };
        
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 border-l-4 rounded-lg shadow-lg z-50 ${colors[type]} max-w-sm`;
        notification.innerHTML = `
            <div class="flex justify-between items-center">
                <span>${icons[type]} ${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-lg hover:opacity-70">&times;</button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, duration);
    },
    
    // Show loading
    showLoading: function(message = 'Loading...') {
        const loading = document.createElement('div');
        loading.id = 'plugin-loading';
        loading.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        loading.innerHTML = `
            <div class="bg-white rounded-lg p-6 flex items-center space-x-3">
                <div class="spinner"></div>
                <span>${message}</span>
            </div>
        `;
        document.body.appendChild(loading);
    },
    
    // Hide loading
    hideLoading: function() {
        const loading = document.getElementById('plugin-loading');
        if (loading) {
            loading.remove();
        }
    },
    
    // Show welcome message
    showWelcomeMessage: function() {
        setTimeout(() => {
            this.showNotification('Plugin Contoh berhasil dimuat!', 'info');
        }, 500);
    },
    
    // Utility functions
    isValidEmail: function(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },
    
    isValidUrl: function(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    },
    
    // Debug logging
    log: function(...args) {
        if (this.config.debug) {
            console.log('[Plugin Contoh]', ...args);
        }
    }
};

// Initialize plugin when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    PluginContoh.init();
});

// Export for global access
window.PluginContoh = PluginContoh;