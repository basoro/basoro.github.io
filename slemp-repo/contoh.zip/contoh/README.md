# Plugin Contoh

🔌 Plugin contoh untuk sistem SLEMP yang mendemonstrasikan cara membuat plugin sederhana.

## Deskripsi

Plugin ini adalah template dasar yang dapat digunakan sebagai starting point untuk mengembangkan plugin SLEMP. Plugin ini menampilkan berbagai komponen UI dan interaksi yang umum digunakan dalam plugin.

## Fitur

- ✅ Interface responsif dengan Tailwind CSS
- ✅ Komponen UI interaktif
- ✅ Sistem notifikasi
- ✅ Form input dan validasi
- ✅ Konfigurasi plugin
- ✅ Dokumentasi lengkap

## Struktur File

```
plugins/contoh/
├── index.html          # Interface utama plugin
├── plugin.json         # Konfigurasi dan metadata plugin
├── README.md          # Dokumentasi plugin
└── static/            # File statis (CSS, JS, gambar)
    ├── css/
    ├── js/
    └── images/
```

## Instalasi

1. Pastikan folder `plugins/contoh/` sudah ada di direktori SLEMP
2. Plugin akan otomatis terdeteksi oleh sistem
3. Akses plugin melalui URL: `/plugins/contoh`

## Penggunaan

### Mengakses Plugin

```
http://localhost:5000/plugins/contoh
```

### Konfigurasi

Edit file `plugin.json` untuk mengubah konfigurasi plugin:

```json
{
    "name": "contoh",
    "display_name": "Plugin Contoh",
    "version": "1.0.0",
    "enabled": true
}
```

## Pengembangan

### Membuat Plugin Baru

1. Salin folder `plugins/contoh/` ke `plugins/nama-plugin-baru/`
2. Edit `plugin.json` dengan informasi plugin baru
3. Modifikasi `index.html` sesuai kebutuhan
4. Tambahkan file statis di folder `static/` jika diperlukan

### Struktur HTML

Plugin menggunakan struktur HTML standar dengan Tailwind CSS:

```html
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Plugin Name - SLEMP</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <!-- Konten plugin -->
</body>
</html>
```

### JavaScript API

Plugin dapat menggunakan JavaScript untuk interaksi:

```javascript
// Menampilkan notifikasi
function showAlert(type) {
    // Implementation
}

// Memproses data
function processDemo() {
    // Implementation
}
```

## API Endpoints

| Method | Endpoint | Deskripsi |
|--------|----------|----------|
| GET | `/plugins/contoh` | Halaman utama plugin |
| GET | `/api/plugins/contoh/interface` | Interface API plugin |
| GET | `/plugins/contoh/static/*` | File statis plugin |

## Kustomisasi

### Tema

Ubah warna dan styling dengan memodifikasi CSS:

```css
.gradient-bg {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
```

### Komponen

Tambahkan komponen baru dengan struktur HTML yang konsisten:

```html
<div class="bg-white rounded-lg shadow-md p-6">
    <h2 class="text-xl font-semibold mb-4 text-gray-800">Judul</h2>
    <!-- Konten -->
</div>
```

## Troubleshooting

### Plugin Tidak Muncul

1. Periksa struktur folder plugin
2. Pastikan file `plugin.json` valid
3. Cek log SLEMP untuk error

### Error 404

1. Pastikan route `/plugins/<plugin_name>` sudah ditambahkan di `app.py`
2. Restart aplikasi SLEMP

### JavaScript Error

1. Buka Developer Tools di browser
2. Periksa Console untuk error JavaScript
3. Pastikan semua dependency sudah dimuat

## Kontribusi

Untuk berkontribusi pada plugin ini:

1. Fork repository
2. Buat branch fitur baru
3. Commit perubahan
4. Submit pull request

## Lisensi

MIT License - lihat file LICENSE untuk detail lengkap.

## Changelog

### v1.0.0 (2024-01-01)
- ✅ Initial release
- ✅ Basic plugin structure
- ✅ Demo interface
- ✅ Documentation

## Support

Jika mengalami masalah atau memiliki pertanyaan:

- 📧 Email: team@slemp.com
- 🐛 Issues: [GitHub Issues](https://github.com/slemp/slemp/issues)
- 📖 Dokumentasi: [SLEMP Docs](https://docs.slemp.com)

---

**SLEMP Team** © 2024