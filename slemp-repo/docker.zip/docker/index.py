#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Docker Manager Plugin for SLEMP
Manage Docker containers, images, networks, and volumes
"""

import subprocess
import json
import os
import sys
import time
from datetime import datetime

# Import Flask components when available
try:
    from flask import request, jsonify
    # Import from parent app
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from app import logger
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False
    logger = None

def run_command(cmd, timeout=30):
    """Execute shell command and return result"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return {
            'success': result.returncode == 0,
            'output': result.stdout.strip(),
            'error': result.stderr.strip(),
            'code': result.returncode
        }
    except subprocess.TimeoutExpired:
        return {
            'success': False,
            'output': '',
            'error': f'Command timed out after {timeout} seconds',
            'code': -1
        }
    except Exception as e:
        return {
            'success': False,
            'output': '',
            'error': str(e),
            'code': -1
        }

def run_command_with_progress(cmd, timeout=300):
    """Run a command with longer timeout for installation processes"""
    return run_command(cmd, timeout)

def check_docker_status():
    """Check if Docker is installed and running"""
    # Check if Docker is installed
    docker_check = run_command('which docker')
    if not docker_check['success']:
        return {
            'installed': False,
            'running': False,
            'version': None,
            'message': 'Docker is not installed'
        }
    
    # Check Docker version
    version_result = run_command('docker --version')
    version = version_result['output'] if version_result['success'] else 'Unknown'
    
    # Check if Docker daemon is running
    status_result = run_command('docker info')
    running = status_result['success']
    
    return {
        'installed': True,
        'running': running,
        'version': version,
        'message': 'Docker is running' if running else 'Docker daemon is not running'
    }

def get_containers():
    """Get list of all Docker containers"""
    cmd = 'docker ps -a --format "table {{.ID}}\t{{.Image}}\t{{.Command}}\t{{.CreatedAt}}\t{{.Status}}\t{{.Ports}}\t{{.Names}}" --no-trunc'
    result = run_command(cmd)
    
    if not result['success']:
        return {'success': False, 'error': result['error'], 'containers': []}
    
    containers = []
    lines = result['output'].split('\n')
    
    # Debug: log raw output
    if logger:
        logger.info(f"Docker ps output: {repr(result['output'])}")
        logger.info(f"Number of lines: {len(lines)}")
        for i, line in enumerate(lines):
            logger.info(f"Line {i}: {repr(line)}")
    
    if len(lines) > 1:  # Skip header
        for i, line in enumerate(lines[1:], 1):
            if line.strip():
                # Split by tab, but handle cases where tabs might be spaces
                parts = line.split('\t')
                if len(parts) < 7:
                    # Try splitting by multiple spaces if tab split doesn't work
                    import re
                    parts = re.split(r'\s{2,}', line.strip())
                
                if logger:
                    logger.info(f"Line {i} parts ({len(parts)}): {parts}")
                
                if len(parts) >= 7:
                    containers.append({
                        'id': parts[0][:12],
                        'image': parts[1],
                        'command': parts[2][:50] + '...' if len(parts[2]) > 50 else parts[2],
                        'created': parts[3],
                        'status': parts[4],
                        'ports': parts[5],
                        'name': parts[6]
                    })
                elif len(parts) >= 6:
                    # Handle case where ports might be empty
                    containers.append({
                        'id': parts[0][:12],
                        'image': parts[1],
                        'command': parts[2][:50] + '...' if len(parts[2]) > 50 else parts[2],
                        'created': parts[3],
                        'status': parts[4],
                        'ports': '',
                        'name': parts[5]
                    })
    
    if logger:
        logger.info(f"Parsed {len(containers)} containers")
    
    return {'success': True, 'containers': containers}

def get_images():
    """Get list of Docker images"""
    cmd = 'docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.ID}}\t{{.CreatedAt}}\t{{.Size}}" --no-trunc'
    result = run_command(cmd)
    
    if not result['success']:
        return {'success': False, 'error': result['error'], 'images': []}
    
    images = []
    lines = result['output'].split('\n')
    
    # Debug: log raw output
    if logger:
        logger.info(f"Docker images output: {repr(result['output'])}")
        logger.info(f"Number of lines: {len(lines)}")
        for i, line in enumerate(lines):
            logger.info(f"Line {i}: {repr(line)}")
    
    if len(lines) > 1:  # Skip header
        for i, line in enumerate(lines[1:], 1):
            if line.strip():
                # Split by tab, but handle cases where tabs might be spaces
                parts = line.split('\t')
                if len(parts) < 5:
                    # Try splitting by multiple spaces if tab split doesn't work
                    import re
                    parts = re.split(r'\s{2,}', line.strip())
                
                if logger:
                    logger.info(f"Line {i} parts ({len(parts)}): {parts}")
                
                if len(parts) >= 5:
                    images.append({
                        'repository': parts[0],
                        'tag': parts[1],
                        'id': parts[2][:12],
                        'created': parts[3],
                        'size': parts[4]
                    })
    
    if logger:
        logger.info(f"Parsed {len(images)} images")
    
    return {'success': True, 'images': images}

def get_networks():
    """Get list of Docker networks"""
    cmd = 'docker network ls --format "table {{.ID}}\t{{.Name}}\t{{.Driver}}\t{{.Scope}}" --no-trunc'
    result = run_command(cmd)
    
    if not result['success']:
        return {'success': False, 'error': result['error'], 'networks': []}
    
    networks = []
    lines = result['output'].split('\n')
    
    # Debug: log raw output
    if logger:
        logger.info(f"Docker networks output: {repr(result['output'])}")
        logger.info(f"Number of lines: {len(lines)}")
    
    if len(lines) > 1:  # Skip header
        for i, line in enumerate(lines[1:], 1):
            if line.strip():
                # Split by tab, but handle cases where tabs might be spaces
                parts = line.split('\t')
                if len(parts) < 4:
                    # Try splitting by multiple spaces if tab split doesn't work
                    import re
                    parts = re.split(r'\s{2,}', line.strip())
                
                if logger:
                    logger.info(f"Line {i} parts ({len(parts)}): {parts}")
                
                if len(parts) >= 4:
                    networks.append({
                        'id': parts[0][:12],
                        'name': parts[1],
                        'driver': parts[2],
                        'scope': parts[3]
                    })
    
    if logger:
        logger.info(f"Parsed {len(networks)} networks")
    
    return {'success': True, 'networks': networks}

def get_volumes():
    """Get list of Docker volumes"""
    cmd = 'docker volume ls --format "table {{.Driver}}\t{{.Name}}"'
    result = run_command(cmd)
    
    if not result['success']:
        return {'success': False, 'error': result['error'], 'volumes': []}
    
    volumes = []
    lines = result['output'].split('\n')
    
    # Debug: log raw output
    if logger:
        logger.info(f"Docker volumes output: {repr(result['output'])}")
        logger.info(f"Number of lines: {len(lines)}")
    
    if len(lines) > 1:  # Skip header
        for i, line in enumerate(lines[1:], 1):
            if line.strip():
                # Split by tab, but handle cases where tabs might be spaces
                parts = line.split('\t')
                if len(parts) < 2:
                    # Try splitting by multiple spaces if tab split doesn't work
                    import re
                    parts = re.split(r'\s{2,}', line.strip())
                
                if logger:
                    logger.info(f"Line {i} parts ({len(parts)}): {parts}")
                
                if len(parts) >= 2:
                    volumes.append({
                        'driver': parts[0],
                        'name': parts[1]
                    })
    
    if logger:
        logger.info(f"Parsed {len(volumes)} volumes")
    
    return {'success': True, 'volumes': volumes}

def container_action(container_id, action):
    """Perform action on container (start, stop, restart, remove)"""
    valid_actions = ['start', 'stop', 'restart', 'remove', 'pause', 'unpause']
    
    if action not in valid_actions:
        return {'success': False, 'error': f'Invalid action: {action}'}
    
    if action == 'remove':
        cmd = f'docker rm -f {container_id}'
    else:
        cmd = f'docker {action} {container_id}'
    
    result = run_command(cmd)
    
    return {
        'success': result['success'],
        'message': f'Container {action} successful' if result['success'] else result['error']
    }

def image_action(image_id, action):
    """Perform action on image (remove)"""
    if action == 'remove':
        cmd = f'docker rmi -f {image_id}'
        result = run_command(cmd)
        
        return {
            'success': result['success'],
            'message': 'Image removed successfully' if result['success'] else result['error']
        }
    
    return {'success': False, 'error': f'Invalid action: {action}'}

def network_action(network_id, action):
    """Perform action on network (remove)"""
    if action == 'remove':
        cmd = f'docker network rm {network_id}'
        result = run_command(cmd)
        
        return {
            'success': result['success'],
            'message': 'Network removed successfully' if result['success'] else result['error']
        }
    
    return {'success': False, 'error': f'Invalid action: {action}'}

def volume_action(volume_name, action):
    """Perform action on volume (remove)"""
    if action == 'remove':
        cmd = f'docker volume rm {volume_name}'
        result = run_command(cmd)
        
        return {
            'success': result['success'],
            'message': 'Volume removed successfully' if result['success'] else result['error']
        }
    
    return {'success': False, 'error': f'Invalid action: {action}'}

def pull_image(image_name):
    """Pull Docker image"""
    cmd = f'docker pull {image_name}'
    result = run_command(cmd)
    
    return {
        'success': result['success'],
        'message': f'Image {image_name} pulled successfully' if result['success'] else result['error']
    }

def create_container(image, name=None, ports=None, volumes=None, env_vars=None):
    """Create new Docker container"""
    cmd = 'docker run -d'
    
    if name:
        cmd += f' --name {name}'
    
    if ports:
        for port_mapping in ports:
            cmd += f' -p {port_mapping}'
    
    if volumes:
        for volume_mapping in volumes:
            cmd += f' -v {volume_mapping}'
    
    if env_vars:
        for env_var in env_vars:
            cmd += f' -e {env_var}'
    
    cmd += f' {image}'
    
    result = run_command(cmd)
    
    return {
        'success': result['success'],
        'message': 'Container created successfully' if result['success'] else result['error'],
        'container_id': result['output'][:12] if result['success'] else None
    }

def get_container_logs(container_id, lines=100):
    """Get container logs"""
    cmd = f'docker logs --tail {lines} {container_id}'
    result = run_command(cmd)
    
    return {
        'success': result['success'],
        'logs': result['output'] if result['success'] else result['error']
    }

def get_system_info():
    """Get Docker system information"""
    info_result = run_command('docker system df')
    version_result = run_command('docker version --format json')
    
    system_info = {
        'disk_usage': info_result['output'] if info_result['success'] else 'Unable to get disk usage',
        'version_info': {}
    }
    
    if version_result['success']:
        try:
            version_data = json.loads(version_result['output'])
            system_info['version_info'] = version_data
        except json.JSONDecodeError:
            system_info['version_info'] = {'error': 'Unable to parse version info'}
    
    return system_info

def cleanup_system():
    """Clean up Docker system (remove unused containers, networks, images)"""
    cmd = 'docker system prune -f'
    result = run_command(cmd)
    
    return {
        'success': result['success'],
        'message': 'System cleanup completed' if result['success'] else result['error'],
        'details': result['output'] if result['success'] else result['error']
    }

def install_docker_package():
    """Install Docker package using apt-get for Ubuntu Linux"""
    try:
        # Check if Docker is already installed
        check_result = subprocess.run(['which', 'docker'], capture_output=True, text=True)
        if check_result.returncode == 0:
            return {'success': True, 'message': 'Docker is already installed'}
        
        # Update package list
        update_result = subprocess.run(['apt-get', 'update'], capture_output=True, text=True)
        if update_result.returncode != 0:
            return {'success': False, 'error': f'Failed to update package list: {update_result.stderr}'}
        
        # Install required packages
        prereq_result = subprocess.run([
            'apt-get', 'install', '-y', 
            'apt-transport-https', 'ca-certificates', 'curl', 'gnupg', 'lsb-release'
        ], capture_output=True, text=True)
        if prereq_result.returncode != 0:
            return {'success': False, 'error': f'Failed to install prerequisites: {prereq_result.stderr}'}
        
        # Create keyrings directory if it doesn't exist
        subprocess.run(['mkdir', '-p', '/etc/apt/keyrings'], capture_output=True, text=True)
        
        # Add Docker's official GPG key (Ubuntu 22.04 compatible method)
        key_result = subprocess.run([
            'curl', '-fsSL', 'https://download.docker.com/linux/ubuntu/gpg', 
            '-o', '/etc/apt/keyrings/docker.gpg'
        ], capture_output=True, text=True)
        if key_result.returncode != 0:
            return {'success': False, 'error': f'Failed to download Docker GPG key: {key_result.stderr}'}
        
        # Set proper permissions for the GPG key
        subprocess.run(['chmod', 'a+r', '/etc/apt/keyrings/docker.gpg'], capture_output=True, text=True)
        
        # Get Ubuntu codename
        codename_result = subprocess.run(['lsb_release', '-cs'], capture_output=True, text=True)
        if codename_result.returncode != 0:
            return {'success': False, 'error': 'Failed to get Ubuntu codename'}
        
        codename = codename_result.stdout.strip()
        
        # Add Docker repository (Ubuntu 22.04 compatible method)
        repo_line = f'deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu {codename} stable'
        
        with open('/etc/apt/sources.list.d/docker.list', 'w') as f:
            f.write(repo_line + '\n')
        
        # Update package list again
        update2_result = subprocess.run(['apt-get', 'update'], capture_output=True, text=True)
        if update2_result.returncode != 0:
            return {'success': False, 'error': f'Failed to update package list after adding repository: {update2_result.stderr}'}
        
        # Install Docker
        install_result = subprocess.run([
            'apt-get', 'install', '-y', 'docker-ce', 'docker-ce-cli', 'containerd.io', 'docker-buildx-plugin', 'docker-compose-plugin'
        ], capture_output=True, text=True)
        
        if install_result.returncode != 0:
            return {'success': False, 'error': f'Failed to install Docker: {install_result.stderr}'}
        
        # Start and enable Docker service using systemctl
        start_result = subprocess.run(['systemctl', 'start', 'docker'], capture_output=True, text=True)
        if start_result.returncode != 0:
            return {'success': False, 'error': f'Failed to start Docker service: {start_result.stderr}'}
        
        enable_result = subprocess.run(['systemctl', 'enable', 'docker'], capture_output=True, text=True)
        if enable_result.returncode != 0:
            return {'success': False, 'error': f'Failed to enable Docker service: {enable_result.stderr}'}
        
        # Verify Docker installation
        verify_result = subprocess.run(['docker', '--version'], capture_output=True, text=True)
        if verify_result.returncode != 0:
            return {'success': False, 'error': 'Docker installation verification failed'}
        
        return {'success': True, 'message': f'Docker installed and started successfully. Version: {verify_result.stdout.strip()}'}
            
    except Exception as e:
        return {'success': False, 'error': f'Error installing Docker: {str(e)}'}

# Docker installation function moved to install_docker_package()

# Docker plugin follows modular pattern - handlers managed through main() function

def install_with_socketio():
    """Handle Docker installation with SocketIO progress updates"""
    try:
        # Import SocketIO if available
        if FLASK_AVAILABLE:
            try:
                from flask import current_app
                socketio = current_app.extensions.get('socketio')
                
                if socketio:
                    import threading
                    import time
                    
                    def install_in_background():
                        try:
                            # Emit initial progress
                            socketio.emit('docker_install_progress', {
                                'step': 1,
                                'total': 3,
                                'status': 'Starting Docker installation...',
                                'percentage': 33
                            })
                            
                            socketio.emit('docker_install_output', {
                                'output': 'Starting Docker installation...',
                                'type': 'info'
                            })
                            
                            time.sleep(1)
                            
                            # Call the actual installation function
                            result = install_docker_package()
                            
                            if result.get('success'):
                                socketio.emit('docker_install_progress', {
                                    'step': 3,
                                    'total': 3,
                                    'status': 'Docker installation completed successfully',
                                    'percentage': 100
                                })
                                
                                socketio.emit('docker_install_output', {
                                    'output': 'Docker installation completed successfully',
                                    'type': 'success'
                                })
                                
                                socketio.emit('docker_install_complete', {
                                    'message': 'Docker has been installed successfully',
                                    'version': result.get('version', 'Unknown')
                                })
                            else:
                                socketio.emit('docker_install_error', {
                                    'message': result.get('error', 'Docker installation failed')
                                })
                                
                        except Exception as e:
                            socketio.emit('docker_install_error', {
                                'message': f'Docker installation failed: {str(e)}'
                            })
                    
                    # Start background thread
                    thread = threading.Thread(target=install_in_background)
                    thread.daemon = True
                    thread.start()
                    
                    return {'success': True, 'message': 'Installation started'}
                    
            except ImportError:
                pass
        
        # Fallback to regular installation
        return install_docker_package()
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

def main(data=None, **kwargs):
    """Main function to handle plugin actions"""
    try:
        # Handle different input formats
        if isinstance(data, dict):
            action = data.get('action')
            kwargs.update(data)
        else:
            action = data
        
        # Import Flask request if available (when called from Flask app)
        if FLASK_AVAILABLE:
            try:
                from flask import request, has_app_context
                # Only access request if we're in an app context
                if has_app_context():
                    # Get action from Flask request if not provided as parameter
                    if action is None:
                        # First try to get from form data (set by API route handler)
                        action = request.form.get('action')
                        # Then try JSON if form data is empty
                        if action is None and request.json:
                            action = request.json.get('action')
                    
                    # Get additional parameters from request
                    if not kwargs and request.method == 'POST':
                        if request.json:
                            kwargs.update(request.json)
                        else:
                            kwargs.update({
                                'container_id': request.form.get('container_id'),
                                'action_type': request.form.get('action_type'),
                                'image_id': request.form.get('image_id'),
                                'network_id': request.form.get('network_id'),
                                'volume_name': request.form.get('volume_name'),
                                'image_name': request.form.get('image_name'),
                                'image': request.form.get('image'),
                                'name': request.form.get('name'),
                                'ports': request.form.get('ports'),
                                'volumes': request.form.get('volumes'),
                                'env_vars': request.form.get('env_vars'),
                                'lines': int(request.form.get('lines', 100)) if request.form.get('lines') else 100
                            })
            except ImportError:
                # Running outside Flask context
                pass
        
        if action == 'status':
            result = check_docker_status()
        elif action == 'containers':
            result = get_containers()
        elif action == 'images':
            result = get_images()
        elif action == 'networks':
            result = get_networks()
        elif action == 'volumes':
            result = get_volumes()
        elif action == 'container_action':
            result = container_action(kwargs.get('container_id'), kwargs.get('action_type'))
        elif action == 'image_action':
            result = image_action(kwargs.get('image_id'), kwargs.get('action_type'))
        elif action == 'network_action':
            result = network_action(kwargs.get('network_id'), kwargs.get('action_type'))
        elif action == 'volume_action':
            result = volume_action(kwargs.get('volume_name'), kwargs.get('action_type'))
        elif action == 'pull_image':
            result = pull_image(kwargs.get('image_name'))
        elif action == 'create_container':
            result = create_container(
                kwargs.get('image'),
                kwargs.get('name'),
                kwargs.get('ports'),
                kwargs.get('volumes'),
                kwargs.get('env_vars')
            )
        elif action == 'container_logs':
            result = get_container_logs(kwargs.get('container_id'), kwargs.get('lines', 100))
        elif action == 'system_info':
            result = get_system_info()
        elif action == 'cleanup':
            result = cleanup_system()
        elif action == 'install':
            # Check if this is a SocketIO request
            if FLASK_AVAILABLE:
                try:
                    from flask import has_app_context, current_app
                    if has_app_context() and current_app.extensions.get('socketio'):
                        result = install_with_socketio()
                    else:
                        result = install_docker_package()
                except ImportError:
                    result = install_docker_package()
            else:
                result = install_docker_package()
        else:
            result = {'success': False, 'error': f'Unknown action: {action}'}
        
        # Return JSON response if Flask is available and we're in Flask context
        if FLASK_AVAILABLE:
            try:
                from flask import jsonify, has_app_context
                if has_app_context():
                    return jsonify(result)
            except ImportError:
                pass
        
        return result
            
    except Exception as e:
        error_result = {'success': False, 'error': f'Plugin error: {str(e)}'}
        if FLASK_AVAILABLE:
            try:
                from flask import jsonify, has_app_context
                if has_app_context():
                    return jsonify(error_result)
            except ImportError:
                pass
        
        return error_result

# Plugin follows modular pattern - no auto-registration

if __name__ == '__main__':
    if len(sys.argv) > 1:
        action = sys.argv[1]
        result = main(action)
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps({'success': False, 'error': 'No action specified'}, indent=2))