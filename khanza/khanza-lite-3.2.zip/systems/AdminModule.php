<?php

namespace Systems;

abstract class AdminModule extends BaseModule
{
    public function navigation()
    {
        return [];
    }
}
