<?php
return [
    'name'          =>  'Apotek Ralan',
    'description'   =>  'Pengelolaan data apotek rawat jalan.',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'shopping-cart',
];
