$('.gallery').lightbox();
