<?php
return [
    'name'          =>  'Tema Situs',
    'description'   =>  'Modul tampilan situs',
    'author'        =>  'Basoro.ID',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'paint-brush'
];
