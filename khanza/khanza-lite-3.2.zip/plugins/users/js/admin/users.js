$(document).ready(function(){
    $('.display').DataTable({
      "lengthChange": false,
      "scrollX": true
    });
});
