<?php
return [
    'name'          =>  'Kepegawaian',
    'description'   =>  'Pengelolaan data kepegawaian Khanza LITE.',
    'author'        =>  'Basoro',
    'version'       =>  '1.1',
    'compatibility' =>  '3.*',
    'icon'          =>  'group',
];
