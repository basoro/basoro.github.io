<?php
return [
    'name'          =>  'Dokter Ralan',
    'description'   =>  'Pengelolaan data pasien untuk dokter rawat jalan.',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'wheelchair',
];
