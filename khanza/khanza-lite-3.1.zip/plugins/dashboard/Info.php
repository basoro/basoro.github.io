<?php

return [
    'name'          =>  'Dashboard',
    'description'   =>  'Statistik, grafik dan akses modul.',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'home',
    'pages'         =>  ['Dashboard' => 'dashboard'],    
];
