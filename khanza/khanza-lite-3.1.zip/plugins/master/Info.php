<?php
return [
    'name'          =>  'Data Master',
    'description'   =>  'Pengelolaan data master Khanza LITE.',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'cubes',
];
