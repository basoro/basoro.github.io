<?php
return [
    'name'          =>  'Rawat Jalan',
    'description'   =>  'Pengelolaan data pasien rawat jalan.',
    'author'        =>  'Basoro',
    'version'       =>  '1.2',
    'compatibility' =>  '3.*',
    'icon'          =>  'wheelchair',
];
