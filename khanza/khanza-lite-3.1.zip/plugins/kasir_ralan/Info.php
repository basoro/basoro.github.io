<?php
return [
    'name'          =>  'Kasir Ralan',
    'description'   =>  'Pengelolaan data kasir rawat jalan.',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '3.*',
    'icon'          =>  'building-o',
];
