<?php
 include '../conf/conf.php';
?>



[url]http://<?php echo $db_hostname;?>/webapps/serverupdate/dataupdate/dataupdate.zip[/url]