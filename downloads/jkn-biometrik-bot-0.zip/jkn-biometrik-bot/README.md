## Instalasi

Sebelum memulai instalasi, buka **Windows Powershell** lalu jalankan perintah berikut:

```ps1
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted -Force;
```

Tujuannya untuk mengubah ExecutionPolicy supaya dapat menjalankan script instalasi.

Download dan extract Zip, klik kanan script `install.ps1` lalu pilih `Run with PowerShell`, ketik `R` untuk melanjutkan. Jika terdapat prompt terkait Execution Policy, ketik huruf `A` yakni `Yes to All` lalu tunggu hingga proses instalasi selesai. Jalankan perintah `node .\index.js` untuk mengaktikan bot biometrik. Server bot akan berjalan di port 3000 secara default dan seharusnya dapat di-akses melalui browser di alamat http://localhost:3000.