# =====================================================
# install.ps1 - Setup Node.js & buat autostart VBS
# =====================================================

# Config
$nodeVersion = "20.14.0"
$nodeLtsUrl64 = "https://nodejs.org/dist/v$nodeVersion/node-v$nodeVersion-x64.msi"
$nodeLtsUrl32 = "https://nodejs.org/dist/v$nodeVersion/node-v$nodeVersion-x86.msi"
$botFolder = "C:\jkn-biometrik-bot"

# =====================================================
# Cek folder aplikasi
# =====================================================
if (-not (Test-Path $botFolder)) {
    Write-Output "❌ Folder $botFolder tidak ditemukan. Pastikan sudah diekstrak di sana."
    exit 1
}

# =====================================================
# Tentukan arsitektur
# =====================================================
$is64Bit = [Environment]::Is64BitOperatingSystem
$nodeLtsUrl = if ($is64Bit) { $nodeLtsUrl64 } else { $nodeLtsUrl32 }

# =====================================================
# Refresh PATH env di PowerShell session
# =====================================================
function Refresh-Env-Vars {
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", [System.EnvironmentVariableTarget]::Machine)
}

# =====================================================
# Cek Node.js
# =====================================================
function Check-Nodejs {
    try {
        node -v > $null 2>&1
        return $true
    } catch {
        return $false
    }
}

# =====================================================
# Ambil versi Node
# =====================================================
function Get-NodejsVersion {
    $version = node -v 2>$null
    if ($version) {
        return $version.TrimStart("v")
    }
    return $null
}

# =====================================================
# Install Node.js
# =====================================================
function Install-Nodejs {
    $arch = if ($is64Bit) { 'x64' } else { 'x86' }
    $installerPath = "$env:TEMP\node-v$nodeVersion-$arch.msi"

    if (-Not (Test-Path $installerPath)) {
        Write-Output "⬇️ Downloading Node.js v$nodeVersion..."
        try {
            Invoke-WebRequest -Uri $nodeLtsUrl -OutFile $installerPath -ErrorAction Stop
        } catch {
            Write-Output "❌ Gagal download Node.js installer."
            exit 1
        }
    }

    Write-Output "⚙️ Installing Node.js v$nodeVersion..."
    Start-Process msiexec.exe -ArgumentList "/i", $installerPath, "/passive", "/norestart" -Wait
    Refresh-Env-Vars
}

# =====================================================
# Uninstall Node.js (jika mau upgrade)
# =====================================================
function Uninstall-Nodejs {
    Write-Output "🔄 Uninstalling existing Node.js..."
    $uninstall = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" `
                | Where-Object { $_.DisplayName -like "Node.js*" }

    if ($uninstall) {
        Start-Process "msiexec.exe" -ArgumentList "/x", $uninstall.UninstallString, "/passive", "/norestart" -Wait
    }
}

# =====================================================
# Proses utama Node.js
# =====================================================
if (Check-Nodejs) {
    $currentVersion = Get-NodejsVersion
    if ($currentVersion -lt $nodeVersion) {
        Write-Output "📌 Current Node.js version is $currentVersion. Upgrading to $nodeVersion."
        Uninstall-Nodejs
        Install-Nodejs
    } else {
        Write-Output "✅ Node.js is already at version $currentVersion."
    }
} else {
    Write-Output "🚀 Node.js not found. Installing v$nodeVersion."
    Install-Nodejs
}

# =====================================================
# Install dependencies
# =====================================================
Write-Output "📦 Installing production dependencies..."
Push-Location $botFolder
npm install --omit=dev
Pop-Location
Refresh-Env-Vars

# =====================================================
# Buat file start-bot.vbs di TEMP
# =====================================================
$vbsFilePath = "$env:TEMP\start-bot.vbs"
$vbsFileContent = @"
Set WshShell = CreateObject(""WScript.Shell"")
WshShell.CurrentDirectory = ""$botFolder""
WshShell.Run ""node index.js"", 0, False
"@

$vbsFileContent | Set-Content -Path $vbsFilePath -Encoding ASCII

# =====================================================
# Pindah ke folder startup
# =====================================================
$startupFolder = [System.Environment]::GetFolderPath('Startup')
Move-Item -Path $vbsFilePath -Destination "$startupFolder\start-bot.vbs" -Force

# =====================================================
# Selesai
# =====================================================
Write-Output ""
Write-Output "🎉 Setup completed!"
Write-Output "🚀 Bot akan otomatis jalan setiap Windows startup."
Read-Host -Prompt "Press Enter to close this window"
