<?php
return array(
	'DB_HOST'		=>	'localhost',
	'DB_NAME'		=>	'bt_default',
	'DB_PORT'		=>	3306,
	'DB_PREFIX'		=>	'bt_',
	'DB_CHARSET'	=>	'utf8',
	'DB_USER'		=>	'bt_default',
	'DB_PWD'		=>	'a85c70993275',	
);
?>
