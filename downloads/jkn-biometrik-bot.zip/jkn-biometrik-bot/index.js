// @ts-check
import bot from 'node-autoit-koffi';
import { createServer } from 'node:http';
import qs from 'node:querystring';
import pkg from './package.json' assert { type: 'json' };

const host = `127.0.0.1`;
const port = Number(process.env.SERVER_PORT) || 3000;

const apps = {
	finger: {
		winTitle: process.env.FP_WIN_TITLE || 'Aplikasi Registrasi Sidik Jari',
		path: process.env.FP_INS_PATH || 'C:\\Program Files (x86)\\BPJS Kesehatan\\Aplikasi Sidik Jari BPJS Kesehatan\\After.exe',
		run: run_finger_bot
	},
	frista: {
		winTitle: process.env.FP_WIN_TITLE || 'Login Frista (Face Recognition BPJS Kesehatan)',
		winTitle2: process.env.FP_WIN_TITLE2 || 'Frista (Face Recognition BPJS Kesehatan)',
		path: process.env.FP_INS_PATH || 'C:\\frista\\frista.exe',
		run: run_frista_bot
	}
};

const server = createServer((req, res) => {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Methods', 'POST');
	res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

	/** @param {Error} error  */
	function handle_error(error) {
		console.error(error);
		json(500, { message: error?.message || `Internal server error` });
	}

	/** @param {number} status @param {any=} data */
	function json(status, data) {
		res.writeHead(status, { 'Content-Type': 'application/json' });
		if (!data) return res.end();
		res.end(JSON.stringify(data));
	}

	try {
		const url = new URL(req.url || '/', `http://${host}`);
		const appKey = url.searchParams.get('app');
		const app = apps[appKey];

		if (!app) return json(400, { message: 'Invalid or missing ?app=finger|frista' });

		if (url.pathname === '/' && req.method === 'GET') {
			return json(200, { message: `Service for ${appKey}`, app: appKey });
		} else if (url.pathname === '/' && req.method === 'POST') {
			let body = '';
			req.on('data', (chunk) => (body += chunk.toString()));
			req.on('end', () => {
				const form_data = qs.parse(body);
				const username = form_data['username'];
				const password = form_data['password'];
				const card_number = form_data['card_number'];
				const exit = form_data['exit'] === 'true';
				const wait = form_data['wait'];

				if (!username || !password || !card_number) {
					return json(400, {
						message: `username, password, and card_number are required fields`
					});
				}

				app.run({ username, password, card_number, exit, wait, res, app })
					.then(() => json(201))
					.catch((e) => handle_error(e));
			});
		} else {
			json(404, { message: `Not found` });
		}
	} catch (error) {
		handle_error(error);
	}
});

server.listen(port, host, () => {
	console.log(`Server running at http://${host}:${port}`);
});

/** @param {number} ms */
function delay(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

async function run_finger_bot({ username, password, card_number, exit, wait, app }) {
	const { winTitle, path } = app;
	const already_open = await bot.winExists(winTitle);
	if (!already_open) {
		await bot.run(path);
		await bot.winWait(winTitle);
	}

	await bot.winActivate(winTitle);
	await bot.winWaitActive(winTitle);
	if (exit) await bot.winSetOnTop(winTitle, '', 1);

	const win_pos = await bot.winGetPos(winTitle);
	if (!win_pos) throw new Error('Failed to get window position');

	const { top, left } = win_pos;

	if (already_open) {
		await bot.mouseMove(left + 223, top + 121, 0);
		await bot.mouseClick('left');
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
	} else {
		await bot.mouseMove(left + 223, top + 179, 0);
		await bot.mouseClick('left');
		await delay(1000);
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
		await bot.send(username);
		await bot.send('{TAB}');
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
		await bot.send(password);
		await bot.send('{ENTER}');
		await delay(+wait || 3593);
	}

	await bot.send(card_number);
	if (exit) await bot.winWaitClose(winTitle);
}

async function run_frista_bot({ username, password, card_number, exit, wait, res, app }) {
	const { winTitle, winTitle2, path } = app;
	const already_open = await bot.winExists(winTitle);
	if (!already_open) {
		await bot.run(path);
		await bot.winWait(winTitle);
	}

	await bot.winActivate(winTitle);
	await bot.winWaitActive(winTitle);
	if (exit) await bot.winSetOnTop(winTitle, '', 1);

	const win_pos = await bot.winGetPos(winTitle);
	if (!win_pos) throw new Error('Failed to get window position');

	const { top, left } = win_pos;

	if (already_open) {
		await bot.mouseMove(left + 223, top + 121, 0);
		await bot.mouseClick('left');
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
	} else {
		await bot.mouseMove(left + 223, top + 179, 0);
		await bot.mouseClick('left');
		await delay(1000);
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
		await bot.send(username);
		await bot.send('{TAB}');
		await bot.send('^a');
		await bot.send('{BACKSPACE}');
		await bot.send(password);
		await bot.send('{TAB}');
		await bot.send('{SPACE}');
		await delay(+wait || 3593);
	}

	await bot.winActivate(winTitle2);
	const ok = await bot.winWaitActive(winTitle2);
	if (!ok) throw new Error("Aplikasi utama tidak terbuka dalam batas waktu");

	await delay(1000);
	await bot.mouseMove(left + 223, top + 121, 0);
	await bot.mouseClick('left');
	await bot.send(card_number);
	if (exit) await bot.winWaitClose(winTitle);
}
