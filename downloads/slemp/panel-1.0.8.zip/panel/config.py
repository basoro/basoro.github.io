#coding: utf-8

import public,web,re,sys,os
reload(sys)
sys.setdefaultencoding('utf-8')
class config:

    def setPassword(self,get):
        if get.password1 != get.password2: return public.returnMsg(False,'Kata sandi yang dimasukkan dua kali tidak cocok, silakan masukkan kembali!')
        if len(get.password1) < 5: return public.returnMsg(False,'Kata sandi pengguna tidak boleh kurang dari 5 digit!')
        public.M('users').where("username=?",(web.ctx.session.username,)).setField('password',public.md5(get.password1))
        public.WriteLog('Konfigurasi panel','Ubah kata sandi pengguna ['+web.ctx.session.username+'] berhasil!')
        return public.returnMsg(True,'Kata sandi berhasil dimodifikasi.!')

    def setUsername(self,get):
        if get.username1 != get.username2: return public.returnMsg(False,'Nama pengguna yang dimasukkan dua kali tidak konsisten, silakan masukkan kembali!')
        if len(get.username1) < 3: return public.returnMsg(False,'Nama pengguna tidak boleh kurang dari 3 digit!')
        public.M('users').where("username=?",(web.ctx.session.username,)).setField('username',get.username1)
        web.ctx.session.username = get.username1
        public.WriteLog('Konfigurasi panel','Ubah pengguna ['+get.username2+'] dengan ['+get.username1+']!')
        return public.returnMsg(True,'Nama pengguna berhasil diubah!')

    def setPanel(self,get):
        if not public.IsRestart(): return public.returnMsg(False,'Harap tunggu semua tugas instalasi selesai sebelum dieksekusi!');
        if get.domain:
            reg = "^([\w\-\*]{1,100}\.){1,4}(\w{1,10}|\w{1,10}\.\w{1,10})$";
            if not re.match(reg, get.domain): return public.returnMsg(False,'Format nama domain salah!');
        isReWeb = False
        oldPort = web.ctx.host.split(':')[1];
        newPort = get.port;
        if oldPort != get.port:
            if self.IsOpen(get.port):
                return public.returnMsg(False,'Port ['+get.port+'] sudah dipakai!')
            if int(get.port) >= 65535 or  int(get.port) < 100: return public.returnMsg(False,'Rentang port tidak benar!');
            public.writeFile('data/port.pl',get.port)
            import firewalls
            get.ps = 'Port panel baru';
            fw = firewalls.firewalls();
            fw.AddAcceptPort(get);
            get.port = oldPort;
            get.id = public.M('firewall').where("port=?",(oldPort,)).getField('id');
            fw.DelAcceptPort(get);
            isReWeb = True

        if get.webname != web.ctx.session.webname: public.writeFile('data/title.pl',get.webname);

        limitip = public.readFile('data/limitip.conf');
        if get.limitip != limitip: public.writeFile('data/limitip.conf',get.limitip);

        public.writeFile('data/domain.conf',get.domain.strip())
        public.writeFile('data/iplist.txt',get.address)

        public.M('config').where("id=?",('1',)).save('backup_path,sites_path',(get.backup_path,get.sites_path))
        web.ctx.session.config['backup_path'] = get.backup_path
        web.ctx.session.config['sites_path'] = get.sites_path

        data = {'uri':web.ctx.fullpath,'host':web.ctx.host.split(':')[0]+':'+newPort,'status':True,'isReWeb':isReWeb,'msg':'Konfigurasi disimpan!'}
        public.WriteLog('Konfigurasi panel','Setel port panel ['+newPort+'], Nama domain ['+get.domain+'], Direktori backup ['+get.backup_path+'], Direktori situs ['+get.sites_path+'], IP server ['+get.address+'], IP otorisasi ['+get.limitip+']!')
        return data

    def setPathInfo(self,get):
        version = get.version
        type = get.type
        if web.ctx.session.webserver == 'nginx':
            path = web.ctx.session.setupPath+'/nginx/conf/enable-php-'+version+'.conf';
            conf = public.readFile(path);
            rep = "\s+#*include\s+pathinfo.conf;";
            if type == 'on':
                conf = re.sub(rep,'\n\t\t\tinclude pathinfo.conf;',conf)
            else:
                conf = re.sub(rep,'\n\t\t\t#include pathinfo.conf;',conf)
            public.writeFile(path,conf)
            public.serviceReload();

        path = web.ctx.session.setupPath+'/php/'+version+'/etc/php.ini';
        conf = public.readFile(path);
        rep = "\n*\s*cgi\.fix_pathinfo\s*=\s*([0-9]+)\s*\n";
        status = '0'
        if type == 'on':status = '1'
        conf = re.sub(rep,"\ncgi.fix_pathinfo = "+status+"\n",conf)
        public.writeFile(path,conf)
        public.WriteLog("Konfigurasi PHP", "Menyiapkan PHP-"+version+" Modul PATH_INFO ["+type+"]!");
        public.phpReload(version);
        return public.returnMsg(True,type+' berhasil disimpan!');

    def setPHPMaxSize(self,get):
        version = get.version
        max = get.max

        if int(max) < 2: return public.returnMsg(False,'Batas ukuran unggahan tidak boleh kurang dari 2M!')

        path = web.ctx.session.setupPath+'/php/'+version+'/etc/php.ini'
        conf = public.readFile(path)
        rep = u"\nupload_max_filesize\s*=\s*[0-9]+M"
        conf = re.sub(rep,u'\nupload_max_filesize = '+max+'M',conf)
        rep = u"\npost_max_size\s*=\s*[0-9]+M"
        conf = re.sub(rep,u'\npost_max_size = '+max+'M',conf)
        public.writeFile(path,conf)

        if web.ctx.session.webserver == 'nginx':
            path = web.ctx.session.setupPath+'/nginx/conf/nginx.conf'
            conf = public.readFile(path)
            rep = "client_max_body_size\s+([0-9]+)m"
            tmp = re.search(rep,conf).groups()
            if int(tmp[0]) < int(max):
                conf = re.sub(rep,'client_max_body_size '+max+'m',conf)
                public.writeFile(path,conf)

        public.serviceReload()
        public.phpReload(version);
        public.WriteLog("Konfigurasi PHP", "Menyiapkan PHP-"+version+". Ukuran unggahan maksimum adalah ["+max+"] MB!")
        return public.returnMsg(True,'Konfigurasi berhasil disimpan!')

    def setPHPDisable(self,get):
        filename = web.ctx.session.setupPath + '/php/' + get.version + '/etc/php.ini'
        if not os.path.exists(filename): return public.returnMsg(False,'Versi PHP yang ditentukan tidak ada!');
        phpini = public.readFile(filename);
        rep = "disable_functions\s*=\s*.*\n"
        phpini = re.sub(rep, 'disable_functions = ' + get.disable_functions + "\n", phpini);
        public.WriteLog('Konfigurasi PHP','Ubah PHP-'+get.version+'. Nonaktifkan fungsi ['+get.disable_functions+']')
        public.writeFile(filename,phpini);
        public.phpReload(get.version);
        return public.returnMsg(True,'Dimodifikasi dengan sukses!');

    def setPHPMaxTime(self,get):
        time = get.time
        version = get.version;
        if int(time) < 30 or int(time) > 86400: return public.returnMsg(False,'Silakan isi nilai antara 30-86400!');
        file = web.ctx.session.setupPath+'/php/'+version+'/etc/php-fpm.conf';
        conf = public.readFile(file);
        rep = "request_terminate_timeout\s*=\s*([0-9]+)\n";
        conf = re.sub(rep,"request_terminate_timeout = "+time+"\n",conf);
        public.writeFile(file,conf)

        if web.ctx.session.webserver == 'nginx':
            path = web.ctx.session.setupPath+'/nginx/conf/nginx.conf';
            conf = public.readFile(path);
            rep = "fastcgi_connect_timeout\s+([0-9]+);";
            tmp = re.search(rep, conf).groups();
            if int(tmp[0]) < time:
                conf = re.sub(rep,'fastcgi_connect_timeout '+time+';',conf);
                rep = "fastcgi_send_timeout\s+([0-9]+);";
                conf = re.sub(rep,'fastcgi_send_timeout '+time+';',conf);
                rep = "fastcgi_read_timeout\s+([0-9]+);";
                conf = re.sub(rep,'fastcgi_read_timeout '+time+';',conf);
                public.writeFile(path,conf)

        public.WriteLog("Konfigurasi PHP", "Menyiapkan PHP-"+version+" Periode batas waktu skrip maksimum adalah ["+time+"] detik!");
        public.serviceReload()
        public.phpReload(version);
        return public.returnMsg(True, 'Berhasil disimpan!');

    def getFpmConfig(self,get):
        version = get.version;
        file = web.ctx.session.setupPath+"/php/"+version+"/etc/php-fpm.conf";
        conf = public.readFile(file);
        data = {}
        rep = "\s*pm.max_children\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['max_children'] = tmp[0];

        rep = "\s*pm.start_servers\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['start_servers'] = tmp[0];

        rep = "\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['min_spare_servers'] = tmp[0];

        rep = "\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['max_spare_servers'] = tmp[0];

        return data

    def setFpmConfig(self,get):
        version = get.version
        max_children = get.max_children
        start_servers = get.start_servers
        min_spare_servers = get.min_spare_servers
        max_spare_servers = get.max_spare_servers

        file = web.ctx.session.setupPath+"/php/"+version+"/etc/php-fpm.conf";
        conf = public.readFile(file);

        rep = "\s*pm.max_children\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.max_children = "+max_children, conf);

        rep = "\s*pm.start_servers\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.start_servers = "+start_servers, conf);

        rep = "\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.min_spare_servers = "+min_spare_servers, conf);

        rep = "\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.max_spare_servers = "+max_spare_servers+"\n", conf);
        public.writeFile(file,conf)
        public.phpReload(version);
        public.WriteLog("Konfigurasi PHP", "Menyiapkan pengaturan PHP-"+version+", max_children="+max_children+", start_servers="+start_servers+", min_spare_servers="+min_spare_servers+", max_spare_servers="+max_spare_servers);
        return public.returnMsg(True, 'Berhasil disimpan!');

    def syncDate(self,get):
        result = public.ExecShell("ntpdate 0.asia.pool.ntp.org");
        public.WriteLog("Pengaturan ", "Sinkronisasi saktu server berhasil!");
        return public.returnMsg(True,"Sinkronisasi berhasil!");

    def IsOpen(self,port):
        import socket
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            s.connect(('127.0.0.1',int(port)))
            s.shutdown(2)
            return True
        except:
            return False

    def SetControl(self,get):
        try:
            if hasattr(get,'day'):
                get.day = int(get.day);
                get.day = str(get.day);
                if(get.day < 1): return public.returnMsg(False,"Jumlah hari yang disimpan adalah ilegal!");
        except:
            pass

        filename = 'data/control.conf';
        if get.type == '1':
            public.writeFile(filename,get.day);
            public.WriteLog("Pengaturan pemantauan", "Layanan pemantauan terbuka, Penyimpanan rekaman ["+get.day+"] hari!");
        elif get.type == '0':
            public.ExecShell("rm -f " + filename);
            public.WriteLog("Pengaturan pemantauan", "Matikan layanan pemantauan!");
        elif get.type == 'del':
            if not public.IsRestart(): return public.returnMsg(False,'Harap tunggu semua tugas instalasi selesai sebelum dieksekusi!');
            os.remove("data/system.db")
            import db;
            sql = db.Sql()
            result = sql.dbfile('system').create('system');
            public.WriteLog("Pengaturan pemantauan", "Catatan pemantauan telah dikosongkan!");
            return public.returnMsg(True,"Bersihkan dengan sukses!");

        else:
            data = {}
            if os.path.exists(filename):
                try:
                    data['day'] = int(public.readFile(filename));
                except:
                    data['day'] = 30;
                data['status'] = True
            else:
                data['day'] = 30;
                data['status'] = False
            return data


        return public.returnMsg(True,"Penyiapan yang berhasil!");

    def Set502(self,get):
        try:
            filename = 'data/502Task.pl';
            if os.path.exists(filename):
                os.system('rm -f ' + filename)
            else:
                public.writeFile(filename,'True')

            return public.returnMsg(True,'Penyiapan yang berhasil!');
        except:
            return public.returnMsg(True,'Gagal, disk tidak dapat ditulisi!');
