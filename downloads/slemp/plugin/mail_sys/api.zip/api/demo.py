#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 王张杰 <750755014@qq.com>
# +-------------------------------------------------------------------

#------------------------------
# send mail api demo of Python
#------------------------------
import requests


def send_mail(mail_from, password, mail_to, subject, content, subtype=None):

    # The sender interface address to be called, for example http://192.168.1.11:8888/mail_sys/send_mail_http.json
    url = 'http://your_panel_address/mail_sys/send_mail_http.json'

    pdata = {}
    pdata['mail_from'] = mail_from
    pdata['password'] = password
    pdata['mail_to'] = mail_to
    pdata['subject'] = subject
    pdata['content'] = content
    pdata['subtype'] = subtype

    resp_data = requests.post(url, pdata).json()
    print resp_data


if __name__ == '__main__':

    # Sender's email address, such as jack@bt.cn
    mail_from = ''
    # Sender email address password
    password = ''
    # Recipient address, separated by commas, such as jack@bt.cn, rose@bt.cn
    mail_to = ''
    # Mail title
    subject = ''
    # Content of email
    content = ''
    # Mail type, do not pass the default is plain, to send html please send html
    subtype = ''
    send_mail(mail_from, password, mail_to, subject, content)
