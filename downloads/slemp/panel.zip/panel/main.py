#!/usr/bin/env python
#coding:utf-8
import sys,web,io,os
global panelPath
panelPath = '/opt/slemp/server/panel/';
os.chdir(panelPath)
import common,public,data,page,db

from collections import OrderedDict
web.config.debug = False

'''from web.wsgiserver import CherryPyWSGIServer
CherryPyWSGIServer.ssl_certificate = "data/certificate.pem"
CherryPyWSGIServer.ssl_private_key = "data/privateKey.pem"'''

urls = (
    '/'        , 'panelIndex',
    '/site'    , 'panelSite',
    '/data'    , 'panelData',
    '/files'   , 'panelFiles',
    '/database', 'panelDatabase',
    '/firewall', 'panelFirewall',
    '/config'  , 'panelConfig',
    '/crontab' , 'panelCrontab',
    '/login'   , 'panelLogin',
    '/system'  , 'panelSystem',
    '/ajax'    , 'panelAjax',
    '/download', 'panelDownload',
    '/control' , 'panelControl',
    '/soft'    , 'panelSoft',
    '/cloud'   , 'panelCloud',
    '/close'   , 'panelClose',
    '/plugin'  , 'panelPlugin',
)


app = web.application(urls, globals())

web.config.session_parameters['cookie_name'] = 'SLEMP_PANEL'
web.config.session_parameters['cookie_domain'] = None
web.config.session_parameters['timeout'] = 3600
web.config.session_parameters['ignore_expiry'] = True
web.config.session_parameters['ignore_change_ip'] = True
web.config.session_parameters['secret_key'] = 'slemp.basoro.id'
web.config.session_parameters['expired_message'] = 'Session expired'
dbfile = '/dev/shm/session.db';
src_sessiondb = '/opt/slemp/server/panel/data/session.db';
if not os.path.exists(src_sessiondb):
    print db.Sql().dbfile('session').create('session');
if not os.path.exists('/dev/shm'): os.system('mkdir -p /dev/shm');
if not os.path.exists(dbfile): os.system("\\cp -a -r "+src_sessiondb+" " + dbfile);
sessionDB = web.database(dbn='sqlite', db=dbfile)
session = web.session.Session(app, web.session.DBStore(sessionDB,'sessions'), initializer={'login': False});
def session_hook():
    session.panelPath = os.path.dirname(__file__);
    web.ctx.session = session
app.add_processor(web.loadhook(session_hook))

render = web.template.render(panelPath + 'templates/',base='template',globals={'session': session,'web':web})

class panelIndex(common.panelAdmin):
    def GET(self):
        import system
        data = system.system().GetConcifInfo()
        data['siteCount'] = public.M('sites').count()
        data['databaseCount'] = public.M('databases').count()
        return render.index(data)

class panelLogin(common.panelSetup):
    def GET(self):
        if not hasattr(session,'webname'): session.webname = 'SLEMP Panel';
        tmp = web.ctx.host.split(':')
        domain = public.readFile('data/domain.conf')
        if domain:
            if(tmp[0].strip() != domain.strip()):
                errorStr = '''
    <meta charset="utf-8">
    <title>Tolak akses</title>
    </head><body>
    <h1>Maaf, Anda tidak memiliki akses</h1>
        <p>Silakan gunakan nama domain yang benar untuk mengakses!</p>
        <p>Lihat nama domain: cat /opt/slemp/server/panel/data/domain.conf</p>
        <p>Matikan limit akses: rm -f /opt/slemp/server/panel/data/domain.conf</p>
    <hr>
    <address>SLEMP Panel 1.x <a href="https://slemp.basoroid" target="_blank">Bantuan</a></address>
    </body></html>
    '''
                web.header('Content-Type','text/html; charset=utf-8', unique=True)
                return errorStr
        if os.path.exists('data/limitip.conf'):
            iplist = public.readFile('data/limitip.conf')
            if iplist:
                if not web.ctx.ip in iplist.split(','):
                    errorStr = '''
<meta charset="utf-8">
<title>Tolak akses</title>
</head><body>
<h1>Maaf, IP Anda tidak diotorisasi</h1>
    <p>IP Anda saat ini adalah [%s], silakan gunakan akses IP yang benar!</p>
    <p>Lihat data IP: cat /opt/slemp/server/panel/data/limitip.conf</p>
    <p>Matikan batasan akses: rm -f /opt/slemp/server/panel/data/limitip.conf</p>
<hr>
<address>SLEMP Panel 1.x <a href="https://slemp.basoroid" target="_blank">Bantuan</a></address>
</body></html>
''' % (web.ctx.ip,)
                    web.header('Content-Type','text/html; charset=utf-8', unique=True)
                    return errorStr;

        get = web.input()
        sql = db.Sql()
        if hasattr(get,'dologin'):
            if session.login != False:
                session.login = False;
                session.kill();
            import time
            time.sleep(0.2);
            raise web.seeother('/login')

        if hasattr(session,'login'):
            if session.login == True:
                raise web.seeother('/')

        data = sql.table('users').getField('username')
        render = web.template.render(panelPath + 'templates/',globals={'session': session})
        return render.login(data)


    def POST(self):
        post = web.input()
        if not (hasattr(post, 'username') or hasattr(post, 'password')):
            return public.returnJson(False,'Nama pengguna atau kata sandi tidak boleh kosong');

        if self.limitAddress('?') < 1: return public.returnJson(False,'Anda gagal masuk berkali-kali, silahkan coba beberapa saat lagi!');
        password = public.md5(post.password)

        sql = db.Sql()
        userInfo = sql.table('users').where("username=? AND password=?",(post.username,password)).field('id,username,password').find()
        try:
            if userInfo['username'] != post.username or userInfo['password'] != password:
                public.WriteLog('登陆','<a style="color:red;">密码错误</a>,帐号:'+post.username+',密码:'+post.password+',登陆IP:'+ web.ctx.ip);
                num = self.limitAddress('+');
                return public.returnJson(False,'用户名或密码错误,您还可以尝试['+str(num)+']次.');

            import time;
            login_temp = 'data/login.temp'
            if not os.path.exists(login_temp): public.writeFile(login_temp,'');
            login_logs = public.readFile(login_temp);
            public.writeFile(login_temp,login_logs+web.ctx.ip+'|'+str(int(time.time()))+',');
            session.login = True
            session.username = post.username
            public.WriteLog('登陆','<a style="color:#3498DB;">登陆成功</a>,帐号:'+post.username+',登陆IP:'+ web.ctx.ip);
            self.limitAddress('-');
            return public.returnJson(True,'登陆成功,正在跳转!');
        except:
            public.WriteLog('登陆','<a style="color:red;">密码错误</a>,帐号:'+post.username+',密码:'+post.password+',登陆IP:'+ web.ctx.ip);
            num = self.limitAddress('+');
            return public.returnJson(False,'用户名或密码错误,您还可以尝试['+str(num)+']次.');

    def limitAddress(self,type):
        import time
        logFile = 'data/'+web.ctx.ip+'.login';
        timeFile = 'data/'+web.ctx.ip+'_time.login';
        limit = 6;
        outtime = 1800;
        try:
            #初始化
            if not os.path.exists(timeFile): public.writeFile(timeFile,str(time.time()));
            if not os.path.exists(logFile): public.writeFile(logFile,'0');

            #判断是否解除登陆限制
            time1 = long(public.readFile(timeFile).split('.')[0]);
            if (time.time() - time1) > outtime:
                public.writeFile(logFile,'0');
                public.writeFile(timeFile,str(time.time()));

            #计数
            num1 = int(public.readFile(logFile));
            if type == '+':
                num1 += 1;
                public.writeFile(logFile,str(num1));

            #清空
            if type == '-':
                public.ExecShell('rm -f data/*.login');
                return 1;

            return limit - num1;
        except:
            return limit;


class panelSite(common.panelAdmin):
    def GET(self):
        data = {}
        data['isSetup'] = True;
        if os.path.exists(web.ctx.session.setupPath+'/nginx') == False: data['isSetup'] = False;
        return render.site(data);

    def POST(self):
        get = web.input()
        import sites
        siteObject = sites.sites()

        defs = ('GetCheckSafe','CheckSafe','GetDefaultSite','SetDefaultSite','AddSite','GetPHPVersion','SetPHPVersion','DeleteSite','AddDomain','DelDomain','GetDirBinding','AddDirBinding','GetDirRewrite','DelDirBinding'
                ,'SetSiteRunPath','GetSiteRunPath','SetPath','SetIndex','GetIndex','GetDirUserINI','SetDirUserINI','GetRewriteList','SetSSL','SetSSLConf','CreateLet','CloseSSLConf','GetSSL','SiteStart','SiteStop'
                ,'Set301Status','Get301Status','CloseLimitNet','SetLimitNet','GetLimitNet','SetProxy','GetProxy','ToBackup','DelBackup','GetSitePHPVersion','logsOpen','GetLogsStatus','CloseHasPwd','SetHasPwd','GetHasPwd')
        for key in defs:
            if key == get.action:
                fun = 'siteObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')

class panelConfig(common.panelAdmin):
    def GET(self):
        import system
        data = system.system().GetConcifInfo()
        return render.config(data)

    def POST(self):
        get = web.input()
        import config
        configObject = config.config()
        defs = ('Set502','setPassword','setUsername','setPanel','setPathInfo','setPHPMaxSize','getFpmConfig','setFpmConfig','setPHPMaxTime','syncDate','setPHPDisable','SetControl','ClosePanel','AutoUpdatePanel','SetPanelLock')
        for key in defs:
            if key == get.action:
                fun = 'configObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')

class panelDownload(common.panelAdmin):
    def GET(self):
        get = web.input()
        try:
            get.filename = get.filename.encode('utf-8');
            import os
            fp = open(get.filename,'rb')
            size = os.path.getsize(get.filename)
            filename = os.path.basename(get.filename)

            #输出文件头
            web.header("Content-Disposition", "attachment; filename=" +filename);
            web.header("Content-Length", size);
            web.header('Content-Type','application/octet-stream')
            buff = 4096
            while True:
                fBody = fp.read(buff)
                if fBody:
                    yield fBody
                else:
                    return
        except Exception, e:
            yield 'Error'
        finally:
            if fp:
                fp.close()

class panelCloud(common.panelAdmin):
    def GET(self):
        import json
        get = web.input()
        result = public.ExecShell("python "+web.ctx.session.setupPath + '/panel/script/backup_'+get.filename+'.py download ' + get.name)
        raise web.seeother(json.loads(result[0]));


class panelFiles(common.panelAdmin):
    def GET(self):
        return render.files('test')

    def POST(self):
        get = web.input(zunfile = {},data = [])
        if hasattr(get,'path'):
            get.path = get.path.replace('//','/').replace('\\','/');

        import files
        filesObject = files.files()
        defs = ('UploadFile','GetDir','CreateFile','CreateDir','DeleteDir','DeleteFile',
                'CopyFile','CopyDir','MvFile','GetFileBody','SaveFileBody','Zip','UnZip',
                'GetFileAccess','SetFileAccess','GetDirSize','SetBatchData','BatchPaste',
                'DownloadFile','GetTaskSpeed','CloseLogs','InstallSoft','UninstallSoft',
                'RemoveTask','ActionTask','Re_Recycle_bin','Get_Recycle_bin','Del_Recycle_bin','Close_Recycle_bin','Recycle_bin')
        for key in defs:
            if key == get.action:
                fun = 'filesObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')

class panelDatabase(common.panelAdmin):
    def GET(self):
        pmd = self.get_phpmyadmin_dir();
        web.ctx.session.phpmyadminDir = False
        if pmd:
            web.ctx.session.phpmyadminDir = 'http://' + web.ctx.host.split(':')[0] + ':'+ pmd[1] + '/' + pmd[0];

        data = {}
        data['isSetup'] = True;
        if os.path.exists(web.ctx.session.setupPath+'/mysql') == False: data['isSetup'] = False;
        return render.database(data)

    def POST(self):
        import json
        import database
        get = web.input(data = [])
        databaseObject = database.database()
        defs = ('GetMySQLInfo','SetDataDir','SetMySQLPort','AddDatabase','DeleteDatabase','SetupPassword','ResDatabasePassword','ToBackup','DelBackup','InputSql','SyncToDatabases','SyncGetDatabases','GetDatabaseAccess','SetDatabaseAccess')
        for key in defs:
            if key == get.action:
                fun = 'databaseObject.'+key+'(get)'
                return public.getJson(eval(fun))
        return public.returnJson(False,'指定参数无效!')

    def get_phpmyadmin_dir(self):
        path = web.ctx.session.setupPath + '/phpmyadmin'
        if not os.path.exists(path): return None

        phpport = '1234';
        try:
            import re;
            if web.ctx.session.webserver == 'nginx':
                filename = web.ctx.session.setupPath + '/nginx/conf/nginx.conf';
                conf = public.readFile(filename);
                rep = "listen\s+([0-9]+)\s*;";
                rtmp = re.search(rep,conf);
                if rtmp:
                    phpport = rtmp.groups()[0];
        except:
            pass




        for filename in os.listdir(path):
            print filename
            filepath = path + '/' + filename
            if os.path.isdir(filepath):
                if filename[0:10] == 'phpmyadmin':
                    return str(filename),phpport

        return None

class panelFirewall(common.panelAdmin):
    def GET(self):
        return render.firewall("test")

    def POST(self):
        import json
        import firewalls
        get = web.input()
        firewallObject = firewalls.firewalls()
        defs = ('AddDropAddress','DelDropAddress','FirewallReload','SetFirewallStatus','AddAcceptPort','DelAcceptPort','SetSshStatus','SetPing','SetSshPort','GetSshInfo')
        for key in defs:
            if key == get.action:
                fun = 'firewallObject.'+key+'(get)'
                return public.getJson(eval(fun))
        return public.returnJson(False,'指定参数无效!')


class panelCrontab(common.panelAdmin):
    def GET(self):
        import crontab
        get = web.input()
        data = crontab.crontab().GetCrontab(get)
        return render.crontab(data)

    def POST(self):
        get = web.input()

        import crontab
        crontabObject = crontab.crontab()
        defs = ('GetCrontab','AddCrontab','GetDataList','GetLogs','DelLogs','DelCrontab','StartTask')
        for key in defs:
            if key == get.action:
                fun = 'crontabObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')

class panelSystem(common.panelAdmin):
    def GET(self):
        return self.funObj()

    def POST(self):
        return self.funObj()

    def funObj(self):
        import system,json
        get = web.input()
        sysObject = system.system()
        defs = ('GetNetWork','GetDiskInfo','GetCpuInfo','GetBootTime','GetSystemVersion','GetMemInfo','GetSystemTotal','GetConcifInfo','ServiceAdmin','ReWeb','RestartServer','ReMemory')
        for key in defs:
            if key == get.action:
                fun = 'sysObject.'+key+'()'
                return public.getJson(eval(fun))
        return public.returnJson(False,'指定参数无效!')

class panelAjax(common.panelAdmin):
    def GET(self):
        return self.funObj()

    def POST(self):
        return self.funObj()

    def funObj(self):
        import ajax,json
        get = web.input()
        ajaxObject = ajax.ajax()
        defs = ('phpSort','ToPunycode','GetBetaStatus','SetBeta','setPHPMyAdmin','delClose','KillProcess','GetPHPInfo','GetProcessList','GetNetWorkList','GetNginxStatus','GetPHPStatus','GetTaskCount','GetNetWorkIo','GetDiskIo','GetCpuIo','CheckInstalled','GetInstalled','GetPHPConfig','SetPHPConfig')
        for key in defs:
            if key == get.action:
                fun = 'ajaxObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')

class panelData(common.panelAdmin):

    def GET(self):
        return self.funObj()

    def POST(self):
        return self.funObj()


    def funObj(self):
        try:
            get = web.input()
            dataObject = data.data()
            defs = ('setPs','getData','getFind','getKey')
            for key in defs:
                if key == get.action:
                    fun = 'dataObject.'+key+'(get)'
                    return public.getJson(eval(fun))
        except:
            import time
            time.sleep(1)
            return self.funObj()

        return public.returnJson(False,'指定参数无效!')

class panelControl(common.panelAdmin):
    def GET(self):
        data = web.input()
        return render.control(data)

class panelSoft(common.panelAdmin):
    def GET(self):
        import system
        data = system.system().GetConcifInfo()
        return render.soft(data)

class panelPlugin(common.panelAdmin):
    def GET(self):
        return self.funObj()

    def POST(self):
        return self.funObj()

    def funObj(self):
        get = web.input()
        import plugins
        pluginObject = plugins.plugins()
        defs = ('install','unInstall','getPluginList','getPluginInfo','getPluginStatus','setPluginStatus','a','getCloudPlugin','getConfigHtml','savePluginSort')
        for key in defs:
            if key == get.action:
                fun = 'pluginObject.'+key+'(get)'
                return public.getJson(eval(fun))

        return public.returnJson(False,'指定参数无效!')


def publicObject(toObject,defs):
    get = web.input();
    for key in defs:
        if key == get.action:
            fun = 'toObject.'+key+'(get)'
            return public.getJson(eval(fun))

    return public.returnJson(False,'指定参数无效!')

def notfound():
    errorStr = '''
    <meta charset="utf-8">
    <title>404 Not Found</title>
    </head><body>
    <h1>Maaf, halaman tidak ada.</h1>
        <p>Halaman yang Anda minta tidak ada. Harap periksa apakah alamat URL benar.!</p>
    <hr>
    <address>SLEMP Panel 1.x <a href="https://slemp.basoro.id" target="_blank">Bantuan</a></address>
    </body></html>
    '''
    return web.notfound(errorStr);

def internalerror():
    errorStr = '''
    <meta charset="utf-8">
    <title>500 Internal Server Error</title>
    </head><body>
    <h1>Maaf, cilukba....!!</h1>
        <p>Halaman yang anda minta rusak!</p>
    <hr>
    <address>SLEMP Panel 1.x <a href="https://slemp.basoro.id" target="_blank">Bantuan</a></address>
    </body></html>
    '''
    return web.internalerror(errorStr)

if __name__ == "__main__":
    app.notfound = notfound
    app.internalerror = internalerror
    reload(sys)
    sys.setdefaultencoding("utf-8")
    app.run()
