# SLEMP
(Simple Linux Engine-X (Nginx) MySQL PHP-FPM)
