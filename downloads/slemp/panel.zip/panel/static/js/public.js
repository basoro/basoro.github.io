function PageData(data,page,type){
	var next = page + 1;
	var prev = page - 1;
	var disabled_prev = '';
	var disabled_next = '';
	if (page <= 1) {
		disabled_prev = 'disabled';
		prev = 1;
	}
	if (page >= data.page) {
		disabled_next = 'disabled';
		next = data.page;
	}

	if (page < 4) {
		var i = 1;
	} else {
		var i = page - 1;
	}

	var count = i+3;
	if ((data.page - page) < 2) {
		count = data.page + 1;
	}

	var PageData = "<li class='" + disabled_prev + "'><a href='javascript:;' onclick='"+type+"(1)'>&lt;&lt;</a></li><li class='prev " + disabled_prev + "'><a href='javascript:;' onclick='"+type+"(" + prev + ")'>&lt;</a></li>";
	for (i; i < count; i++) {
		if (i == page) {
			PageData += "<li class='active'><a href='javascript:;' onclick='"+type+"(" + i + ")'>" + i + "</a></li>";
		} else {
			PageData += "<li><a href='javascript:;' onclick='"+type+"(" + i + ")'>" + i + "</a></li>";
		}
	}
	PageData += "<li class='next " + disabled_next + "'><a href='javascript:;' onclick='"+type+"(" + next + ")'>&gt;</a></li>\
	<li class='" + disabled_next + "'><a href='javascript:;' onclick='"+type+"(" + data.page + ")'>&gt;&gt;</a></li>\
	<li class='disabled'><a href='javascript:;'>Total " + data.page + " page  "+data.count+" records</a></li>";
	return PageData;
}

$(document).ready(function() {
	$(".sub-menu a.sub-menu-a").click(function() {
		$(this).next(".sub").slideToggle("slow")
			.siblings(".sub:visible").slideUp("slow");
	});
});

function RandomStrPwd(len) {
	len = len || 32;
	var $chars = 'AaBbCcDdEeFfGHhiJjKkLMmNnPpRSrTsWtXwYxZyz2345678';
	var maxPos = $chars.length;
	var pwd = '';
	for (i = 0; i < len; i++) {
		pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
	}
	return pwd;
}
function repeatPwd(len){
	$("#MyPassword").val(RandomStrPwd(len));
}

function refresh(){
    window.location.reload();
}

function GetBakPost(tab){
	$(".baktext").hide().prev().show();
	var id = $(".baktext").attr("data-id");
	var bakText = $(".baktext").val();
	if(bakText==''){
		bakText='Cloud';
	}
	setWebPs(tab, id, bakText);
	$("a[data-id='"+id+"']").html(bakText)
	$(".baktext").remove();
}

function setWebPs(tab, id, bakText) {
	var loadT = layer.load({
		shade: true,
		shadeClose: false
	});
	var data = "ps="+bakText;
	$.post('/data?action=setPs','table=' + tab + '&id=' + id + '&' + data, function(ret) {
		if (ret == true) {
			if (tab == 'sites') {
				getWeb(1);
			} else {
				getData(1);
			}

			layer.closeAll();
			layer.msg('Successfully modified', {
				icon: 1
			});
		} else {
			layer.msg('Failed, no permission', {
				icon:2
			});
			layer.closeAll();
		}
	});
}

$("#setBox").click(function() {
	if ($(this).prop("checked")) {
		$("input[name=id]").prop("checked", true);
	} else {
		$("input[name=id]").prop("checked", false);
	}
});

$(".menu-icon").click(function() {
	$(".sidebar-scroll").toggleClass("sidebar-close");
	$(".main-content").toggleClass("main-content-open");
	if ($(".sidebar-close")) {
		$(".sub-menu").find(".sub").css("display", "none");
	}
});
var Upload,percentage;

Date.prototype.format = function(format)
{
	 var o = {
	 "M+" : this.getMonth()+1, //month
	 "d+" : this.getDate(),    //day
	 "h+" : this.getHours(),   //hour
	 "m+" : this.getMinutes(), //minute
	 "s+" : this.getSeconds(), //second
	 "q+" : Math.floor((this.getMonth()+3)/3),  //quarter
	 "S" : this.getMilliseconds() //millisecond
	 }
	 if(/(y+)/.test(format)) format=format.replace(RegExp.$1,
	 (this.getFullYear()+"").substr(4 - RegExp.$1.length));
	 for(var k in o)if(new RegExp("("+ k +")").test(format))
	 format = format.replace(RegExp.$1,
	 RegExp.$1.length==1 ? o[k] :
	 ("00"+ o[k]).substr((""+ o[k]).length));
	 return format;
}

function getLocalTime(tm) {
	tm  = tm.toString();
	if(tm.length > 10){
		tm = tm.substring(0,10);
	}
	return new Date(parseInt(tm) * 1000).format("yyyy/MM/dd hh:mm:ss");
}

function ToSize(bytes){
	var unit = [' B',' KB',' MB',' GB'];
	var c = 1024;
	for(var i=0;i<unit.length;i++){
		if(bytes < c){
			return (i==0?bytes:bytes.toFixed(2)) + unit[i];
		}
		bytes /= c;
	}
}

function ChangePath(id){
	setCookie("SetId",id);
	var mycomputer = layer.open({
		type: 1,
		area: '650px',
		title: 'Select directory',
		closeBtn: 2,
		shift: 5,
		shadeClose: false,
		content:"<div class='changepath'>\
			<div class='path-top'>\
				<button type='button' class='btn btn-default btn-sm' onclick='BackFile()'><span class='glyphicon glyphicon-share-alt'></span> Return</button>\
				<div class='place' id='PathPlace'>Current path：<span></span></div>\
			</div>\
			<div class='path-con'>\
				<div class='path-con-left'>\
					<dl>\
						<dt id='comlist' onclick='BackMyComputer()'>Computer</dt>\
					</dl>\
				</div>\
				<div class='path-con-right'>\
					<ul class='default' id='computerDefautl'></ul>\
					<div class='file-list'>\
						<table class='table table-hover'>\
							<thead>\
								<tr class='file-list-head'>\
									<th width='40%'>Filename</th>\
									<th width='20%'>Modified datetime</th>\
									<th width='10%'>Chmod</th>\
									<th width='10%'>Owner</th>\
									<th width='10%'></th>\
								</tr>\
							</thead>\
							<tbody id='tbody' class='list-list'>\
							</tbody>\
						</table>\
					</div>\
				</div>\
			</div>\
		</div>\
		<div class='getfile-btn' style='margin-top:0'>\
				<button type='button' class='btn btn-default btn-sm pull-left' onclick='CreateFolder()'>New folder</button>\
				<button type='button' class='btn btn-danger btn-sm btn-title' onclick=\"layer.close(getCookie('ChangePath'))\">Close</button>\
				<button type='button' class='btn btn-info btn-sm btn-title' onclick='GetfilePath()'>Select</button>\
			</div>"
	});
	setCookie('ChangePath',mycomputer);
	var path = $("#inputPath").val();
	GetDiskList("");
	GetDiskList(path);
	ActiveDisk();
}

function GetDiskList(Path){
	var Body='';
	var LBody= '';
	var data='path='+Path + '&disk=True';
	$.post('/files?action=GetDir',data,function(rdata){

		if(rdata.DISK != undefined){
			for(var i=0; i < rdata.DISK.length; i++){
				LBody +="<dd onclick=\"GetDiskList('"+rdata.DISK[i].path+"')\"><span class='glyphicon glyphicon-hdd'></span>&nbsp;"+rdata.DISK[i].path+"</dd>";
			}
			$("#comlist").html(LBody);
		}
		for(var i=0; i < rdata.DIR.length; i++){
			var fmp = rdata.DIR[i].split(";");
			var cnametext =fmp[0];
			if(cnametext.length>20){
				cnametext = cnametext.substring(0,20)+'...'
			}
			if(isChineseChar(cnametext)){
				if(cnametext.length>10){
					cnametext = cnametext.substring(0,10)+'...'
				}
			}
			Body +="<tr>"
					+"<td onclick=\"GetDiskList('"+rdata.PATH+"/"+fmp[0]+"')\" title='"+fmp[0]+"'><span class='glyphicon glyphicon-folder-open'></span>"+cnametext+"</td>"
					+"<td>"+getLocalTime(fmp[2])+"</td>"
					+"<td>"+fmp[3]+"</td>"
					+"<td>"+fmp[4]+"</td>"
					+"<td><span class='delfile-btn' onclick=\"NewDelFile('"+rdata.PATH+'/'+fmp[0]+"')\">X</span></td>"
				 +"</tr>";
		}

		if(rdata.FILES != null && rdata.FILES !=''){
			for(var i=0; i < rdata.FILES.length; i++){
				var fmp = rdata.FILES[i].split(";");
				var cnametext =fmp[0];
				if(cnametext.length>20){
					cnametext = cnametext.substring(0,20)+'...'
				}
				if(isChineseChar(cnametext)){
					if(cnametext.length>10){
						cnametext = cnametext.substring(0,10)+'...'
					}
				}
				Body +="<tr>"
						+"<td title='"+fmp[0]+"'><span class='glyphicon glyphicon-file'></span>"+cnametext+"</td>"
						+"<td>"+getLocalTime(fmp[2])+"</td>"
						+"<td>"+fmp[3]+"</td>"
						+"<td>"+fmp[4]+"</td>"
						+"<td></td>"
					 +"</tr>";
			}
		}
		$(".default").hide();
		$(".file-list").show();
		$("#tbody").html(Body);
		if(rdata.PATH.substr(rdata.PATH.length-1,1) != '/') rdata.PATH+='/'
		$("#PathPlace").find("span").html(rdata.PATH);
		ActiveDisk();
		return;
	});
}

function CreateFolder(){
	var html = "<tr><td colspan='2'><span class='glyphicon glyphicon-folder-open'></span> <input id='newFolderName' class='newFolderName' type='text' value=''></td><td colspan='3'><button id='nameOk' type='button' class='btn btn-info btn-sm'>Submit</button>&nbsp;&nbsp;<button id='nameNOk' type='button' class='btn btn-default btn-sm'>Cancel</button></td></tr>";
	if($("#tbody tr").length==0){
		$("#tbody").append(html);
	}
	else{
		$("#tbody tr:first-child").before(html);
	}
	$(".newFolderName").focus();
	$("#nameOk").click(function(){
		var name = $("#newFolderName").val();
		var txt = $("#PathPlace").find("span").text();
		newTxt = txt.replace(new RegExp(/(\/\/)/g),'/') + name;
		var data='path=' + newTxt;
		$.post('/files?action=CreateDir',data,function(rdata){
			if(rdata.status==true){
				layer.msg(rdata.msg, {icon: 1});
			}
			else{
				layer.msg(rdata.msg, {icon: 2});
			}
			GetDiskList(txt);
		})
	})
	$("#nameNOk").click(function(){
		$(this).parents("tr").remove();
	})
}

function NewDelFile(path){
	var txt = $("#PathPlace").find("span").text();
	newTxt = path.replace(new RegExp(/(\/\/)/g),'/');
	var data='path=' + newTxt + '&empty=True';
	$.post('/files?action=DeleteDir',data,function(rdata){
		if(rdata.status==true){
			layer.msg(rdata.msg, {icon: 1});
		}
		else{
			layer.msg(rdata.msg, {icon: 2});
		}
		GetDiskList(txt);
	})
}

function ActiveDisk(){
	var active = $("#PathPlace").find("span").text().substring(0,1);
	switch(active){
		case "C":
		$(".path-con-left dd:nth-of-type(1)").css("background","#eee").siblings().removeAttr("style");
		break;
		case "D":
		$(".path-con-left dd:nth-of-type(2)").css("background","#eee").siblings().removeAttr("style");
		break;
		case "E":
		$(".path-con-left dd:nth-of-type(3)").css("background","#eee").siblings().removeAttr("style");
		break;
		case "F":
		$(".path-con-left dd:nth-of-type(4)").css("background","#eee").siblings().removeAttr("style");
		break;
		case "G":
		$(".path-con-left dd:nth-of-type(5)").css("background","#eee").siblings().removeAttr("style");
		break;
		case "H":
		$(".path-con-left dd:nth-of-type(6)").css("background","#eee").siblings().removeAttr("style");
		break;
		default:
		$(".path-con-left dd").removeAttr("style");
	}
}

function BackMyComputer(){
	$(".default").show();
	$(".file-list").hide();
	$("#PathPlace").find("span").html("");
	ActiveDisk();
}

function BackFile(){
	var tmp = $("#PathPlace").find("span").text();
	if(tmp.substr(tmp.length-1,1) == '/') tmp = tmp.substr(0,tmp.length-1);
 	var Path = tmp.split("/");
 	var back = '';
	if(Path.length>1){
	 	var count = Path.length-1;
	 	for(var i=0; i<count; i++){
	 		back += Path[i]+"/";
	 	}
	 	GetDiskList(back.replace("//","/"));
	}
	else
	{
	 	back = Path[0];
	}
	if(Path.length==1){
	 	//BackMyComputer()
	}
}

function GetfilePath(){
	var txt = $("#PathPlace").find("span").text();
	txt = txt.replace(new RegExp(/(\\)/g),'/');
	$("#"+getCookie("SetId")).val(txt);
	layer.close(getCookie('ChangePath'));
}

function VirtualDirectories(id,path){
	layer.open({
		type: 1,
		area: '620px',
		title: 'View directory',
		closeBtn: 2,
		shift: 5,
		shadeClose: false,
		content:"<div class='changepath'>\
			<div class='path-top'>\
				<button id='backPath' type='button' class='btn btn-default btn-sm' ><span class='glyphicon glyphicon-share-alt'></span> Return</button>\
				<div class='place' id='xuniPathPlace'>Current path：<span></span></div>\
			</div>\
			<div class='path-con'>\
				<div class='path-con-right' style='width:100%'>\
					<table class='table table-hover'>\
						<thead>\
							<tr class='file-list-head'>\
								<th width='60%'>Name</th>\
								<th width='15%'>Size</th>\
								<th width='25%'>Modified</th>\
							</tr>\
						</thead>\
						<tbody id='xunitbody' class='list-list'>\
						</tbody>\
					</table>\
				</div>\
			</div>\
		</div>"
	});
	GetVirtualDirectories(id,path);
	$("#backPath").click(function(){
		var path = $("#xuniPathPlace").find("span").text();
		GetVirtualDirectories(-1,path);
	})
}

function GetVirtualDirectories(id,path){
	if(path == undefined){
		path = "";
	}
	var Body = "";
	var data = "id="+id+"&path="+path;
	$.get("/Api/GetDirFormat",data,function(rdata){
		for(var i=0; i < rdata.DIR.length; i++){
			Body +="<tr><td onclick=\"GetVirtualDirectories("+rdata.DIR[i].id+",\'"+rdata.PATH+"\')\"><span class='glyphicon glyphicon-folder-open'></span>"+rdata.DIR[i].name+"</td><td>--</td><td>"+rdata.DIR[i].addtime+"</td></tr>";
		}
		for(var i=0; i < rdata.FILES.length; i++){
			Body +="<tr><td><span class='glyphicon glyphicon-file'></span>"+rdata.FILES[i].filename+"</td><td>"+(ToSize(rdata.FILES[i].filesize))+"</td><td>"+rdata.FILES[i].uptime+"</td></tr>";
		}
		$("#xunitbody").html(Body);
		$("#xuniPathPlace").find("span").text(rdata.PATH);
	});
}

function setCookie(name,value)
{
var Days = 30;
var exp = new Date();
exp.setTime(exp.getTime() + Days*24*60*60*1000);
document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}

function getCookie(name)
{
	var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
	if(arr=document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
}

function aotuHeight(){
	var McontHeight = $("body").height() - 40;
	$(".main-content").css("min-height",McontHeight);
}
$(function(){
	aotuHeight()
})
$(window).resize(function(){
	aotuHeight()
})

function showHidePwd(){
	var open = "glyphicon-eye-open",
		close = "glyphicon-eye-close";
	$(".pw-ico").click(function(){
		var $class = $(this).attr("class"),
			$prev = $(this).prev();
		if($class.indexOf(open)>0){
			var pw= $prev.attr("data-pw");
			$(this).removeClass(open).addClass(close);
			$prev.text(pw);
		}
		else{
			$(this).removeClass(close).addClass(open);
			$prev.text("**********");
		}
		var l = $(this).next().position().left;
		var t = $(this).next().position().top;
		var w = $(this).next().width();
		$(this).next().next().css({"left":l+w+"px","top":t+"px"});
	});
}

function openPath(path){
	setCookie('Path',path);
	window.location.href = '/files';
}

function OnlineEditFile(type, fileName) {
	if (type != 0) {
		var path = $("#PathPlace input").val();
		var data = encodeURIComponent($("#textBody").val());
		var encoding = $("select[name=encoding]").val();
		layer.msg('Saving...', {
			icon: 16,
			time: 0
		});
		$.post('/files?action=SaveFileBody', 'data=' + data + '&path=' + fileName+'&encoding='+encoding, function(rdata) {
			if(type == 1) layer.closeAll();
			layer.msg(rdata.msg, {
				icon: rdata.status ? 1 : 2
			});
		});
		return;
	}

	var loadT = layer.msg('Reading file...', {
		icon: 16,
		time: 0
	});
	var exts = fileName.split('.');
	var ext = exts[exts.length-1];
	var msg = 'Online editing only supports text and script files, default UTF8 encoding, do you try to open it? ';
	if(ext == 'conf' || ext == 'cnf' || ext == 'ini'){
		msg = 'What you are opening is a configuration file. If you don\'t understand the configuration rules, the configuration program may not work properly. Continue? ';
	}
	var doctype;
	switch (ext){
		case 'html':
			var mixedMode = {
				name: "htmlmixed",
				scriptTypes: [{matches: /\/x-handlebars-template|\/x-mustache/i,
							   mode: null},
							  {matches: /(text|application)\/(x-)?vb(a|script)/i,
							   mode: "vbscript"}]
			  };
			doctype = mixedMode;
			break;
		case 'htm':
			var mixedMode = {
				name: "htmlmixed",
				scriptTypes: [{matches: /\/x-handlebars-template|\/x-mustache/i,
							   mode: null},
							  {matches: /(text|application)\/(x-)?vb(a|script)/i,
							   mode: "vbscript"}]
			  };
			doctype = mixedMode;
			break;
		case 'js':
			doctype = "text/javascript";
			break;
		case 'json':
			doctype = "application/ld+json";
			break;
		case 'css':
			doctype = "text/css";
			break;
		case 'php':
			doctype = "application/x-httpd-php";
			break;
		case 'tpl':
			doctype = "application/x-httpd-php";
			break;
		case 'xml':
			doctype = "application/xml";
			break;
		case 'sql':
			doctype = "text/x-sql";
			break;
		case 'conf':
			doctype = "text/x-nginx-conf";
			break;
		default:
			var mixedMode = {
				name: "htmlmixed",
				scriptTypes: [{matches: /\/x-handlebars-template|\/x-mustache/i,
							   mode: null},
							  {matches: /(text|application)\/(x-)?vb(a|script)/i,
							   mode: "vbscript"}]
			  };
			doctype = mixedMode;
	}
	$.post('/files?action=GetFileBody', 'path=' + fileName, function(rdata) {
		layer.close(loadT);
		var encodings = ["utf-8","gbk"];
		var encoding = ''
		var opt = ''
		var val = ''
		for(var i=0;i<encodings.length;i++){
			opt = rdata.encoding == encodings[i] ? 'selected':'';
			encoding += '<option value="'+encodings[i]+'" '+opt+'>'+encodings[i]+'</option>';
		}

		var editorbox = layer.open({
			type: 1,
			shift: 5,
			closeBtn: 2,
			area: ['90%', '90%'],
			title: 'Online editing [' + fileName + ']',
			content: '<form class="zun-form-new" style="padding-top:10px">\
			<div class="line noborder">\
			<p style="color:red;margin-bottom:10px">Hint: Ctrl+F to search for keywords, Ctrl+G to find the next one, Ctrl+S to save, Ctrl+Shift+R to find replacements! \
			<select name="encoding" style="width: 74px;position: absolute;top: 11px;right: 14px;height: 22px;z-index: 9999;border-radius: 0;">'+encoding+'</select></p>\
			<textarea class="mCustomScrollbar" id="textBody" style="width:100%;margin:0 auto;line-height: 1.8;position: relative;top: 10px;" value="" />\
			</div>\
			<div class="submit-btn" style="position:absolute; bottom:0; width:100%">\
			<button type="button" class="btn btn-danger btn-sm btn-title btn-editor-close">Close</button>\
			<button id="OnlineEditFileBtn" type="button" class="btn btn-info btn-sm btn-title">Save</button>\
			</div>\
			</form>'
		});
		$("#textBody").text(rdata.data);
		//$(".layui-layer").css("top", "5%");
		var h = $(window).height()*0.9;
		$("#textBody").height(h-160);
		var editor = CodeMirror.fromTextArea(document.getElementById("textBody"), {
			extraKeys: {"Ctrl-F": "findPersistent","Ctrl-H":"replaceAll","Ctrl-S":function(){
					$("#textBody").text(editor.getValue());
					OnlineEditFile(2,fileName);
				}
			},
			mode:doctype,
			lineNumbers: true,
			matchBrackets:true,
			matchtags:true,
			autoMatchParens: true
		});
		editor.focus();
		editor.setSize('auto',h-150);
		$("#OnlineEditFileBtn").click(function(){
			$("#textBody").text(editor.getValue());
			OnlineEditFile(1,fileName);
		});
		$(".btn-editor-close").click(function(){
			layer.close(editorbox);
		})
	});
}

function ServiceAdmin(name,type){
	if(!isNaN(name)){
		name = 'php-fpm-'+name;
	}
	var data = "name="+name+"&type="+type;
	var msg = '';
	switch(type){
		case 'stop':
			msg = 'Stop';
			break;
		case 'start':
			msg = 'Start';
			break;
		case 'restart':
			msg = 'Restart';
			break;
		case 'reload':
			msg = 'Reload';
			break;
	}
	layer.confirm('Do you really want the '+msg+name+' service? ',{closeBtn:2},function(){
		var loadT = layer.msg('Being '+msg+name+' service...',{icon:16,time:0});
		$.post('/system?action=ServiceAdmin',data,function(rdata){
			layer.close(loadT);
			var reMsg =rdata.status?name+'The service has failed '+msg:name+' service '+msg+'! ';
			layer.msg(reMsg,{icon:rdata.status?1:2});

			if(type != 'reload' && rdata.status == true){
				setTimeout(function(){
					window.location.reload();
				},1000)
			}
			if(!rdata.status) layer.msg(rdata.msg,{icon:2,time:0,shade:0.3,shadeClose:true});

		}).error(function(){
			layer.close(loadT);
			layer.msg('Successful operation!',{icon:1});
		});
	});
}

function GetConfigFile(type){
	var fileName = '';
	switch(type){
		case 'mysql':
			fileName = '/etc/my.cnf';
			break;
		case 'nginx':
			fileName = '/opt/slemp/server/nginx/conf/nginx.conf';
			break;
		default:
			fileName = '/opt/slemp/server/php/'+type+'/etc/php.ini';
			break;
	}

	OnlineEditFile(0,fileName);
}

function GetPHPStatus(version){
	$.post('/ajax?action=GetPHPStatus','version='+version,function(rdata){
		layer.open({
			type:1,
			area:'400',
			title:'PHP load status',
			closeBtn:2,
			shift:5,
			shadeClose:true,
			content:"<div style='margin:15px;'><table class='table table-hover table-bordered'>\
						<tr><th>Application pool (pool)</th><td>"+rdata.pool+"</td></tr>\
						<tr><th>Process management (process manager)</th><td>"+((rdata['process manager'] == 'dynamic')?'dynamic':'static')+"</td></tr>\
						<tr><th>Start date (start time)</th><td>"+rdata['start time']+"</td></tr>\
						<tr><th>Number of requests (accepted conn)</th><td>"+rdata['accepted conn']+"</td></tr>\
						<tr><th>Request queue (listen queue)</th><td>"+rdata['listen queue']+"</td></tr>\
						<tr><th>Maximum waiting queue (max listen queue)</th><td>"+rdata['max listen queue']+"</td></tr>\
						<tr><th>Socket queue length (listen queue len)</th><td>"+rdata['listen queue len']+"</td></tr>\
						<tr><th>Number of idle processes (idle processes)</th><td>"+rdata['idle processes']+"</td></tr>\
						<tr><th>Number of active processes (active processes)</th><td>"+rdata['active processes']+"</td></tr>\
						<tr><th>Total number of processes (total processes)</th><td>"+rdata['total processes']+"</td></tr>\
						<tr><th>Maximum number of active processes (max active processes)</th><td>"+rdata['max active processes']+"</td></tr>\
						<tr><th>The maximum number of process arrivals(max children reached)</th><td>"+rdata['max children reached']+"</td></tr>\
						<tr><th>Slow request quantity(slow requests)</th><td>"+rdata['slow requests']+"</td></tr>\
					 </table></div>"
		});
	});
}

function GetNginxStatus(){
	$.post('/ajax?action=GetNginxStatus','',function(rdata){
		layer.open({
			type:1,
			area:'400',
			title:'Nginx load status',
			closeBtn:2,
			shift:5,
			shadeClose:true,
			content:"<div style='margin:15px;'><table class='table table-hover table-bordered'>\
						<tr><th>Active connection(Active connections)</th><td>"+rdata.active+"</td></tr>\
						<tr><th>Total connections(accepts)</th><td>"+rdata.accepts+"</td></tr>\
						<tr><th>Total handshake(handled)</th><td>"+rdata.handled+"</td></tr>\
						<tr><th>Total requests(requests)</th><td>"+rdata.requests+"</td></tr>\
						<tr><th>Number of requests(Reading)</th><td>"+rdata.Reading+"</td></tr>\
						<tr><th>Response number(Writing)</th><td>"+rdata.Writing+"</td></tr>\
						<tr><th>Resident process(Waiting)</th><td>"+rdata.Waiting+"</td></tr>\
					 </table></div>"
		});
	});
}

function GetNetWorkList(){
	var loadT = layer.msg('Mendapatkan data...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/ajax?action=GetNetWorkList','',function(rdata){
		layer.close(loadT);
		var tbody = ""
		for(var i=0;i<rdata.length;i++){
			tbody += "<tr>"
						+"<td>" + rdata[i].type + "</td>"
						+"<td>" + rdata[i].laddr[0]+ ":" + rdata[i].laddr[1] + "</td>"
						+"<td>" + (rdata[i].raddr.length > 1?"<a style='color:blue;' title='Blokir IP ini' href=\"javascript:dropAddress('" + rdata[i].raddr[0] + "');\">"+rdata[i].raddr[0]+"</a>:" + rdata[i].raddr[1]:'NONE') + "</td>"
						+"<td>" + rdata[i].status + "</td>"
						+"<td>" + rdata[i].process + "</td>"
						+"<td>" + rdata[i].pid + "</td>"
					+"</tr>"
		}

		layer.open({
			type:1,
			area:['650px','600px'],
			title:'Status jaringan',
			closeBtn:2,
			shift:5,
			shadeClose:true,
			content:"<div style='margin:15px;'><table class='table table-hover table-bordered'>\
						<tr>\
							<th>Jenis</th>\
							<th>IP Lokal</th>\
							<th>IP Remote</th>\
							<th>Status</th>\
							<th>Proses</th>\
							<th>PID</th>\
						</tr>\
						<tbody>"+tbody+"</tbody>\
					 </table></div>"
		});
	});
}

function GetProcessList(){
	var loadT = layer.msg('Sedang dianalisis...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/ajax?action=GetProcessList','',function(rdata){
		layer.close(loadT);
		var tbody = ""
		for(var i=0;i<rdata.length;i++){
			tbody += "<tr>"
						+"<td>" + rdata[i].pid + "</td>"
						+"<td>" + rdata[i].name + "</td>"
						+"<td>" + rdata[i].cpu_percent + "%</td>"
						+"<td>" + rdata[i].memory_percent + "%</td>"
						+"<td>" + ToSize(rdata[i].io_read_bytes) + '/' + ToSize(rdata[i].io_write_bytes) + "</td>"
						+"<td>" + rdata[i].status + "</td>"
						+"<td>" + rdata[i].threads + "</td>"
						+"<td>" + rdata[i].user + "</td>"
						+"<td><a title='End this process' style='color:red;' href=\"javascript:killProcess(" + rdata[i].pid + ",'"+rdata[i].name+"');\">Kill</a></td>"
					+"</tr>"
		}

		layer.open({
			type:1,
			area:['70%','600px'],
			title:'Manajemen proses',
			closeBtn:2,
			shift:5,
			shadeClose:true,
			content:"<div style='margin:15px;'><table class='table table-hover table-bordered'>\
						<tr>\
							<th>PID</th>\
							<th>Nama</th>\
							<th>CPU</th>\
							<th>RAM</th>\
							<th>Baca/Tulis</th>\
							<th>Status</th>\
							<th>Thread</th>\
							<th>User</th>\
							<th>Aksi</th>\
						</tr>\
						<tbody>"+tbody+"</tbody>\
					 </table></div>"
		});
	});
}

function killProcess(pid,name){
	layer.confirm('Ending the process ['+pid+']['+name+'] may affect the normal operation of the server, continue? ',{closeBtn:2},function(){
		loadT = layer.msg('Ending process...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/ajax?action=KillProcess','pid='+pid,function(rdata){
			layer.close(loadT);
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
		})
	})
}

function dropAddress(address){
	layer.confirm('After blocking this IP, the other party will not be able to access this server. You can delete it in [Security], continue? ',{closeBtn:2},function(){
		loadT = layer.msg('Blocking IP...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/firewall?action=AddDropAddress','port='+address+'&ps=Manual shielding',function(rdata){
			layer.close(loadT);
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
		})
	})
}

function divcenter(){
	$(".layui-layer").css("position","absolute");
    var dw = $(window).width();
    var ow = $(".layui-layer").outerWidth();
    var dh = $(window).height();
    var oh = $(".layui-layer").outerHeight();
    var l = (dw - ow) / 2;
    var t = (dh - oh) / 2 > 0 ? (dh - oh) / 2 : 10;
    var lDiff = $(".layui-layer").offset().left - $(".layui-layer").position().left;
    var tDiff = $(".layui-layer").offset().top - $(".layui-layer").position().top;
    l = l + $(window).scrollLeft() - lDiff;
    t = t + $(window).scrollTop() - tDiff;
    $(".layui-layer").css("left",l + "px");
    $(".layui-layer").css("top",t + "px");
}

function btcopy(){
	$(".btcopy").zclip({
		path: "/static/js/ZeroClipboard.swf",
		copy: function(){
		return $(this).attr("data-pw");
		},
		afterCopy:function(){
			if($(this).attr("data-pw") ==""){
				layer.msg("Password is empty",{icon:7,time:1500});
			}
			else
			layer.msg("Successful copy",{icon:1,time:1500});
		}
	})
}

function isChineseChar(str){
   var reg = /[\u4E00-\u9FA5\uF900-\uFA2D]/;
   return reg.test(str);
}

function SafeMessage(title,msg,success,thtml){
	if(thtml == undefined) thtml = "";
	var a = Math.round(Math.random()*9+1);
	var b = Math.round(Math.random()*9+1);
	var sum = '';
	sum = a + b;
	sumtext = a + ' + ' + b;
	setCookie("vcodesum",sum);
	layer.open({
		type: 1,
	    title: title,
	    area: '350px',
	    closeBtn: 2,
	    shadeClose: true,
	    content:"<div class='zun-form-new webDelete'>\
	    	<p>" + msg + "</p>\
	    	" + thtml + "\
			<div class='vcode'>Calculation results：<span class='text'>"+sumtext+"</span>=<input type='number' id='vcodeResult' value=''></div>\
	    	<div class='submit-btn' style='margin-top:15px'>\
				<button type='button' class='btn btn-danger btn-sm btn-title' onclick='layer.closeAll()'>Cancel</button>\
		        <button type='button' id='toSubmit' class='btn btn-info btn-sm btn-title' >Submit</button>\
	        </div>\
	    </div>"
	});


	$("#vcodeResult").focus().keyup(function(e){
		if(e.keyCode == 13) $("#toSubmit").click();
	});

	$("#toSubmit").click(function(){
		var sum = $("#vcodeResult").val().replace(/ /g,"");
		if(sum == undefined || sum ==''){
			layer.msg("Enter the calculation result, otherwise it cannot be deleted");
			return;
		}

		if(sum != getCookie("vcodesum")){
			layer.msg("Calculation error, please recalculate");
			return;
		}

		success();
	});
}
