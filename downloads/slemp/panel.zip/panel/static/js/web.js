function getWeb(page, search) {
	search = search == undefined ? '':search;
	page = page == undefined ? '1':page;
	var sUrl = '/data?action=getData'
	var pdata = 'tojs=getWeb&table=sites&limit=15&p=' + page + '&search=' + search;
	var loadT = layer.load();

	$.post(sUrl,pdata, function(data) {
		layer.close(loadT);

		var Body = '';
		for (var i = 0; i < data.data.length; i++) {

			if (data.data[i].status == 'running' || data.data[i].status == '1') {
				var status = "<a href='javascript:;' title='Deactivate this site' onclick=\"webStop(" + data.data[i].id + ",'" + data.data[i].name + "')\" class='btn-defsult'><span style='color:#3498DB;'>Running    </span><span style='color:#3498DB;' class='glyphicon glyphicon-play'></span></a>";
			} else {
				var status = "<a href='javascript:;' title='Enable this site' onclick=\"webStart(" + data.data[i].id + ",'" + data.data[i].name + "')\" class='btn-defsult'><span style='color:red;'>Stopped    </span><span style='color:red;' class='glyphicon glyphicon-pause'></span></a>";
			}

			if (data.data[i].backup_count > 0) {
				var backup = "<a href='javascript:;' class='link' onclick=\"getBackup(" + data.data[i].id + ",'" + data.data[i].name + "')\">Backup</a>";
			} else {
				var backup = "<a href='javascript:;' class='link' onclick=\"getBackup(" + data.data[i].id + ",'" + data.data[i].name + "')\">No Backup</a>";
			}

			var web_end_time = (data.data[i].due_date == "0000-00-00") ? 'permanent' : data.data[i].due_date;

			Body += "<tr><td style='display:none'><input type='checkbox' name='id' value='" + data.data[i].id + "'></td>\
					<td><a class='link webtips' href='javascript:;' onclick=\"webEdit(" + data.data[i].id + ",'" + data.data[i].name + "','" + data.data[i].due_date + "','" + data.data[i].addtime + "')\">" + data.data[i].name + "</td>\
					<td>" + status + "</td>\
					<td class='visible-lg visible-md visible-sm'>" + backup + "</td>\
					<td class='visible-lg visible-md visible-sm'><a class='link' title='open Directory' href=\"javascript:openPath('"+data.data[i].path+"');\">" + data.data[i].path + "</a></td>\
					<td class='visible-lg visible-md visible-sm'><a class='linkbed' href='javascript:;' data-id='"+data.data[i].id+"'>" + data.data[i].ps + "</a></td>\
					<td style='text-align:right; color:#bbb'>\
					<a href='javascript:;' class='link' onclick=\"webEdit(" + data.data[i].id + ",'" + data.data[i].name + "','" + data.data[i].due_date + "','" + data.data[i].addtime + "')\">Setting </a>\
                        | <a href='javascript:;' class='link' onclick=\"webDelete('" + data.data[i].id + "','" + data.data[i].name + "')\" title='Delete site'>Delete</a>\
					</td></tr>"
		}

		if(Body.length < 10){
			Body = "<tr><td colspan='6'>There is currently no site data</td></tr>";
			$(".dataTables_paginate").hide()
		}

		$("#webBody").html(Body);
		$(".btn-more").hover(function(){
			$(this).addClass("open");
		},function(){
			$(this).removeClass("open");
		});

		$("#webPage").html(data.page);

		$(".linkbed").click(function(){
			var dataid = $(this).attr("data-id");
			var databak = $(this).text();
			if(databak=="空"){
				databak='';
			}
			$(this).hide().after("<input class='baktext' type='text' data-id='"+dataid+"' name='bak' value='" + databak + "' placeholder='Description' onblur='GetBakPost(\"sites\")' />");
			$(".baktext").focus();
		});
	});
}

function webAdd(type) {
	if (type == 1) {
		var array;
		var str="";
		var domainlist='';
		var domain = array = $("#mainDomain").val().split("\n");
		var Webport=[];
		var checkDomain = domain[0].split('.');
		if(checkDomain.length < 1){
			layer.msg('The domain name is not in the correct format. Please re-enter!',{icon:2});
			return;
		}
		for(var i=1; i<domain.length; i++){
			domainlist += '"'+domain[i]+'",';
		}
		Webport = domain[0].split(":")[1];
		if(Webport==undefined){
			Webport="80";
		}
		domainlist = domainlist.substring(0,domainlist.length-1);
		domain ='{"domain":"'+domain[0]+'","domainlist":['+domainlist+'],"count":'+domain.length+'}';
		var loadT = layer.msg('Processing...',{icon:16,time:0})
		var data = $("#addweb").serialize()+"&port="+Webport+"&webname="+domain;
		$.post('/site?action=AddSite', data, function(ret) {
			if(ret.status === false){
				layer.msg(ret.msg,{icon:ret.status?1:2})
				return
			}

			var ftpData = '';
			if (ret.ftpStatus) {
				ftpData = ""
			}
			var sqlData = '';
			if (ret.databaseStatus) {
				sqlData = "<p class='p1'>Database account information</p>\
					 		<p><span>Database：</span><strong>" + ret.databaseUser + "</strong></p>\
					 		<p><span>Username：</span><strong>" + ret.databaseUser + "</strong></p>\
					 		<p><span>Password：</span><strong>" + ret.databasePass + "</strong></p>"
			}
			if (ret.siteStatus == true) {
				getWeb(1);
				layer.closeAll();
				if(ftpData == '' && sqlData == ''){
					layer.msg("Successfully created a site",{icon:1})
				}
				else{
					layer.open({
						type: 1,
						area: '600px',
						title: 'Successfully created a site',
						closeBtn:2,
						shadeClose: false,
						content: "<div class='success-msg'>\
							<div class='pic'><img src='/static/img/success-pic.png'></div>\
							<div class='suc-con'>\
								" + ftpData + sqlData + "\
							</div>\
						 </div>",
					});
					if ($(".success-msg").height() < 150) {
						$(".success-msg").find("img").css({
							"width": "150px",
							"margin-top": "30px"
						});
					}
				}

			} else {
				layer.msg(ret.msg, {
					icon: 2
				});
			}
			layer.close(loadT);
		});
		return;
	}

	$.post('/site?action=GetPHPVersion',function(rdata){
		var defaultPath = $("#defaultPath").html();
		var php_version = "<div class='line'><label><span>PHP version</span></label><select name='version' id='c_k3' style='width:100px'>";
		for(var i=rdata.length-1;i>=0;i--){
            php_version += "<option value='"+rdata[i].version+"'>"+rdata[i].name+"</option>";
        }
		php_version += "</select></div>";
		layer.open({
			type: 1,
			skin: 'demo-class',
			area: '560px',
			title: 'Add website',
			closeBtn: 2,
			shift: 0,
			shadeClose: false,
			content: "<form class='zun-form-new' id='addweb'>\
						<div class='line'>\
		                    <label><span>Domain</span></label>\
		                    <div class='info-r'>\
								<textarea id='mainDomain' name='webname' style='width:398px;line-height:22px' /></textarea>\
								<a href='#' class='btn btn-default btn-xs btn-zhm'>Transcoding</a>\
							</div>\
						</div>\
	                    <div class='line'>\
	                    <label><span>Description</span></label>\
	                    <div class='info-r'>\
	                    	<input id='Wbeizhu' type='text' name='ps' placeholder='Website note' style='width:398px' />\
	                    </div>\
	                    </div>\
	                    <div class='line'>\
	                    <label><span>Directory</span></label>\
	                    <div class='info-r'>\
	                    	<input id='inputPath' type='text' name='path' value='"+defaultPath+"/' placeholder='Website root directory' style='width:398px' /><span class='glyphicon glyphicon-folder-open cursor' onclick='ChangePath(\"inputPath\")'></span>\
	                    </div>\
	                    </div>\
	                    <div class='line'>\
	                    <label><span>Database</span></label>\
		                    <select name='sql' id='c_k2' style='width:100px'>\
		                    	<option value='true'>MySQL</option>\
		                    	<option value='false' selected>Not created</option>\
		                    </select>\
		                    <select name='codeing' id='c_codeing' style='width:100px'>\
		                    	<option value='utf8'>utf-8</option>\
		                    	<option value='utf8mb4'>utf8mb4</option>\
								<option value='gbk'>gbk</option>\
								<option value='big5'>big5</option>\
		                    </select>\
	                    </div>\
	                    <div class='line' id='datass'>\
	                    <label><span></span></label>\
	                    <div class='info-r'>\
		                    <div class='userpassword'><span>Username：<input id='data-user' type='text' name='datauser' value=''  style='width:100px' /></span>\
		                    <span class='last'>Password：<input id='data-password' type='text' name='datapassword' value=''  style='width:100px' /></span></div>\
		                    <p>While creating the site, create a corresponding database account for the site to facilitate different databases using different databases.</p>\
	                    </div>\
	                    </div>\
						"+php_version+"\
	                    <div class='submit-btn'>\
							<button type='button' class='btn btn-danger btn-sm btn-title' onclick='layer.closeAll()'>Cancel</button>\
							<button type='button' class='btn btn-info btn-sm btn-title' onclick=\"webAdd(1)\">Submit</button>\
						</div>\
	                  </form>",
		});
		$(function() {
			var placeholder = "<div class='placeholder' style='top:10px;left:10px'>Fill in a domain name per line, the default is 80 port<br>General resolution add method *.domain.com<br>If the port format is www.domain.com:88</div>";
			$('#mainDomain').after(placeholder);
			$(".placeholder").click(function(){
				$(this).hide();
				$('#mainDomain').focus();
			})
			$('#mainDomain').focus(function() {
			    $(".placeholder").hide();
			});

			$('#mainDomain').blur(function() {
				if($(this).val().length==0){
					$(".placeholder").show();
				}
			});

			$('#mainDomain').on('input', function() {
				var array;
				var res,ress;
				var str = $(this).val();
				var len = str.replace(/[^\x00-\xff]/g, "**").length;
				array = str.split("\n");
				ress =array[0].split(":")[0];
				res = ress.replace(new RegExp(/([-.])/g), '_');
				if(res.length > 15) res = res.substr(0,15);
				if($("#inputPath").val().substr(0,defaultPath.length) == defaultPath) $("#inputPath").val(defaultPath+'/'+ress);
				if(!isNaN(res.substr(0,1))) res = "sql"+res;
				if(res.length > 15) res = res.substr(0,15);
				$("#Wbeizhu").val(ress);
				$("#ftp-user").val(res);
				$("#data-user").val(res);
				if(isChineseChar(str)) $('.btn-zhm').show();
				else $('.btn-zhm').hide();
			})
			$('#Wbeizhu').on('input', function() {
				var str = $(this).val();
				var len = str.replace(/[^\x00-\xff]/g, "**").length;
				if (len > 20) {
					str = str.substring(0, 20);
					$(this).val(str);
					layer.msg('Do not exceed 20 characters', {
						icon: 0
					});
				}
			})

			var timestamp = new Date().getTime().toString();
			var dtpw = timestamp.substring(7);
			$("#data-user").val("sql" + dtpw);


			function _getRandomString(len) {
				len = len || 32;
				var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
				var maxPos = $chars.length;
				var pwd = '';
				for (i = 0; i < len; i++) {
					pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
				}
				return pwd;
			}
			$("#ftp-password").val(_getRandomString(10));
			$("#data-password").val(_getRandomString(10));


			$("#ftpss,#datass").hide();

			$("#c_k1").change(function() {
					var val = $("#c_k1").val();
					if (val == 'false') {
						$("#ftp-user").attr("disabled", true);
						$("#ftp-password").attr("disabled", true);
						$("#ftpss").hide();
					} else {
						$("#ftp-user").attr("disabled", false);
						$("#ftp-password").attr("disabled", false);
						$("#ftpss").show();
					}
				})

			$("#c_k2").change(function() {
				var val = $("#c_k2").val();
				if (val == 'false') {
					$("#data-user").attr("disabled", true);
					$("#data-password").attr("disabled", true);
					$("#datass").hide();
				} else {
					$("#data-user").attr("disabled", false);
					$("#data-password").attr("disabled", false);
					$("#datass").show();
				}
			});
		});
	});
}

function webPathEdit(id){
	$.post("/data?action=getKey","table=sites&key=path&id="+id,function(rdata){
		$.post('/site?action=GetDirUserINI','path='+rdata+'&id='+id,function(userini){
			var userinicheckeds = userini.userini?'checked':'';
			var logscheckeds = userini.logs?'checked':'';
			var opt = ''
			var selected = '';
			for(var i=0;i<userini.runPath.dirs.length;i++){
				selected = '';
				if(userini.runPath.dirs[i] == userini.runPath.runPath) selected = 'selected';
				opt += '<option value="'+ userini.runPath.dirs[i] +'" '+selected+'>'+ userini.runPath.dirs[i] +'</option>'
			}
			var webPathHtml = "<div class='webEdit-box padding-10'>\
						<div>\
							<input type='checkbox' name='userini' id='userini'"+userinicheckeds+" /><label for='userini' style='font-weight:normal'>Anti-cross-site attack</label>\
							<input type='checkbox' name='logs' id='logs'"+logscheckeds+" /><label for='logs' style='font-weight:normal'>Write access log</label>\
						</div>\
						<div class='line' style='margin-top:5px'>\
							<input type='text' style='width:80%' placeholder='Website root directory' value='"+rdata+"' name='webdir' id='inputPath'>\
							<span onclick='ChangePath(&quot;inputPath&quot;)' class='glyphicon glyphicon-folder-open cursor'></span>\
						</div>\
						<button class='btn btn-info btn-sm' onclick='SetSitePath("+id+")'>Save</button>\
						<div class='line' style='margin-top:5px'>\
							<span>Running directory</span>\
							<select type='text' style='width:30%;margin: 5px;' name='runPath' id='runPath'>"+opt+"</select>\
							<button class='btn btn-info btn-sm' onclick='SetSiteRunPath("+id+")' style='margin-top: -4px;'>Save</button>\
							<ul class='help-info-text'>\
								<li>The running directory of some programs is not in the root directory, you need to specify the secondary directory as the running directory, such as ThinkPHP5, Laravel</li>\
								<li>Select your running directory, click Save</li>\
							</ul>\
						</div>\
					</div>";
			$("#webEdit-con").html(webPathHtml);

			$("#userini").change(function(){
				$.post('/site?action=SetDirUserINI','path='+rdata,function(userini){
					layer.msg(userini.msg,{icon:userini.status?1:2});
				});
			});

			$("#logs").change(function(){
				$.post('/site?action=logsOpen','id='+id,function(userini){
					layer.msg(userini.msg,{icon:userini.status?1:2});
				});
			});

		});
	});
}

function SetSiteRunPath(id){
	var NewPath = $("#runPath").val();
	var loadT = layer.msg('Executing, please wait...',{icon:16,time:10000,shade: [0.3, '#000']});
	$.post('/site?action=SetSiteRunPath','id='+id+'&runPath='+NewPath,function(rdata){
		layer.close(loadT);
		var ico = rdata.status?1:2;
		layer.msg(rdata.msg,{icon:ico});
	});
}

function SetSitePath(id){
	var NewPath = $("#inputPath").val();
	var loadT = layer.msg('Executing, please wait...',{icon:16,time:10000,shade: [0.3, '#000']});
	$.post('/site?action=SetPath','id='+id+'&path='+NewPath,function(rdata){
		layer.close(loadT);
		var ico = rdata.status?1:2;
		layer.msg(rdata.msg,{icon:ico});
	});
}


function webBakEdit(id){
	$.post("/data?action=getKey','table=sites&key=ps&id="+id,function(rdata){
		var webBakHtml = "<div class='webEdit-box padding-10'>\
					<div class='line'>\
					<label><span>Website note</span></label>\
					<div class='info-r'>\
					<textarea name='beizhu' id='webbeizhu' col='5' style='width:96%'>"+rdata+"</textarea>\
					<br><br><button class='btn btn-info btn-sm' onclick='SetSitePs("+id+")'>Save</button>\
					</div>\
					</div>";
		$("#webEdit-con").html(webBakHtml)
	});
}

function SetSitePs(id){
	var myPs = $("#webbeizhu").val();
	$.post('/data?action=setPs','table=sites&id='+id+'&ps='+myPs,function(rdata){
		layer.msg(rdata?"Successfully modified":"No need to modify",{icon:rdata?1:2});
	});
}

function SetIndexEdit(id){
	$.post('/site?action=GetIndex','id='+id,function(rdata){
		rdata= rdata.replace(new RegExp(/(,)/g), "\n");
		var setIndexHtml = "<div class='webEdit-box padding-10'><form id='SetIndex'><div class='SetIndex'>\
				<div class='line'>\
						<textarea id='Dindex' name='files' style='margin-top: 2px; margin-bottom: 0px; height: 186px; width:50%; line-height:20px'>"+rdata+"</textarea>\
						<p style='line-height: 26px; color: #666'>The default document, one per line, has a priority from top to bottom. </p>\
						</br><button type='button' class='btn btn-info btn-sm' onclick='SetIndexList("+id+")'>Save</button>\
				</div>\
				</div></form></div>";
		$("#webEdit-con").html(setIndexHtml);
	});

}

function webStop(wid, wname) {
	layer.confirm('Once the site is deactivated, it will be inaccessible. Do you really want to disable this site?', {closeBtn:2},function(index) {
		if (index > 0) {
			var loadT = layer.load()
			$.post("/site?action=SiteStop","id=" + wid + "&name=" + wname, function(ret) {
				layer.msg(ret.msg,{icon:ret.status?1:2})
				layer.close(loadT);
				getWeb(1);

			});
		}
	});
}

function webStart(wid, wname) {
	layer.confirm('The site is about to start, do you really want to enable this site?',{closeBtn:2}, function(index) {
		if (index > 0) {
			var loadT = layer.load()
			$.post("/site?action=SiteStart","id=" + wid + "&name=" + wname, function(ret) {
				layer.msg(ret.msg,{icon:ret.status?1:2})
				layer.close(loadT);
				getWeb(1);
			});
		}
	});
}

function webDelete(wid, wname){
	var thtml = "<div class='options'>\
	    	<label><input type='checkbox' id='deldata' name='data'><span>Database</span></label>\
	    	<label><input type='checkbox' id='delpath' name='path'><span>Directory</span></label>\
	    	</div>";
	SafeMessage("Delete site ["+wname+"]"," Whether to delete the same name, database, root directory",function(){
		var ftp='',data='',path='';
		if($("#delftp").is(":checked")){
			ftp='&ftp=1';
		}
		if($("#deldata").is(":checked")){
			data='&data=1';
		}
		if($("#delpath").is(":checked")){
			path='&path=1';
		}
		var loadT = layer.msg('Executing, please wait...',{icon:16,time:10000,shade: [0.3, '#000']});
		$.post("/site?action=DeleteSite","id=" + wid + "&webname=" + wname+ftp+data+path, function(ret){
			layer.closeAll();
			layer.msg(ret.msg,{icon:ret.status?1:2})
			getWeb(1);
		});
	},thtml);
}

function DomainEdit(id, name,msg,status) {
	$.get('/data?action=getData&table=domain&list=True&search=' + id, function(domain) {
		var echoHtml = "";
		for (var i = 0; i < domain.length; i++) {
			echoHtml += "<tr><td><a title='Click to visit' target='_blank' href='http://" + domain[i].name + ":" + domain[i].port + "' class='linkbed'>" + domain[i].name + "</a></td><td><a class='linkbed'>" + domain[i].port + "</a></td><td class='text-center'><a class='table-btn-del' href='javascript:;' onclick=\"delDomain(" + id + ",'" + name + "','" + domain[i].name + "','" + domain[i].port + "',1)\"><span class='glyphicon glyphicon-trash'></span></a></td></tr>";
		}
		var bodyHtml = "<div class='webEdit-box padding-10' style='display:block'>\
							<div class='divtable'>\
								<textarea id='newdomain'></textarea>\
								<a href='#' class='btn btn-default btn-xs btn-zhm' style='top:22px;right:154px'>Transcoding</a>\
								<input type='hidden' id='newport' value='80' />\
								<button type='button' class='btn btn-info btn-sm pull-right' style='margin:30px 35px 0 0' onclick=\"DomainAdd(" + id + ",'" + name + "',1)\">Add</button>\
								<table class='table table-hover' width='100%' style='margin-bottom:0'>\
								<thead><tr><th>Domain</th><th width='70px'>Port</th><th width='50px' class='text-center'>Action</th></tr></thead>\
								<tbody id='checkDomain'>" + echoHtml + "</tbody>\
								</table>\
							</div>\
						</div>";
		$("#webEdit-con").html(bodyHtml);
		if(msg != undefined){
			layer.msg(msg,{icon:status?1:5});
		}
		var placeholder = "<div class='placeholder'>Fill in a domain name per line, the default is 80 port<br>General resolution add method *.domain.com<br>If the port format is www.domain.com:88</div>";
		$('#newdomain').after(placeholder);
		$(".placeholder").click(function(){
			$(this).hide();
			$('#newdomain').focus();
		})
		$('#newdomain').focus(function() {
		    $(".placeholder").hide();
		});

		$('#newdomain').blur(function() {
			if($(this).val().length==0){
				$(".placeholder").show();
			}
		});
		$("#newdomain").on("input",function(){
			var str = $(this).val();
			if(isChineseChar(str)) $('.btn-zhm').show();
			else $('.btn-zhm').hide();
		})
		//checkDomain();
	});
}

function DomainRoot(id, name,msg) {
	$.get('/data?action=getData&table=domain&list=True&search=' + id, function(domain) {
		var echoHtml = "";
		for (var i = 0; i < domain.length; i++) {
			echoHtml += "<tr><td><a title='Click to visit' target='_blank' href='http://" + domain[i].name + ":" + domain[i].port + "' class='linkbed'>" + domain[i].name + "</a></td><td><a class='linkbed'>" + domain[i].port + "</a></td><td class='text-center'><a class='table-btn-del' href='javascript:;' onclick=\"delDomain(" + id + ",'" + name + "','" + domain[i].name + "','" + domain[i].port + "',1)\"><span class='glyphicon glyphicon-trash'></span></a></td></tr>";
		}
		var index = layer.open({
			type: 1,
			skin: 'demo-class',
			area: '450px',
			title: 'Domain management',
			closeBtn: 2,
			shift: 0,
			shadeClose: true,
			content: "<div class='divtable padding-10'>\
						<textarea id='newdomain'></textarea>\
						<a href='#' class='btn btn-default btn-xs btn-zhm' style='top:22px;right:154px'>Transcoding</a>\
						<input type='hidden' id='newport' value='80' />\
						<button type='button' class='btn btn-info btn-sm pull-right' style='margin:30px 35px 0 0' onclick=\"DomainAdd(" + id + ",'" + name + "')\">Add</button>\
						<table class='table table-hover' width='100%' style='margin-bottom:0'>\
						<thead><tr><th>Domain</th><th width='70px'>Port</th><th width='50px' class='text-center'>Action</th></tr></thead>\
						<tbody id='checkDomain'>" + echoHtml + "</tbody>\
						</table></div>"
		});
		if(msg != undefined){
			layer.msg(msg,{icon:1});
		}
		var placeholder = "<div class='placeholder'>Fill in a domain name per line, the default is 80 port<br>General resolution add method *.domain.com<br>If the port format is www.domain.com:88</div>";
		$('#newdomain').after(placeholder);
		$(".placeholder").click(function(){
			$(this).hide();
			$('#newdomain').focus();
		})
		$('#newdomain').focus(function() {
		    $(".placeholder").hide();
		});

		$('#newdomain').blur(function() {
			if($(this).val().length==0){
				$(".placeholder").show();
			}
		});
		$("#newdomain").on("input",function(){
			var str = $(this).val();
			if(isChineseChar(str)) $('.btn-zhm').show();
			else $('.btn-zhm').hide();
		})
		//checkDomain();
	});
}

function cancelSend(){
	$(".changeDomain,.changePort").hide().prev().show();
	$(".changeDomain,.changePort").remove();
}

function checkDomain() {
	$("#checkDomain tr").each(function() {
		var $this = $(this);
		var domain = $(this).find("td:first-child").text();
		$(this).find("td:first-child").append("<i class='lading'></i>");
		checkDomainWebsize($this,domain);
	})
}

function checkDomainWebsize(obj,domain){
	var gurl = "http://api.zun.gd/ipaddess"
	var ip = getCookie('iplist');
	var data = "domain=" + domain+"&ip="+ip;
	$.ajax({ url: gurl,data:data,type:"get",dataType:"jsonp",async:true ,success: function(rdata){
		obj.find("td:first-child").find(".lading").remove();
		if (rdata.code == -1) {
			obj.find("td:first-child").append("<i class='yf' data-title='The domain name is not resolved'>Unresolved</i>");
		} else {
			obj.find("td:first-child").append("<i class='f' data-title='The domain name resolution IP is：" + rdata.data.ip + "<br>Current server IP：" + rdata.data.main_ip + "(仅供参考,Users who use CDN please ignore)'>Parsed</i>");
		}

		obj.find("i").mouseover(function() {
			var tipsTitle = $(this).attr("data-title");
			layer.tips(tipsTitle, this, {
				tips: [1, '#3c8dbc'],
				time: 0
			})
		})
		obj.find("i").mouseout(function() {
			$(".layui-layer-tips").remove();
		})
	}})
}

function DomainAdd(id, webname,type) {
	var Domain = $("#newdomain").val().split("\n");

	var domainlist="";
	for(var i=0; i<Domain.length; i++){
		domainlist += Domain[i]+",";
	}

	if(domainlist.length < 3){
		layer.msg('Domain name cannot be empty!',{icon:5});
		return;
	}
	domainlist = domainlist.substring(0,domainlist.length-1);
	var loadT = layer.load();
	var data = "domain=" + domainlist + "&webname=" + webname + "&id=" + id;
	$.post('/site?action=AddDomain', data, function(retuls) {
		layer.close(loadT);
		DomainEdit(id,webname,retuls.msg,retuls.status);
	});
}

function delDomain(wid, wname, domain, port,type) {
	var num = $("#checkDomain").find("tr").length;
	if(num==1){
		layer.msg('The last domain name cannot be deleted!');
	}
	layer.confirm('Do you really want to remove this domain from the site? ',{closeBtn:2}, function(index) {
			var url = "/site?action=DelDomain"
			var data = "id=" + wid + "&webname=" + wname + "&domain=" + domain + "&port=" + port;
			var loadT = layer.msg('Deleting...',{time:0,icon:16});
			$.post(url,data, function(ret) {
				layer.close(loadT);
				layer.msg(ret.msg,{icon:ret.status?1:2})
				if(type == 1){
					layer.close(loadT);
					DomainEdit(wid,wname)
				}else{
					layer.closeAll();
					DomainRoot(wid, wname);
				}
			});
	});
}

function IsDomain(domain) {
		//domain = 'http://'+domain;
		var re = new RegExp();
		re.compile("^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_%&\?\/.=]+$");
		if (re.test(domain)) {
			return (true);
		} else {
			return (false);
		}
	}

function WebBackup(id, name) {
		var loadT =layer.msg('Backup, please wait...', {icon:16,time:0,shade: [0.3, '#000']});
		var data = "id="+id;
		$.post('/site?action=ToBackup', data, function(rdata) {
			layer.closeAll();
			layer.msg(rdata.msg,{icon:rdata.status?1:2})
			getBackup(id);
		});
}

function WebBackupDelete(id,pid){
	layer.confirm('Really want to delete the backup package??',{title:'Delete backup file',closeBtn:2},function(index){
		var loadT =layer.msg('Deleting, please wait...', {icon:16,time:0,shade: [0.3, '#000']});
		$.post('/site?action=DelBackup','id='+id, function(rdata){
			layer.closeAll();
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
			getBackup(pid);
		});
	})
}

function getBackup(id,name,page) {
	if(page == undefined){
		page = '1';
	}
	$.post('/data?action=getFind','table=sites&id=' + id, function(rdata) {
		$.post('/data?action=getData','table=backup&search=' + id + '&limit=5&p='+page+'&type=0&tojs=getBackup',function(frdata){

			var body = '';
				for (var i = 0; i < frdata.data.length; i++) {
					if(frdata.data[i].type == '1') continue;
					if(frdata.data[i].filename.length < 15){
						var ftpdown = "<a class='link' href='/cloud?filename="+frdata.data[i].filename+"&name="+ frdata.data[i].name+"' target='_blank'>Download</a> | ";
					}else{
						var ftpdown = "<a class='link' href='/download?filename="+frdata.data[i].filename+"&name="+frdata.data[i].name+"' target='_blank'>Download</a> | ";
					}
					body += "<tr><td><span class='glyphicon glyphicon-file'></span>"+frdata.data[i].name+"</td>\
							<td>" + (ToSize(frdata.data[i].size)) + "</td>\
							<td>" + frdata.data[i].addtime + "</td>\
							<td class='text-right' style='color:#ccc'>"+ ftpdown + "<a class='link' href='javascript:;' onclick=\"WebBackupDelete('" + frdata.data[i].id + "',"+id+")\">Delete</a></td>\
						</tr>"
				}
			var ftpdown = '';
			frdata.page = frdata.page.replace(/'/g,'"').replace(/getBackup\(/g,"getBackup(" + id + ",0,");

			if(name == 0){
				var sBody = "<table width='100%' id='WebBackupList' class='table table-hover'>\
							<thead><tr><th>File name</th><th>File size</th><th>Backup time</th><th width='140px' class='text-right'>Action</th></tr></thead>\
							<tbody id='WebBackupBody' class='list-list'>"+body+"</tbody>\
							</table>"
				$("#WebBackupList").html(sBody);
				$(".page").html(frdata.page);
				return;
			}
			layer.closeAll();
			layer.open({
				type: 1,
				skin: 'demo-class',
				area: '700px',
				title: 'Backup',
				closeBtn: 2,
				shift: 0,
				shadeClose: false,
				content: "<form class='zun-form' id='WebBackup' style='max-width:98%'>\
							<button class='btn btn-default btn-sm' style='margin-right:10px' type='button' onclick=\"WebBackup('" + rdata.id + "','" + rdata.name + "')\">Backup</button>\
							</form>\
							<div class='divtable' style='margin:17px'><table width='100%' id='WebBackupList' class='table table-hover'>\
							<thead><tr><th>File name</th><th>File size</th><th>Backup time</th><th width='140px' class='text-right'>Action</th></tr></thead>\
							<tbody id='WebBackupBody' class='list-list'>"+body+"</tbody>\
							</table><div class='page'>"+frdata.page+"</div></div>"
			});
		});

	});

}

function goSet(num) {

	var el = document.getElementsByTagName('input');
	var len = el.length;
	var data = '';
	var a = '';
	var count = 0;

	for (var i = 0; i < len; i++) {
		if (el[i].checked == true && el[i].value != 'on') {
			data += a + count + '=' + el[i].value;
			a = '&';
			count++;
		}
	}

	if(num==1){
		reAdd(data);
	}
	else if(num==2){
		shift(data);
	}
}
