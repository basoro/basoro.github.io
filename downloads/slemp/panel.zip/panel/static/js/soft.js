function phpSoftMain(name,key){
	if(!isNaN(name)){
		var nametext = "php"+name;
		name = name.replace(".","");
	}

	var loadT = layer.msg('Processing, please wait..',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/plugin?action=getPluginInfo&name=php',function(rdata){
		layer.close(loadT);
		nameA = rdata.versions[key];
		bodys = [
				'<span class="on" onclick="javascript:service(\''+name+'\','+nameA.run+')">Service</span>',
				'<span onclick="phpUploadLimit(\''+name+'\','+nameA.max+')">Upload</span>',
				'<span onclick="phpTimeLimit(\''+name+'\','+nameA.maxTime+')">Timeout</span>',
				'<span onclick="configChange(\''+name+'\')">Config</span>',
				'<span onclick="SetPHPConfig(\''+name+'\','+nameA.pathinfo+')">Ext</span>',
				'<span onclick="disFun(\''+name+'\')">Disabled</span>',
				'<span onclick="SetFpmConfig(\''+name+'\')">FPM</span>',
				'<span onclick="GetPHPStatus(\''+name+'\')">Status</span>',
				'<span onclick="BtPhpinfo(\''+name+'\')">Info</span>'
		]

		var sdata = '';
		if(rdata.phpSort == false){
			rdata.phpSort = [0,1,2,3,4,5,6,7,8];
		}else{
			rdata.phpSort = rdata.phpSort.split('|');
		}
		for(var i=0;i<rdata.phpSort.length;i++){
			sdata += bodys[rdata.phpSort[i]];
		}

		layer.open({
			type: 1,
			area: '710px',
			title: nametext+' management',
			closeBtn: 2,
			shift: 0,
			content: '<div class="tasklist" style="width:710px;height:480px;">\
				<input name="softMenuSortOrder" type="hidden" />\
				<div class="tab-nav">\
					'+sdata+'\
				</div>\
				<div id="webEdit-con" class="tab-con">\
					<div class="soft-man-con"></div>\
				</div>\
			</div>'
		})
		service(name,nameA.run);
		$(".tab-nav span").click(function(){
			//var txt = $(this).text();
			//$(this).parent().addClass("on").siblings().removeClass("on");
            $(this).addClass("on").siblings().removeClass("on");
			//if(txt != "Extended configuration") $(".soft-man-con").removeAttr("style");
		});
		//$(".soft-man-menu").dragsort({dragSelector: ".spanmove", dragEnd: MenusaveOrder});
	});
}

function MenusaveOrder() {
	var data = $(".soft-man-menu > p").map(function() { return $(this).attr("data-id"); }).get();
	var ssort = data.join("|");
	$("input[name=softMenuSortOrder]").val(ssort);
	$.post('/ajax?action=phpSort','ssort='+ssort,function(){});
};

function service(name,status){
	if(status == 'false') status = false;
	if(status == 'true') status = true;

	var serviceCon ='<p class="status">Current status:<span>'+(status?'Open':'Shut down')+'</span><span style="color: '+(status?'#3498DB;':'red;')+' margin-left: 3px;" class="glyphicon '+(status?'glyphicon glyphicon-play':'glyphicon-pause')+'"></span></p>\
					<div class="sfm-opt">\
						<button class="btn btn-default btn-sm" onclick="ServiceAdmin(\''+name+'\',\''+(status?'stop':'start')+'\')">'+(status?'Stop':'Start up')+'</button>\
						<button class="btn btn-default btn-sm" onclick="ServiceAdmin(\''+name+'\',\'restart\')">Restart</button>\
						<button class="btn btn-default btn-sm" onclick="ServiceAdmin(\''+name+'\',\'reload\')">Reload</button>\
					</div>';
	$(".soft-man-con").html(serviceCon);
}

function updateSoftList(){
	loadT = layer.msg('Getting data from the cloud, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/plugin?action=getCloudPlugin',function(rdata){
		layer.close(loadT);
		GetSList();
		layer.msg(rdata.msg,{icon:rdata.status?1:1});
	});
}

function phpUploadLimit(version,max){
	var LimitCon = '<p class="conf_p"><input class="phpUploadLimit" type="number" value="'+max+'" name="max">MB</p><button class="btn btn-info btn-sm" onclick="SetPHPMaxSize(\''+version+'\')">Submit</button>';
	$(".soft-man-con").html(LimitCon);
}
function phpTimeLimit(version,max){
	var LimitCon = '<p class="conf_p"><input class="phpTimeLimit" type="number" value="'+max+'">second</p><button class="btn btn-info btn-sm" onclick="SetPHPMaxTime(\''+version+'\')">Submit</button>';
	$(".soft-man-con").html(LimitCon);
}
function SetPHPMaxTime(version){
	var max = $(".phpTimeLimit").val();
	var loadT = layer.msg('Saving data...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=setPHPMaxTime','version='+version+'&time='+max,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	})
}
function SetPHPMaxSize(version){
	max = $(".phpUploadLimit").val();
	if(max < 2){
		alert(max);
		layer.msg('Upload size limit cannot be less than 2M',{icon:2});
		return;
	}
	var loadT = layer.msg('Saving data...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=setPHPMaxSize','&version='+version+'&max='+max,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	})
}

function configChange(type){
	var con = '<p style="color: #666; margin-bottom: 7px">Hint: Ctrl+F search keyword, Ctrl+G find next, Ctrl+S save, Ctrl+Shift+R find replace</p><textarea style="height: 320px; line-height:18px;" id="textBody"></textarea>\
					<button id="OnlineEditFileBtn" class="btn btn-info btn-sm" style="margin-top:10px;">Submit</button>';
	$(".soft-man-con").html(con);
	var fileName = '';
	switch(type){
		case 'mysqld':
			fileName = '/etc/my.cnf';
			break;
		case 'nginx':
			fileName = '/opt/slemp/server/nginx/conf/nginx.conf';
			break;
		default:
			fileName = '/opt/slemp/server/php/'+type+'/etc/php.ini';
			break;
	}
	var loadT = layer.msg("Loading...",{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/files?action=GetFileBody', 'path=' + fileName, function(rdata) {
		layer.close(loadT);
		$("#textBody").empty().text(rdata.data);
		$(".CodeMirror").remove();
		var editor = CodeMirror.fromTextArea(document.getElementById("textBody"), {
			extraKeys: {"Ctrl-Space": "autocomplete"},
			lineNumbers: true,
			matchBrackets:true,
		});
		editor.focus();
		$(".CodeMirror-scroll").css({"height":"300px","margin":0,"padding":0});
		$("#OnlineEditFileBtn").click(function(){
			$("#textBody").text(editor.getValue());
			confSafe(fileName);
		})
	})
}

function confSafe(fileName){
	var data = encodeURIComponent($("#textBody").val());
	var encoding = 'utf-8';
	var loadT = layer.msg('Saving...', {
		icon: 16,
		time: 0
	});
	$.post('/files?action=SaveFileBody', 'data=' + data + '&path=' + fileName+'&encoding='+encoding, function(rdata) {
		layer.close(loadT);
		layer.msg(rdata.msg, {
			icon: rdata.status ? 1 : 2
		});
	});
}

function SetPathInfo(version,type){
	var loadT = layer.msg('Processing..',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=setPathInfo','version='+version+'&type='+type,function(rdata){
		var pathinfo = (type == 'on')?true:false;
		var pathinfoOpt = '<a style="color:red;" href="javascript:SetPathInfo(\''+version+'\',\'off\');">Close</a>'
		if(!pathinfo){
			pathinfoOpt = '<a class="link" href="javascript:SetPathInfo(\''+version+'\',\'on\');">Open</a>'
		}
		var pathinfo1 = '<td>PATH_INFO</td><td>Extension</td><td>MVC architecture program needs to be turned on, such as typecho</td><td><span class="ico-'+(pathinfo?'start':'stop')+' glyphicon glyphicon-'+(pathinfo?'ok':'remove')+'"></span></td><td style="text-align: right;" width="50">'+pathinfoOpt+'</td>';
		$("#pathInfo").html(pathinfo1);
		$(".webEdit-menu .active").attr('onclick',"SetPHPConfig('71',"+pathinfo+")");
		layer.msg(rdata.msg,{icon:1});
	})
}

function SetPHPConfig(version,pathinfo,go){
	$.get('/ajax?action=GetPHPConfig&version='+version,function(rdata){
		var body  = ""
		var opt = ""
		for(var i=0;i<rdata.libs.length;i++){
			if(rdata.libs[i].versions.indexOf(version) == -1) continue;

			if(rdata.libs[i]['task'] == '-1' && rdata.libs[i].phpversions.indexOf(version) != -1){
				opt = '<a style="color:#3498DB;" href="javascript:task();">Menginstal..</a>'
			}else if(rdata.libs[i]['task'] == '0' && rdata.libs[i].phpversions.indexOf(version) != -1){
				opt = '<a style="color:#C0C0C0;" href="javascript:task();">Menunggu instalasi..</a>'
			}else if(rdata.libs[i].status){
				opt = '<a style="color:red;" href="javascript:UninstallPHPLib(\''+version+'\',\''+rdata.libs[i].name+'\',\''+rdata.libs[i].title+'\');">Lepas</a>'
			}else{
				opt = '<a class="link" href="javascript:InstallPHPLib(\''+version+'\',\''+rdata.libs[i].name+'\',\''+rdata.libs[i].title+'\');">Pasang</a>'
			}

			body += '<tr>'
						+'<td>'+rdata.libs[i].name+'</td>'
						+'<td>'+rdata.libs[i].type+'</td>'
						+'<td>'+rdata.libs[i].msg+'</td>'
						+'<td><span class="ico-'+(rdata.libs[i].status?'start':'stop')+' glyphicon glyphicon-'+(rdata.libs[i].status?'ok':'remove')+'"></span></td>'
						+'<td style="text-align: right;">'+opt+'</td>'
				   +'</tr>'
		}

		var pathinfoOpt = '<a style="color:red;" href="javascript:SetPathInfo(\''+version+'\',\'off\');">Close</a>'
		if(!pathinfo){
			pathinfoOpt = '<a class="link" href="javascript:SetPathInfo(\''+version+'\',\'on\');">Open</a>'
		}
		var pathinfo1 = '<tr id="pathInfo"><td>PATH_INFO</td><td>Extension</td><td>The MVC architecture program needs to be started, such as typecho</td><td><span class="ico-'+(pathinfo?'start':'stop')+' glyphicon glyphicon-'+(pathinfo?'ok':'remove')+'"></span></td><td style="text-align: right;" width="50">'+pathinfoOpt+'</td></tr>';
		var con='<div class="divtable" style="margin-right:10px">'
					+'<table class="table table-hover" width="100%" cellspacing="0" cellpadding="0" border="0">'
						+'<thead>'
							+'<tr>'
								+'<th>Name</th>'
								+'<th>Types</th>'
								+'<th>Description</th>'
								+'<th width="40">Status</th>'
								+'<th style="text-align: right;" width="50">Action</th>'
							+'</tr>'
						+'</thead>'
						+'<tbody>'+pathinfo1+body+'</tbody>'
					+'</table>'
				+'</div>';
		$(".soft-man-con").html(con).css({"height":"320px","overflow":"auto","margin-right":0});
	});

	if(go == undefined){
		sindex = setInterval(function(){
			if($(".active a").html() != 'Extension'){
				clearInterval(sindex);
				return;
			}
			SetPHPConfig(version,pathinfo,true)
		},5000);
	}

}

function InstallPHPLib(version,name,title){
	layer.confirm('You really want to install ['+name+']?',{closeBtn:2},function(){
		name = name.toLowerCase();
		var data = "name="+name+"&version="+version+"&type=1";
		var loadT = layer.msg('Adding to installer...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/files?action=InstallSoft', data, function(rdata)
		{
			setTimeout(function(){
				layer.close(loadT);
				SetPHPConfig(version);
				setTimeout(function(){
					layer.msg(rdata.msg,{icon:rdata.status?1:2});
				},1000);
			},1000);
		});

		fly("bi-btn");
		InstallTips();
		GetTaskCount();
	});
}

function UninstallPHPLib(version,name,title){
	layer.confirm('You really want to uninstall ['+name+']?',{closeBtn:2},function(){
		name = name.toLowerCase();
		var data = 'name='+name+'&version='+version;
		var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/files?action=UninstallSoft',data,function(rdata){
			layer.close(loadT);
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
			SetPHPConfig(version);
		});
	});
}

function disFun(version){
	$.get('/ajax?action=GetPHPConfig&version='+version,function(rdata){
		var disable_functions = rdata.disable_functions.split(',');
		var dbody = ''
		for(var i=0;i<disable_functions.length;i++){
			dbody += "<tr><td>"+disable_functions[i]+"</td><td><a style='float:right;' href=\"javascript:disable_functions('"+version+"','"+disable_functions[i]+"','"+rdata.disable_functions+"');\">Delete</a></td></tr>";
		}

		var con = "<div class='dirBinding'>"
				   +"<input type='text' placeholder='Add the name of the function to be disabled, such as: exec' id='disable_function_val' style='height: 28px; border-radius: 3px;width: 410px;' />"
				   +"<button class='btn btn-info btn-sm' onclick=\"disable_functions('"+version+"',1,'"+rdata.disable_functions+"')\">Add</button>"
				   +"</div>"
				   +"<div class='divtable' style='width:96%;margin:6px auto;height:260px;overflow:auto'><table class='table table-hover' width='100%' style='margin-bottom:0'>"
				   +"<thead><tr><th>Function name</th><th width='100' class='text-right'>Action</th></tr></thead>"
				   +"<tbody id='blacktable'>" + dbody + "</tbody>"
				   +"</table></div>"

		con +='\
		';

		$(".soft-man-con").html(con);
	});
}

function disable_functions(version,act,fs){
	var fsArr = fs.split(',');
	if(act == 1){
		var functions = $("#disable_function_val").val();
		for(var i=0;i<fsArr.length;i++){
			if(functions == fsArr[i]){
				layer.msg("The function you want to enter has been disabled!",{icon:5});
				return;
			}
		}
		fs += ',' + functions;
		msg = 'Added successfully!';
	}else{

		fs = '';
		for(var i=0;i<fsArr.length;i++){
			if(act == fsArr[i]) continue;
			fs += fsArr[i] + ','
		}
		msg = 'Successfully deleted!';
		fs = fs.substr(0,fs.length -1);
	}

	var data = 'version='+version+'&disable_functions='+fs;
	var loadT = layer.msg('Processing...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/config?action=setPHPDisable',data,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.status?msg:rdata.msg,{icon:rdata.status?1:2});
		disFun(version);
	});
}

function SetFpmConfig(version,action){
	if(action == 1){
		var max_children = Number($("input[name='max_children']").val());
		var start_servers = Number($("input[name='start_servers']").val());
		var min_spare_servers = Number($("input[name='min_spare_servers']").val());
		var max_spare_servers = Number($("input[name='max_spare_servers']").val());
		if(max_children < max_spare_servers){
			layer.msg('max_spare_servers Not greater than max_children',{icon:2});
			return;
		}

		if(min_spare_servers > start_servers) {
			layer.msg('min_spare_servers Not greater than start_servers',{icon:2});
			return;
		}

		if(max_spare_servers < min_spare_servers){
			layer.msg('min_spare_servers Not greater than max_spare_servers',{icon:2});
			return;
		}

		if(max_children < start_servers){
			layer.msg('start_servers Not greater than max_children',{icon:2});
			return;
		}

		if(max_children < 1 || start_servers < 1 || min_spare_servers < 1 || max_spare_servers < 1){
			layer.msg('The configuration value cannot be less than 1',{icon:2});
			return;
		}

		var data = 'version='+version+'&max_children='+max_children+'&start_servers='+start_servers+'&min_spare_servers='+min_spare_servers+'&max_spare_servers='+max_spare_servers;
		var loadT = layer.msg('Processing...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/config?action=setFpmConfig',data,function(rdata){
			layer.close(loadT);
			var loadT = layer.msg(rdata.msg,{icon:rdata.status?1:2});
		}).error(function(){
			layer.close(loadT);
			layer.msg('Successful setup!',{icon:1});
		});
		return;
	}

	$.post('/config?action=getFpmConfig','version='+version,function(rdata){

		var limitList = "<option value='0'>Customize</option>"
						+"<option value='1' "+(rdata.max_children==30?'selected':'')+">30 concurrent</option>"
						+"<option value='2' "+(rdata.max_children==50?'selected':'')+">50 concurrent</option>"
						+"<option value='3' "+(rdata.max_children==100?'selected':'')+">100 concurrent</option>"
						+"<option value='4' "+(rdata.max_children==200?'selected':'')+">200 concurrent</option>"
						+"<option value='5' "+(rdata.max_children==300?'selected':'')+">300 concurrent</option>"
						+"<option value='6' "+(rdata.max_children==500?'selected':'')+">500 concurrent</option>"
						+"<option value='7' "+(rdata.max_children==1000?'selected':'')+">1000 concurrent</option>"
		var body="<div class='bingfa'>"
						+"<p><span class='span_tit'>Concurrency plan: </span><select name='limit' style='width:90px; margin-left:6px;'>"+limitList+"</select></p>"
						+"<p><span class='span_tit'>max_children：</span><input type='number' name='max_children' value='"+rdata.max_children+"' />  *The maximum number of child processes allowed to be created</p>"
						+"<p><span class='span_tit'>start_servers：</span><input type='number' name='start_servers' value='"+rdata.start_servers+"' />  *Number of starting processes (number of initial processes after service startup)</p>"
						+"<p><span class='span_tit'>min_spare_servers：</span><input type='number' name='min_spare_servers' value='"+rdata.min_spare_servers+"' />   *Minimum number of idle processes (number of reserved processes after cleaning up idle processes)</p>"
						+"<p><span class='span_tit'>max_spare_servers：</span><input type='number' name='max_spare_servers' value='"+rdata.max_spare_servers+"' />   *Maximum number of idle processes (starts cleaning when the idle process reaches this value)</p>"
						+"<div><button class='btn btn-info btn-sm' onclick='SetFpmConfig(\""+version+"\",1)'>Save</button></div>"
				+"</div>"

		$(".soft-man-con").html(body);
		$("select[name='limit']").change(function(){
					var type = $(this).val();
					var max_children = rdata.max_children;
					var start_servers = rdata.start_servers;
					var min_spare_servers = rdata.min_spare_servers;
					var max_spare_servers = rdata.max_spare_servers;
					switch(type){
						case '1':
							max_children = 30;
							start_servers = 5;
							min_spare_servers = 5;
							max_spare_servers = 20;
							break;
						case '2':
							max_children = 50;
							start_servers = 15;
							min_spare_servers = 15;
							max_spare_servers = 35;
							break;
						case '3':
							max_children = 100;
							start_servers = 20;
							min_spare_servers = 20;
							max_spare_servers = 70;
							break;
						case '4':
							max_children = 200;
							start_servers = 25;
							min_spare_servers = 25;
							max_spare_servers = 150;
							break;
						case '5':
							max_children = 300;
							start_servers = 30;
							min_spare_servers = 30;
							max_spare_servers = 180;
							break;
						case '6':
							max_children = 500;
							start_servers = 35;
							min_spare_servers = 35;
							max_spare_servers = 250;
							break;
						case '7':
							max_children = 1000;
							start_servers = 40;
							min_spare_servers = 40;
							max_spare_servers = 300;
							break;
					}

					$("input[name='max_children']").val(max_children);
					$("input[name='start_servers']").val(start_servers);
					$("input[name='min_spare_servers']").val(min_spare_servers);
					$("input[name='max_spare_servers']").val(max_spare_servers);
				});
	});
}

function BtPhpinfo(version){
	var con = '<button class="btn btn-default btn-sm" onclick="GetPHPInfo(\''+version+'\')">View phpinfo()</button>';
	$(".soft-man-con").html(con);
}

function GetPHPInfo(version){
	var loadT = layer.msg('Retrieving...',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/ajax?action=GetPHPInfo&version='+version,function(rdata){
		layer.close(loadT);
		layer.open({
			type: 1,
		    title: "PHP-"+version+"-PHPINFO",
		    area: ['70%','90%'],
		    closeBtn: 2,
		    shadeClose: true,
		    content:rdata.replace('a:link {color: #009; text-decoration: none; background-color: #fff;}','').replace('a:link {color: #000099; text-decoration: none; background-color: #ffffff;}','')
		});
	});
}

function nginxSoftMain(name,version){
	var loadT = layer.msg('Processing, please wait..',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/system?action=GetConcifInfo',function(rdata){
		layer.close(loadT);
		nameA = rdata['web'];
		var status = name=='nginx'?'<span onclick="GetNginxStatus()">Load status</span>':'';
		var menu = '';
		if(version != undefined || version !=''){
			var menu = '<span onclick="softChangeVer(\''+name+'\',\''+version+'\')">Switch version</span>';
		}

		layer.open({
			type: 1,
			area: '640px',
			title: name+' management',
			closeBtn: 2,
			shift: 0,
			content: '<div class="tasklist" style="width:640px;height:480px;">\
				<div class="tab-nav">\
					<span class="on" onclick="service(\''+name+'\','+nameA.status+')">Web service</span>\
					<span onclick="configChange(\''+name+'\')">Configuration</span>\
					'+menu+'\
					'+status+'\
				</div>\
				<div id="webEdit-con" class="tab-con">\
					<div class="soft-man-con"></div>\
				</div>\
			</div>'
		})
		service(name,nameA.status);
		$(".tab-nav span").click(function(){
			//var i = $(this).index();
			$(this).addClass("on").siblings().removeClass("on");
		})
	});
}

function GetNginxStatus(){
	$.post('/ajax?action=GetNginxStatus','',function(rdata){
		var con = "<div><table class='table table-hover table-bordered'>\
						<tr><th>Connections(Active connections)</th><td>"+rdata.active+"</td></tr>\
						<tr><th>Total connections(accepts)</th><td>"+rdata.accepts+"</td></tr>\
						<tr><th>Total handshake(handled)</th><td>"+rdata.handled+"</td></tr>\
						<tr><th>Total requests(requests)</th><td>"+rdata.requests+"</td></tr>\
						<tr><th>Number of requests(Reading)</th><td>"+rdata.Reading+"</td></tr>\
						<tr><th>Response number(Writing)</th><td>"+rdata.Writing+"</td></tr>\
						<tr><th>Resident process(Waiting)</th><td>"+rdata.Waiting+"</td></tr>\
					 </table></div>";
		$(".soft-man-con").html(con);
	})
}

function GetPHPStatus(version){
	$.post('/ajax?action=GetPHPStatus','version='+version,function(rdata){
		var con = "<div style='height:420px;overflow:hidden;'><table class='table table-hover table-bordered GetPHPStatus' style='margin:0;padding:0'>\
						<tr><th>Application pool(pool)</th><td>"+rdata.pool+"</td></tr>\
						<tr><th>Process management(process manager)</th><td>"+((rdata['process manager'] == 'dynamic')?'dynamic':'static')+"</td></tr>\
						<tr><th>Start date(start time)</th><td>"+rdata['start time']+"</td></tr>\
						<tr><th>Number of requests(accepted conn)</th><td>"+rdata['accepted conn']+"</td></tr>\
						<tr><th>Request queue(listen queue)</th><td>"+rdata['listen queue']+"</td></tr>\
						<tr><th>Maximum waiting queue(max listen queue)</th><td>"+rdata['max listen queue']+"</td></tr>\
						<tr><th>Socket queue length(listen queue len)</th><td>"+rdata['listen queue len']+"</td></tr>\
						<tr><th>Number of idle processes(idle processes)</th><td>"+rdata['idle processes']+"</td></tr>\
						<tr><th>Number of active processes(active processes)</th><td>"+rdata['active processes']+"</td></tr>\
						<tr><th>Total number of processes(total processes)</th><td>"+rdata['total processes']+"</td></tr>\
						<tr><th>Maximum number of active processes(max active processes)</th><td>"+rdata['max active processes']+"</td></tr>\
						<tr><th>The maximum number of process arrivals(max children reached)</th><td>"+rdata['max children reached']+"</td></tr>\
						<tr><th>Slow request quantity(slow requests)</th><td>"+rdata['slow requests']+"</td></tr>\
					 </table></div>";
		$(".soft-man-con").html(con);
		$(".GetPHPStatus td,.GetPHPStatus th").css("padding","7px");
	})
}

function SoftMan(name,version){
	switch(name){
		case 'nginx':
			nginxSoftMain(name,version);
			return;
			break;
		case 'mysql':
			name='mysqld';
			break;
	}
	var loadT = layer.msg('Processing, please wait..',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/system?action=GetConcifInfo',function(rdata){
		layer.close(loadT);
		var nameA = rdata[name.replace('mysqld','mysql')];
		var menu = '<span onclick="configChange(\''+name+'\')">Configuration</span><span onclick="softChangeVer(\''+name+'\',\''+version+'\')">Switch version</span>';
		if(name == "phpmyadmin"){
			menu = '<span onclick="phpVer(\''+name+'\',\''+nameA.phpversion+'\')">PHP version</span><span onclick="safeConf(\''+name+'\','+nameA.port+','+nameA.auth+')">Security</span>';
		}
		if(version == undefined || version == ''){
			var menu = '<span onclick="configChange(\''+name+'\')">Configuration</span>';
		}

		if(name == 'mysqld'){
			menu += '<span onclick="changeMySQLDataPath()">Storage</span><span onclick="changeMySQLPort()">Port</span>';
		}

		layer.open({
			type: 1,
			area: '640px',
			title: name+' management',
			closeBtn: 2,
			shift: 0,
			content: '<div class="tasklist" style="width:640px;height:480px;">\
				<div class="tab-nav">\
					<span class="on" onclick="service(\''+name+'\',\''+nameA.status+'\')">Service</span>'
					+menu+
				'</div>\
				<div id="webEdit-con" class="tab-con">\
					<div class="soft-man-con"></div>\
				</div>\
			</div>'
		})
		service(name,nameA.status);
		$(".tab-nav span").click(function(){
			//var i = $(this).index();
			$(this).addClass("on").siblings().removeClass("on");
		})
	})
}

function changeMySQLDataPath(act){
	if(act != undefined){
		layer.confirm('Will the database run stop during the migration of the database file, continue??',{closeBtn:2,icon:3},function(){
			var datadir = $("#datadir").val();
			var data = 'datadir='+datadir;
			var loadT = layer.msg('Migrating files, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
			$.post('/database?action=SetDataDir',data,function(rdata){
				layer.close(loadT)
				layer.msg(rdata.msg,{icon:rdata.status?1:5});
			});
		});
		return;
	}

	$.post('/database?action=GetMySQLInfo','',function(rdata){
		var LimitCon = '<p class="conf_p">\
							<input id="datadir" class="phpUploadLimit form-control" style="width:350px;" type="text" value="'+rdata.datadir+'" name="datadir">\
							<span onclick="ChangePath(\'datadir\')" class="glyphicon glyphicon-folder-open cursor"></span>\
						</p>\
						<button class="btn btn-info btn-sm" onclick="changeMySQLDataPath(1)">Migrate</button>';
		$(".soft-man-con").html(LimitCon);
	});
}

function changeMySQLPort(act){
	if(act != undefined){
		layer.confirm('Modifying the database port may cause your site to fail to connect to the database. Are you sure you want to modify it??',{closeBtn:2,icon:3},function(){
			var port = $("#dataport").val();
			var data = 'port='+port;
			var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
			$.post('/database?action=SetMySQLPort',data,function(rdata){
				layer.close(loadT)
				layer.msg(rdata.msg,{icon:rdata.status?1:5});
			});
		});
		return;
	}

	$.post('/database?action=GetMySQLInfo','',function(rdata){
		var LimitCon = '<p class="conf_p">\
							<input id="dataport" class="phpUploadLimit form-control" type="number" value="'+rdata.port+'" name="dataport">\
							<button style="margin-top: -4px;" class="btn btn-info btn-sm" onclick="changeMySQLPort(1)">Modify</button>\
						</p>';

		$(".soft-man-con").html(LimitCon);
	});
}

function softChangeVer(name,version){
	if(name == "mysqld") name = "mysql";
	var veropt = version.split("|");
	var SelectVersion = '';
	for(var i=0; i<veropt.length; i++){
		SelectVersion += '<option>'+name+' '+veropt[i]+'</option>';
	}

	var body = "<div class='ver'><span style='margin-right:10px'>Select version</span><select id='selectVer' name='phpVersion' class='form-control' style='width:160px'>";
	body += SelectVersion+'</select></div><button class="btn btn-info btn-sm" style="margin-top:10px;">Switch</button>';

	if(name == 'mysql'){
		body += "<br><br><li style='color:red;'>Note: Installing a new MySQL version will overwrite the database data, please backup the database first!</li>"
	}

	$(".soft-man-con").html(body);
	$(".btn-info").click(function(){
		var ver = $("#selectVer").val();
		oneInstall(name,ver.split(" ")[1]);
	});
	selectChange();
}

function phpVer(name,version){
	$.post('/site?action=GetPHPVersion',function(rdata){
		var body = "<div class='ver'><span style='margin-right:10px'>Choose PHP version</span><select id='get' name='phpVersion' style='width:110px'>";
		var optionSelect = '';
		for(var i=0;i<rdata.length;i++){
			optionSelect = rdata[i].version == version?'selected':'';
			body += "<option value='"+ rdata[i].version +"' "+ optionSelect +">"+ rdata[i].name +"</option>"
		}
		body += '</select></div><button class="btn btn-info btn-sm" style="margin-top:10px;" onclick="phpVerChange(\'phpversion\',\'get\')">Submit</button>';
		$(".soft-man-con").html(body);
	})
}

function phpVerChange(type,msg){
	var data = type + '=' + $("#" + msg).val();
	var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/ajax?action=setPHPMyAdmin',data,function(rdata){
		layer.closeAll();
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
		if(rdata.status){
			setTimeout(function(){
				window.location.reload();
			},3000);
		}
	})
}

function safeConf(name,port,auth){
	var con = '<div class="ver">\
						<span style="margin-right:10px">Access port</span>\
						<input class="form-control phpmyadmindk" name="Name" id="pmport" value="'+port+'" placeholder="Phpmyadmin access port" maxlength="5" type="number">\
						<button class="btn btn-info btn-sm" onclick="phpmyadminport()">Submit</button>\
					</div>\
					<div class="user_pw_tit">\
						<span class="tit">Password access</span>\
						<span class="btswitch-p"><input class="btswitch btswitch-ios" id="phpmyadminsafe" type="checkbox" '+(auth?'checked':'')+'>\
						<label class="btswitch-btn phpmyadmin-btn" for="phpmyadminsafe" onclick="phpmyadminSafe()"></label>\
						</span>\
					</div>\
					<div class="user_pw">\
						<p><span>Authorized account</span><input id="username_get" name="username_get" value="" type="text" placeholder="Please leave blank if not modified"></p>\
						<p><span>Authorization password</span><input id="password_get_1" name="password_get_1" value="" type="password" placeholder="Please leave blank if not modified"></p>\
						<p><span>Repeat the password</span><input id="password_get_2" name="password_get_1" value="" type="password" placeholder="Please leave blank if not modified"></p>\
						<p><button class="btn btn-info btn-sm" onclick="phpmyadmin(\'get\')">Submit</button></p>\
					</div>\
					<ul class="help-info-text"><li>Add an access security lock for phpmyadmin</li></ul>';
	$(".soft-man-con").html(con);
	if(auth){
		$(".user_pw").show();
	}
}

function phpmyadminport(){
	var pmport = $("#pmport").val();
	if(pmport < 80 || pmport > 65535){
		layer.msg('The port range is invalid. Please re-enter!',{icon:2});
		return;
	}
	var data = 'port=' + pmport;
	var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/ajax?action=setPHPMyAdmin',data,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	});
}

function phpmyadminSafe(){
	var stat = $("#phpmyadminsafe").prop("checked");
	if(stat) {
		$(".user_pw").hide();
		phpmyadmin('close');
	}else{
		 $(".user_pw").show();
	}

}

function phpmyadmin(msg){
	type = 'password';
	if(msg == 'close'){
		password_1 = msg;
		username = msg;
		layer.confirm('Do you really want to turn off access authentication??',{closeBtn:2,icon:3},function(){
			var data = type + '=' + msg + '&siteName=phpmyadmin';
			var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
			$.post('/ajax?action=setPHPMyAdmin',data,function(rdata){
				layer.close(loadT);
				layer.msg(rdata.msg,{icon:rdata.status?1:2});
			});
		});
		return;
	}else{
		username = $("#username_get").val()
		password_1 = $("#password_get_1").val()
		password_2 = $("#password_get_2").val()
		if(username.length < 1 || password_1.length < 1){
			layer.msg('Authorized user or password cannot be empty!',{icon:2});
			return;
		}
		if(password_1 != password_2){
			layer.msg('The passwords entered twice do not match, please re-enter!',{icon:2});
			return;
		}
	}
	msg = password_1 + '&username='+username + '&siteName=phpmyadmin';
	var data = type + '=' + msg;
	var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/ajax?action=setPHPMyAdmin',data,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	});
}

function PluginMan(name,title){
	loadT = layer.msg('Getting template...',{icon:16,time:0,shade: [0.3, '#000']});
	$.get('/plugin?action=getConfigHtml&name=' + name,function(rhtml){
		layer.close(loadT);
		if(rhtml.status === false){
			if(name == "phpguard"){
				layer.msg("Php daemon has been started, no need to set",{icon:1})
			}
			else{
				layer.msg(rhtml.msg,{icon:2});
			}
			return;
		}
		layer.open({
			type: 1,
			shift: 5,
			closeBtn: 2,
			area: '700px',
			title: ''+ title,
			content: rhtml
		});
		rcode = rhtml.split('<script type="javascript/text">')[1].replace('</script>','');
		setTimeout(function(){
			if(!!(window.attachEvent && !window.opera)){
				execScript(rcode);
			}else{
				window.eval(rcode);
			}
		},200)

	});
}

function SetPluginConfig(name,param,def){
	if(def == undefined) def = 'SetConfig';
	loadT = layer.msg('Saving configuration...',{icon:16,time:0,shade: [0.3, '#000']});
	$.post('/plugin?action=a&name='+name+'&s=' + def,param,function(rdata){
		layer.close(loadT);
		layer.msg(rdata.msg,{icon:rdata.status?1:2});
	});
}

function GetSList(isdisplay){
	if(isdisplay == undefined){
		var loadT = layer.msg('Mengunduh data perangkat lunak...',{icon:16,time:0,shade: [0.3, '#000']})
	}
	$.post('/plugin?action=getPluginList','',function(rdata){
		layer.close(loadT);
		var sBody = '';
		var pBody = '';
		$(".task").text(rdata[rdata.length - 1]);
		for(var i=0;i<rdata.length - 1;i++){
			var len = rdata[i].versions.length;
          	var version_info = '';
			var version = '';
			var softPath ='';
			var titleClick = '';
			var state = '';
			var indexshow = '';
			var checked = '';
			checked = rdata[i].status==0 ? '':'checked';
          	for(var j=0;j<len;j++){
              	if(rdata[i].versions[j].status) continue;
             	version_info += rdata[i].versions[j].version + '|';
            }
          	if(version_info != ''){
             	 version_info = version_info.substring(0,version_info.length-1);
            }

			var handle = '<a class="link" onclick="AddVersion(\''+rdata[i].name+'\',\''+version_info+'\',\''+rdata[i].tip+'\',this,\''+rdata[i].title+'\')">Pasang</a>';
			if(rdata[i].name != 'php'){
				for(var n=0; n<len; n++){
					if(rdata[i].versions[n].status == true){
						if(rdata[i].tip == 'lib'){
							handle = '<a class="link" onclick="PluginMan(\''+rdata[i].name+'\',\''+rdata[i].title+'\')">Atur</a> | <a class="link" onclick="UninstallVersion(\''+rdata[i].name+'\',\''+rdata[i].versions[n].version+'\',\''+rdata[i].title+'\')">Lepas</a>';
							titleClick = 'onclick="PluginMan(\''+rdata[i].name+'\',\''+rdata[i].title+'\')" style="cursor:pointer"';
						}else{
							handle = '<a class="link" onclick="SoftMan(\''+rdata[i].name+'\',\''+version_info+'\')">Atur</a> | <a class="link" onclick="UninstallVersion(\''+rdata[i].name+'\',\''+rdata[i].versions[n].version+'\',\''+rdata[i].title+'\')">Lepas</a>';
							titleClick = 'onclick="SoftMan(\''+rdata[i].name+'\',\''+version_info+'\')" style="cursor:pointer"';
						}

						version = rdata[i].versions[n].version;
						softPath = '<span class="glyphicon glyphicon-folder-open" title="'+rdata[i].path+'" onclick="openPath(\''+rdata[i].path+'\')"></span>';
						indexshow = '<div class="index-item"><input class="btswitch btswitch-ios" id="index_'+rdata[i].name+'" type="checkbox" '+checked+'><label class="btswitch-btn" for="index_'+rdata[i].name+'" onclick="toIndexDisplay(\''+rdata[i].name+'\',\''+version+'\')"></label></div>';
						if(rdata[i].versions[n].run == true){
							state='<span style="color:#3498DB" class="glyphicon glyphicon-play"></span>'
						}
						else{
							state='<span style="color:red" class="glyphicon glyphicon-pause"></span>'
						}
					}
					var isTask = rdata[i].versions[n].task;
					if(isTask == '-1'){
						handle = '<a style="color:#3498DB;" href="javascript:task();">Menginstal..</a>'
					}else if(isTask == '0'){
						handle = '<a style="color:#C0C0C0;" href="javascript:task();">Menunggu instalasi..</a>'
					}
				}
				sBody += '<tr>'
						+'<td><span '+titleClick+'>'+rdata[i].title+' '+version+'</span></td>'
						+'<td class="visible-lg visible-md visible-sm">'+rdata[i].type+'</td>'
						+'<td>'+state+'</td>'
						+'<td style="text-align: right;">'+handle+'</td>'
					+'</tr>'
			}
			else{
				for(var n=0; n<len; n++){
					if(rdata[i].versions[n].status == true){
						checked = rdata[i].versions[n]['display'] ? "checked":"";
						handle = '<a class="link" onclick="phpSoftMain(\''+rdata[i].versions[n].version+'\','+n+')">Atur</a> | <a class="link" onclick="UninstallVersion(\''+rdata[i].name+'\',\''+rdata[i].versions[n].version+'\',\''+rdata[i].title+'\')">Lepas</a>';
						softPath = '<span class="glyphicon glyphicon-folder-open" title="'+rdata[i].path+'" onclick="openPath(\''+rdata[i].path+"/"+rdata[i].versions[n].version.replace(/\./,"")+'\')"></span>';
						titleClick = 'onclick="phpSoftMain(\''+rdata[i].versions[n].version+'\','+n+')" style="cursor:pointer"';
						indexshow = '<div class="index-item"><input class="btswitch btswitch-ios" id="index_'+rdata[i].name+rdata[i].versions[n].version.replace(/\./,"")+'" type="checkbox" '+checked+'><label class="btswitch-btn" for="index_'+rdata[i].name+rdata[i].versions[n].version.replace(/\./,"")+'" onclick="toIndexDisplay(\''+rdata[i].name+'\',\''+rdata[i].versions[n].version+'\')"></label></div>';
						if(rdata[i].versions[n].run == true){
							state='<span style="color:#3498DB" class="glyphicon glyphicon-play"></span>'
						}
						else{
							state='<span style="color:red" class="glyphicon glyphicon-pause"></span>'
						}

					}
					else{
						handle = '<a class="link" onclick="oneInstall(\''+rdata[i].name+'\',\''+rdata[i].versions[n].version+'\')">Pasang</a>';
						softPath ='';
						checked = '';
						indexshow = '';
						titleClick ='';
						state = '';
					}
					var isTask = rdata[i].versions[n].task;
					if(isTask == '-1'){
						handle = '<a style="color:#3498DB;" href="javascript:task();">Menginstal..</a>'
					}else if(isTask == '0'){
						handle = '<a style="color:#C0C0C0;" href="javascript:task();">Menunggu instalasi..</a>'
					}
					pBody += '<tr>'
							+'<td><span '+titleClick+'>'+rdata[i].title+'-'+rdata[i].versions[n].version+'</span></td>'
							+'<td class="visible-lg visible-md visible-sm">'+rdata[i].type+'</td>'
							+'<td>'+state+'</td>'
							+'<td style="text-align: right;">'+handle+'</td>'
						+'</tr>'
				}
			}
		}
		sBody += pBody;
		$("#softList").html(sBody);
	})
}

function oneInstall(name,version){
	if (name == 'nginx'){
		var isError = false
		$.ajax({
			url:'/ajax?action=GetInstalled',
			type:'get',
			async:false,
			success:function(rdata){
				if(rdata.webserver != name && rdata.webserver != false){
					layer.msg('Please uninstall Nginx first',{icon:2})
					isError = true;
					return;
				}
			}
		});
	}

	var optw = '';
	if(name == 'mysql'){
		optw = "<br><br><li style='color:red;'>Note: Installing a new MySQL version will overwrite the database data. Please back up the database first.!</li>"
	}

	if (isError) return;
	var one = layer.open({
		type: 1,
	    title: 'Choose installation method',
	    area: '350px',
	    closeBtn: 2,
	    shadeClose: true,
	    content:"<div class='zun-form-new'>\
			<div class='version'>Installation version:<span style='margin-left:30px'>"+name+" "+version+"</span>"+optw+"</div>\
				<div class='fangshi'>Compile from source. Installation time (30 minutes to 3 hours) for high performance applications.</div>\
	    	<div class='fangshi' style='display:none;'>Installation method: <label data-title='That is rpm, installation time is very fast (5~10 minutes), performance and stability is slightly lower than compile and install'>Extreme speed installation<input type='checkbox'></label><label data-title='Long installation time (30 minutes to 3 hours) for high performance applications'>Compile from source <input type='checkbox' checked></label></div>\
	    	<div class='submit-btn' style='margin-top:15px'>\
				<button type='button' class='btn btn-danger btn-sm btn-title one-close'>Cancel</button>\
		        <button type='button' id='bi-btn' class='btn btn-info btn-sm btn-title bi-btn'>Submit</button>\
	        </div>\
	    </div>"
	})
	$('.fangshi input').click(function(){
		$(this).attr('checked','checked').parent().siblings().find("input").removeAttr('checked');
	});
	$("#bi-btn").click(function(){
		var type = $('.fangshi input').prop("checked") ? '1':'0';
		var data = "name="+name+"&version="+version+"&type="+type;
		var loadT = layer.msg('Adding to installer...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/files?action=InstallSoft', data, function(rdata) {
			layer.closeAll();
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
			GetSList();
		})

	});
	$(".one-close").click(function(){
		layer.close(one);
	})
	InstallTips();
	fly("bi-btn");
}

function AddVersion(name,ver,type,obj,title){
	if(type == "lib"){
		layer.confirm('You really want to install ['+title+'-'+ver+']?',{closeBtn:2},function(){
			$(obj).text("Installing..");
			var data = "name="+name;
			var loadT = layer.msg('Installing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
			$.post("/plugin?action=install",data,function(rdata){
				layer.close(loadT);
				layer.msg(rdata.msg,{icon:rdata.status?1:2});
				setTimeout(function(){GetSList()},2000)
			});
		});
		return;
	}


	var titlename = name;
	var veropt = ver.split("|");
	var SelectVersion = '';
	for(var i=0; i<veropt.length; i++){
		SelectVersion += '<option>'+name+' '+veropt[i]+'</option>';
	}
	if(name == 'phpmyadmin' || name == 'nginx'){
		var isError = false
		$.ajax({
			url:'/ajax?action=GetInstalled',
			type:'get',
			async:false,
			success:function(rdata){
				if(name == 'nginx'){
					if(rdata.webserver != name.toLowerCase() && rdata.webserver != false){
						layer.msg('Error',{icon:2})
						isError = true;
						return;
					}
				}
				if(name == 'phpmyadmin'){
					if (rdata.php.length < 1){
						layer.msg('Please install PHP first',{icon:2})
						isError = true;
						return;
					}
					if (!rdata.mysql.setup){
						layer.msg('Please install MySQL first.',{icon:2})
						isError = true;
						return;
					}

				}
			}
		});
		if(isError) return;
	}

	layer.open({
		type: 1,
	    title: titlename+" Software Installation",
	    area: '350px',
	    closeBtn: 2,
	    shadeClose: true,
	    content:"<div class='zun-form-new'>\
			<div class='version'>Installation version:<select id='SelectVersion'>"+SelectVersion+"</select></div>\
				<div class='fangshi'>Compile from source. Installation time (30 minutes to 3 hours) for high performance applications.</div>\
				<div class='fangshi' style='display:none;'>Installation method: <label data-title='That is rpm, installation time is very fast (5~10 minutes), performance and stability is slightly lower than compile and install'>Extreme speed installation<input type='checkbox'></label><label data-title='Long installation time (30 minutes to 3 hours) for high performance applications'>Compile from source <input type='checkbox' checked></label></div>\
	    	<div class='submit-btn' style='margin-top:15px'>\
				<button type='button' class='btn btn-danger btn-sm btn-title' onclick='layer.closeAll()'>Cancel</button>\
		        <button type='button' id='bi-btn' class='btn btn-info btn-sm btn-title bi-btn'>Submit</button>\
	        </div>\
	    </div>"
	})
	selectChange();
	$('.fangshi input').click(function(){
		$(this).attr('checked','checked').parent().siblings().find("input").removeAttr('checked');
	});
	$("#bi-btn").click(function(){
		var info = $("#SelectVersion").val().toLowerCase();
		var name = info.split(" ")[0];
		var version = info.split(" ")[1];
		var type = $('.fangshi input').prop("checked") ? '1':'0';
		var data = "name="+name+"&version="+version+"&type="+type;

		var loadT = layer.msg('Adding to installer...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post("/plugin?action=install",data,function(rdata){
			layer.closeAll();
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
			GetSList();
		});
	});
	InstallTips();
	fly("bi-btn");
}

function selectChange(){
	$("#SelectVersion,#selectVer").change(function(){
		var info = $(this).val();
		var name = info.split(" ")[0];
		var version = info.split(" ")[1];
		max=64
		msg="64M"
		if(name == 'mysql'){
			memSize = getCookie('memSize');
			switch(version){
				case '5.1':
					max = 256;
					msg = '256M';
					break;
				case '5.7':
					max = 1500;
					msg = '2GB';
					break;
				case '5.6':
					max = 800;
					msg = '1GB';
					break;
				case 'mariadb_10.0':
					max = 800;
					msg = '1GB';
					break;
				case 'mariadb_10.1':
					max = 1500;
					msg = '2GB';
					break;
			}
			if(memSize < max){
				layer.msg('Your memory is less than ' + msg + ', it is not recommended to install MySQL-' + version,{icon:5});
			}
		}
	});
}

function UninstallVersion(name,version,title){
	layer.confirm('You really want to uninstall ['+title+'-'+version+']?',{closeBtn:2},function(){
		var data = 'name='+name+'&version='+version;
		var loadT = layer.msg('Processing, please wait...',{icon:16,time:0,shade: [0.3, '#000']});
		$.post('/plugin?action=unInstall',data,function(rdata){
			layer.close(loadT)
			GetSList();
			layer.msg(rdata.msg,{icon:rdata.status?1:2});
		})
	});
}

$(function(){
	if(window.document.location.pathname == '/'){
		setInterval(function(){GetSList(true);},5000);
	}
});
