#coding: utf-8
import sys,os,web,public,re
reload(sys)
sys.setdefaultencoding('utf-8')
class firewalls:
    __isFirewalld = False
    __isUfw = False

    def __init__(self):
        if os.path.exists('/usr/sbin/firewalld'): self.__isFirewalld = True
        if os.path.exists('/usr/sbin/ufw'): self.__isUfw = True

    def FirewallReload(self):
        if self.__isUfw:
            public.ExecShell('/usr/sbin/ufw reload')
            return;
        if self.__isFirewalld:
            public.ExecShell('firewall-cmd --reload')
        else:
            public.ExecShell('/etc/init.d/iptables save')
            public.ExecShell('/etc/init.d/iptables restart')

    def SetFirewallStatus(self,get):
        status = status
        result = SendSocket("Firewall|status|".status)
        return (result)


    def AddDropAddress(self,get):
        import time
        address = get.port
        if public.M('firewall').where("port=?",(address,)).count() > 0: return public.returnMsg(False,'The mask you want to put on the mask already exists, there is no need to repeat the processing.!')
        if self.__isUfw:
            public.ExecShell('ufw deny from ' + address + ' to any');
        else:
            if self.__isFirewalld:
                public.ExecShell('firewall-cmd --permanent --add-rich-rule=\'rule family=ipv4 source address="'+ address +'" drop\'')
            else:
                public.ExecShell('iptables -I INPUT -s '+address+' -j DROP')

        public.WriteLog("Firewall management", 'Block IP ['+address+'] success!')
        addtime = time.strftime('%Y-%m-%d %X',time.localtime())
        public.M('firewall').add('port,ps,addtime',(address,get.ps,addtime))

        self.FirewallReload();
        return public.returnMsg(True,'Added successfully!')

    def DelDropAddress(self,get):
        address = get.port
        id = get.id
        if self.__isUfw:
            public.ExecShell('ufw delete deny from ' + address + ' to any');
        else:
            if self.__isFirewalld:
                public.ExecShell('firewall-cmd --permanent --remove-rich-rule=\'rule family=ipv4 source address="'+ address +'" drop\'')
            else:
                public.ExecShell('iptables -t filte -D INPUT -s '+address+' -j DROP')

        public.WriteLog("Firewall management", 'Unblock IP ['+address+'] success!')
        public.M('firewall').where("id=?",(id,)).delete()

        self.FirewallReload();
        return public.returnMsg(True,'successfully deleted!')


    def AddAcceptPort(self,get):
        import time
        port = get.port
        ps = get.ps
        if public.M('firewall').where("port=?",(port,)).count() > 0: return public.returnMsg(False,'The port you want to release already exists, no need to repeat the release!')
        if self.__isUfw:
            public.ExecShell('ufw allow ' + port + '/tcp');
        else:
            if self.__isFirewalld:
                public.ExecShell('firewall-cmd --permanent --zone=public --add-port='+port+'/tcp')
            else:
                public.ExecShell('iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport '+port+' -j ACCEPT')
        public.WriteLog("Firewall management", 'Release port ['+port+'] success!')
        addtime = time.strftime('%Y-%m-%d %X',time.localtime())
        public.M('firewall').add('port,ps,addtime',(port,ps,addtime))

        self.FirewallReload()
        return public.returnMsg(True,'Added successfully!')


    def DelAcceptPort(self,get):
        port = get.port
        id = get.id
        try:
            if(port == web.ctx.host.split(':')[1]): return public.returnMsg(False,'Failed to delete the current panel port!')
            if self.__isUfw:
                public.ExecShell('ufw delete allow ' + port + '/tcp');
            else:
                if self.__isFirewalld:
                    public.ExecShell('firewall-cmd --permanent --zone=public --remove-port='+port+'/tcp')
                else:
                    public.ExecShell('iptables -D INPUT -p tcp -m state --state NEW -m tcp --dport '+port+' -j ACCEPT')
            public.WriteLog("Firewall management", 'Remove firewall release port ['+port+'] success!')
            public.M('firewall').where("id=?",(id,)).delete()

            self.FirewallReload()
            return public.returnMsg(True,'successfully deleted!')
        except:
            return public.returnMsg(False,'Failed, the program gave up!')

    def SetSshStatus(self,get):
        version = public.readFile('/etc/redhat-release')
        if int(get['status'])==1:
            msg = 'SSH service has been disabled'
            act = 'stop'
        else:
            msg = 'SSH service has started'
            act = 'start'


        if version.find(' 7.') != -1:
            public.ExecShell("systemctl "+act+" sshd.service")
        else:
            public.ExecShell("/etc/init.d/sshd "+act)

        public.WriteLog("Firewall management", msg)
        return public.returnMsg(True,'Successful operation!')


    def SetPing(self,get):
        if get.status == '1':
            get.status = '0';
        else:
            get.status = '1';
        filename = '/etc/sysctl.conf'
        conf = public.readFile(filename)
        if conf.find('net.ipv4.icmp_echo') != -1:
            rep = u"net\.ipv4\.icmp_echo.*"
            conf = re.sub(rep,'net.ipv4.icmp_echo_ignore_all='+get.status,conf)
        else:
            conf += "\nnet.ipv4.icmp_echo_ignore_all="+get.status


        public.writeFile(filename,conf)
        public.ExecShell('sysctl -p')
        return public.returnMsg(True,'Successful operation!')


    def SetSshPort(self,get):
        port = get.port
        if int(port) < 22 or int(port) > 65535: return public.returnMsg(False,'The port range must be between 22-65535!');
        ports = ['21','25','80','443','8080','1234','12345'];
        if port in ports: return public.returnMsg(False,'The designated port is a common port, please try another one!');

        file = '/etc/ssh/sshd_config'
        conf = public.readFile(file)

        rep = "#*Port\s+([0-9]+)\s*\n"
        conf = re.sub(rep, "Port "+port+"\n", conf)
        public.writeFile(file,conf)

        if self.__isFirewalld:
            public.ExecShell('firewall-cmd --permanent --zone=public --add-port='+port+'/tcp')
            public.ExecShell('setenforce 0');
            public.ExecShell('sed -i "s#SELINUX=enforcing#SELINUX=disabled#" /etc/selinux/config');
            public.ExecShell("systemctl restart sshd.service")
        else:
            public.ExecShell('iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport '+port+' -j ACCEPT')
            public.ExecShell("/etc/init.d/sshd restart")

        self.FirewallReload()
        public.M('firewall').where("ps=?",('SSH remote management service',)).setField('port',port)
        public.WriteLog("Firewall management", "Change the SSH port to ["+port+"] success!")
        return public.returnMsg(True,'Successfully modified!')


    def GetSshInfo(self,get):
        file = '/etc/ssh/sshd_config'
        conf = public.readFile(file)
        rep = "#*Port\s+([0-9]+)\s*\n"
        port = re.search(rep,conf).groups(0)[0]
        import system
        panelsys = system.system();

        version = panelsys.GetSystemVersion();
        if version.find('Ubuntu') != -1:
             status = public.ExecShell("service sshd status | grep 'dead'")
        else:
            if version.find(' 7.') != -1:
                status = public.ExecShell("systemctl status sshd.service | grep 'dead'")
            else:
                status = public.ExecShell("/etc/init.d/sshd status | grep 'stopped'")

        if len(status[0]) > 3:
            status = False
        else:
            status = True
        isPing = True
        try:
            file = '/etc/sysctl.conf'
            conf = public.readFile(file)
            rep = "#*net\.ipv4\.icmp_echo_ignore_all\s*=\s*([0-9]+)"
            tmp = re.search(rep,conf).groups(0)[0]
            if tmp == '1': isPing = False
        except:
            isPing = True


        data = {}
        data['port'] = port
        data['status'] = status
        data['ping'] = isPing
        return data
