#coding: utf-8
import public,db,web,re,time,os,sys,mysql
reload(sys)
sys.setdefaultencoding('utf-8')
class database:

    def AddDatabase(self,get):
        try:
            data_name = get['name'].strip()
            if data_name == 'root' or data_name == 'mysql' or data_name == 'test' or len(data_name) < 3:
                return public.returnMsg(False,'Database name is not legal, or less than 3 characters!')

            if len(data_name) > 16: return public.returnMsg(False, 'Database name cannot be greater than 16 digits')

            reg = "^[a-zA-Z]{1}\w+$"
            if not re.match(reg, data_name): return public.returnMsg(False,'The database name cannot have a special symbol, and the first digit must be a letter')

            data_pwd = get['password']
            if len(data_pwd)<1:
                data_pwd = public.md5(time.time())[0:8]

            sql = public.M('databases')
            if sql.where("name=?",(data_name,)).count(): return public.returnMsg(False,'The database already exists!')
            address = get['address'].strip()
            user = 'Yes'
            username = data_name
            password = data_pwd

            codeing = get['codeing']

            wheres={
                    'utf8'      :   'utf8_general_ci',
                    'utf8mb4'   :   'utf8mb4_general_ci',
                    'gbk'       :   'gbk_chinese_ci',
                    'big5'      :   'big5_chinese_ci'
                    }
            codeStr=wheres[codeing]
            result = mysql.mysql().execute("create database " + data_name + " DEFAULT CHARACTER SET " + codeing + " COLLATE " + codeStr)
            isError=self.IsSqlError(result)
            if  isError != None: return isError
            mysql.mysql().execute("drop user '" + username + "'@'localhost'")
            mysql.mysql().execute("drop user '" + username + "'@'" + address + "'")
            mysql.mysql().execute("grant all privileges on " + data_name + ".* to '" + username + "'@'localhost' identified by '" + data_pwd + "'")
            mysql.mysql().execute("grant all privileges on " + data_name + ".* to '" + username + "'@'" + address + "' identified by '" + data_pwd + "'")
            mysql.mysql().execute("flush privileges")


            if get['ps'] == '': get['ps']='Fill in the note'
            addTime = time.strftime('%Y-%m-%d %X',time.localtime())

            pid = 0
            if hasattr(get,'pid'): pid = get.pid
            sql.add('pid,name,username,password,accept,ps,addtime',(pid,data_name,username,password,address,get['ps'],addTime))
            public.WriteLog("Database management", "Add database [" + data_name + "] success!")
            return public.returnMsg(True,'Added successfully')
        except Exception,ex:
            public.WriteLog("Database management", "Add database [" + data_name + "] failure => "  +  str(ex))
            return public.returnMsg(False,'Add failed')

    def IsSqlError(self,mysqlMsg):
        mysqlMsg=str(mysqlMsg)
        if "using password:" in mysqlMsg: return public.returnMsg(False,'Database management password error!')
        if "Connection refused" in mysqlMsg: return public.returnMsg(False,'Database connection failed, please check if the database service is started!')
        if "1133" in mysqlMsg: return public.returnMsg(False,'Database user does not exist!')
        return None

    def DeleteDatabase(self,get):
        try:
            id=get['id']
            name = get['name']
            accept = public.M('databases').where("id=?",(id,)).getField('accept')
            #MYSQL
            result = mysql.mysql().execute("drop database " + name)
            isError=self.IsSqlError(result)
            if  isError != None: return isError
            mysql.mysql().execute("drop user '" + name + "'@'localhost'")
            mysql.mysql().execute("drop user '" + name + "'@'" + accept + "'")
            mysql.mysql().execute("flush privileges")
            #SQLITE
            public.M('databases').where("id=?",(id,)).delete()
            public.WriteLog("Database management", "Delete database [" + name + "] success!")
            return public.returnMsg(True, 'Delete database successfully!')
        except Exception,ex:
            public.WriteLog("Database management", "Delete database [" + data_name + "] failure => "  +  str(ex))
            return public.returnMsg(False,'Failed to delete database')

    def SetupPassword(self,get):
        password = get['password'].strip()
        try:
            rep = "^[\w#@%\.]+$"
            if not re.match(rep, password): return public.returnMsg(False, 'Do not include special characters in the password!')
            mysql_root = public.M('config').where("id=?",(1,)).getField('mysql_root')
            #MYSQL
            result = mysql.mysql().query("show databases")
            isError=self.IsSqlError(result)
            if  isError != None:
                public.M('config').where("id=?",(1,)).setField('mysql_root',password)
                result = mysql.mysql().query("show databases")
                isError=self.IsSqlError(result)
                if  isError != None:
                    root_mysql = '''#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
pwd=$1
/etc/init.d/mysqld stop
mysqld_safe --skip-grant-tables&
echo 'Changing password...';
echo 'The set password...';
sleep 6
mysql -uroot -e "insert into mysql.user(Select_priv,Insert_priv,Update_priv,Delete_priv,Create_priv,Drop_priv,Reload_priv,Shutdown_priv,Process_priv,File_priv,Grant_priv,References_priv,Index_priv,Alter_priv,Show_db_priv,Super_priv,Create_tmp_table_priv,Lock_tables_priv,Execute_priv,Repl_slave_priv,Repl_client_priv,Create_view_priv,Show_view_priv,Create_routine_priv,Alter_routine_priv,Create_user_priv,Event_priv,Trigger_priv,Create_tablespace_priv,User,Password,host)values('Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','root',password('${pwd}'),'127.0.0.1')"
mysql -uroot -e "insert into mysql.user(Select_priv,Insert_priv,Update_priv,Delete_priv,Create_priv,Drop_priv,Reload_priv,Shutdown_priv,Process_priv,File_priv,Grant_priv,References_priv,Index_priv,Alter_priv,Show_db_priv,Super_priv,Create_tmp_table_priv,Lock_tables_priv,Execute_priv,Repl_slave_priv,Repl_client_priv,Create_view_priv,Show_view_priv,Create_routine_priv,Alter_routine_priv,Create_user_priv,Event_priv,Trigger_priv,Create_tablespace_priv,User,Password,host)values('Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','root',password('${pwd}'),'localhost')"
mysql -uroot -e "UPDATE mysql.user SET password=PASSWORD('${pwd}') WHERE user='root'";
mysql -uroot -e "UPDATE mysql.user SET authentication_string=PASSWORD('${pwd}') WHERE user='root'";
mysql -uroot -e "FLUSH PRIVILEGES";
pkill -9 mysqld_safe
pkill -9 mysqld
sleep 2
/etc/init.d/mysqld start

echo '==========================================='
echo "The root password was successfully modified to : ${pwd}"
echo "The root password set ${pwd}  successuful"''';

                public.writeFile('mysql_root.sh',root_mysql)
                os.system("bash mysql_root.sh " + password)
                os.system("rm -f mysql_root.sh")


            else:
                if '5.7' in public.readFile(web.ctx.session.setupPath + '/mysql/version.pl'):
                    result = mysql.mysql().execute("update mysql.user set authentication_string=password('" + password + "') where User='root'")
                else:
                    result = mysql.mysql().execute("update mysql.user set Password=password('" + password + "') where User='root'")
                mysql.mysql().execute("flush privileges")

            msg = 'The ROOT password was successfully modified.!'
            #SQLITE
            public.M('config').where("id=?",(1,)).setField('mysql_root',password)
            public.WriteLog("Database management", "Set the root password successfully.!")
            web.ctx.session.config['mysql_root']=password
            return public.returnMsg(True,msg)
        except Exception,ex:
            return public.returnMsg(False,'Password change failed!');

    def ResDatabasePassword(self,get):
        try:
            newpassword = get['password']
            username = get['username']
            id = get['id']
            rep = "^[\w#@%\.]+$"
            if len(re.search(rep, newpassword).groups()) >0: return public.returnMsg(False, 'Do not include special characters in the password!')
            #MYSQL
            if '5.7' in public.readFile(web.ctx.session.setupPath + '/mysql/version.pl'):
                result = mysql.mysql().execute("update mysql.user set authentication_string=password('" + newpassword + "') where User='" + username + "'")
            else:
                result = mysql.mysql().execute("update mysql.user set Password=password('" + newpassword + "') where User='" + username + "'")

            isError=self.IsSqlError(result)
            if  isError != None: return isError
            mysql.mysql().execute("flush privileges")

            if result==False: return public.returnMsg(False,'The modification failed, the database user does not exist.!')
            #SQLITE
            if int(id) > 0:
                public.M('databases').where("id=?",(id,)).setField('password',newpassword)
            else:
                public.M('config').where("id=?",(id,)).setField('mysql_root',newpassword)
                web.ctx.session.config['mysql_root'] = newpassword

            public.WriteLog("Database management", "Modify database user [" + username + "] password succeeded!")
            return public.returnMsg(True,'Modify the database [' + username + '] password succeeded!')
        except Exception,ex:
            public.WriteLog("Database management", "Modify database user [" + username + "] password failed => "  +  str(ex))
            return public.returnMsg(False,'Modify the database [' + username + '] password failed!')

    def setMyCnf(self,action = True):
        myFile = '/etc/my.cnf'
        mycnf = public.readFile(myFile)
        root = web.ctx.session.config['mysql_root']
        pwdConfig = "\n[mysqldump]\nuser=root\npassword=root"
        rep = "\n\[mysqldump\]\nuser=root\npassword=.+"
        if action:
            if mycnf.find(pwdConfig) > -1: return
            if mycnf.find("\n[mysqldump]\nuser=root\n") > -1:
                mycnf = mycnf.replace(rep, pwdConfig)
            else:
                mycnf  += "\n[mysqldump]\nuser=root\npassword=root"

        else:
            mycnf = mycnf.replace(rep, '')


        public.writeFile(myFile,mycnf)


    def ToBackup(self,get):
        #try:
        id = get['id']
        name = public.M('databases').where("id=?",(id,)).getField('name')
        root = web.ctx.session.config['mysql_root']
        if not os.path.exists(web.ctx.session.config['backup_path'] + '/database'): os.system('mkdir -p ' + web.ctx.session.config['backup_path'] + '/database');
        mycnf = public.readFile('/etc/my.cnf');
        rep = "\[mysqldump\]\nuser=root"
        sea = '[mysqldump]\n'
        subStr = sea + "user=root\npassword=" + root+"\n";
        mycnf = mycnf.replace(sea,subStr)
        if len(mycnf) > 100:
            public.writeFile('/etc/my.cnf',mycnf);

        fileName = name + '_' + time.strftime('%Y%m%d_%H%M%S',time.localtime()) + '.sql.gz'
        backupName = web.ctx.session.config['backup_path'] + '/database/' + fileName
        public.ExecShell("/opt/slemp/server/mysql/bin/mysqldump --opt --default-character-set=utf8 " + name + " | gzip > " + backupName)
        if not os.path.exists(backupName): return public.returnMsg(False,'Backup failed!');

        mycnf = public.readFile('/etc/my.cnf');
        mycnf = mycnf.replace(subStr,sea)
        if len(mycnf) > 100:
            public.writeFile('/etc/my.cnf',mycnf);

        sql = public.M('backup')
        addTime = time.strftime('%Y-%m-%d %X',time.localtime())
        sql.add('type,name,pid,filename,size,addtime',(1,fileName,id,backupName,0,addTime))
        public.WriteLog("Database management", "Backup database [" + name + "] success!")
        return public.returnMsg(True, 'Backup success!')
        #except Exception,ex:
            #public.WriteLog("Database management", "Backup database [" + name + "] failure => "  +  str(ex))
            #return public.returnMsg(False,'Backup failed!')

    def DelBackup(self,get):
        try:
            id = get.id
            where = "id=?"
            filename = public.M('backup').where(where,(id,)).getField('filename')
            if os.path.exists(filename): os.remove(filename)

            public.M('backup').where(where,(id,)).delete()
            public.WriteLog("Database management", "Delete backup file [" + filename + "] success!")
            return public.returnMsg(True, 'Delete backup file successfully!');
        except Exception,ex:
            public.WriteLog("Database management", "Delete backup file [" + filename + "] failure => "  +  str(ex))
            return public.returnMsg(False,'Failed to delete backup file!')

    def InputSql(self,get):
        try:
            name = get['name']
            file = get['file']
            root = web.ctx.session.config['mysql_root']
            tmp = file.split('.')
            exts = ['sql','gz','zip']
            ext = tmp[len(tmp) -1]
            if ext not in exts:
                return public.returnMsg(False, 'Please select sql, gz, zip file format!')

            if ext != 'sql':
                tmp = file.split('/')
                tmpFile = tmp[len(tmp)-1]
                tmpFile = tmpFile.replace('.sql.' + ext, '.sql')
                tmpFile = tmpFile.replace('.' + ext, '.sql')
                tmpFile = tmpFile.replace('tar.', '')
                backupPath = web.ctx.session.config['backup_path'] + '/database'

                if ext == 'zip':
                    public.ExecShell("cd "  +  backupPath  +  " && unzip " +  file)
                else:
                    public.ExecShell("cd "  +  backupPath  +  " && tar zxf " +  file)
                    if not os.path.exists(backupPath  +  "/"  +  tmpFile): public.ExecShell("cd "  +  backupPath  +  " && gunzip -q " +  file)

                if not os.path.exists(backupPath + '/' + tmpFile) or tmpFile == '': return public.returnMsg(False, '文件[' + tmpFile + ']不存在!')
                public.ExecShell("cd "  +  backupPath  +  " && "  +  web.ctx.session.setupPath + "/mysql/bin/mysql -uroot -p" + root + " --default-character-set=utf-8 " + name + " < " + tmpFile + " && rm -f " +  tmpFile)
            else:
                public.ExecShell(web.ctx.session.setupPath + "/mysql/bin/mysql -uroot -p" + root + " " + name + " < " +  file)

            public.WriteLog("Database management", "Import database [" + name + "] success!")
            return public.returnMsg(True, 'Import database successfully!');
        except Exception,ex:
            public.WriteLog("Database management", "Import database [" + name + "] failure => "  +  str(ex))
            return public.returnMsg(False,'Importing database failed!')

    def SyncToDatabases(self,get):
        type = int(get['type'])
        n = 0
        sql = public.M('databases')
        if type == 0:
            data = sql.field('id,name,username,password,accept').select()
            for value in data:
                result = self.ToDataBase(value)
                if result == 1: n +=1

        else:
            data = get.data
            for value in data:
                find = sql.where("id=?",(value,)).field('id,name,username,password,accept').find()
                result = self.ToDataBase(find)
                if result == 1: n +=1

        return public.returnMsg(True,"This time is synchronized:" + str(n) + " database")


    def ToDataBase(self,find):
        if len(find['password']) < 3 :
            find['username'] = find['name']
            find['password'] = public.md5(str(time.time()) + find['name'])[0:10]
            public.M('databases').where("id=?",(find['id'],)).save('password,username',(find['password'],find['username']))

        result = mysql.mysql().execute("create database " + find['name'])
        if "using password:" in str(result): return -1
        if "Connection refused" in str(result): return -1
        mysql.mysql().execute("drop user '" + find['username'] + "'@'localhost'")
        mysql.mysql().execute("drop user '" + find['username'] + "'@'" + find['accept'] + "'")
        password = find['password']
        if find['password']!="" and len(find['password']) > 20:
            password = find['password']

        mysql.mysql().execute("grant all privileges on " + find['name'] + ".* to '" + find['username'] + "'@'localhost' identified by '" + password + "'")
        mysql.mysql().execute("grant all privileges on " + find['name'] + ".* to '" + find['username'] + "'@'" + find['accept'] + "' identified by '" + password + "'")
        mysql.mysql().execute("flush privileges")
        return 1


    def SyncGetDatabases(self,get):
        data = mysql.mysql().query("show databases")
        isError = self.IsSqlError(data)
        if isError != None: return isError
        users = mysql.mysql().query("select User,Host from mysql.user where User!='root' AND Host!='localhost' AND Host!=''")
        sql = public.M('databases')
        nameArr = ['information_schema','performance_schema','mysql']
        n = 0
        for  value in data:
            b = False
            for key in nameArr:
                if value[0] == key:
                    b = True
                    break
            if b:continue
            if sql.where("name=?",(value[0],)).count(): continue
            host = '127.0.0.1'
            for user in users:
                if value[0] == user[0]:
                    host = user[1]
                    break

            ps = 'Fill in the note'
            if value[0] == 'test':
                    ps = 'Test database'
            addTime = time.strftime('%Y-%m-%d %X',time.localtime())
            if sql.table('databases').add('name,username,password,accept,ps,addtime',(value[0],value[0],'',host,ps,addTime)): n +=1

        return public.returnMsg(True,'This time from the server' + str(n) + ' database!')


    def GetDatabaseAccess(self,get):
        name = get['name']
        users = mysql.mysql().query("select User,Host from mysql.user where User='" + name + "' AND Host!='localhost'")
        isError = self.IsSqlError(users)
        if isError != None: return isError
        if len(users)<1:
            return public.returnMsg(True,['',''])

        return public.returnMsg(True,users[0])

    def SetDatabaseAccess(self,get):
        try:
            name = get['name']
            access = get['access']
            #if access != '%' and filter_var(access, FILTER_VALIDATE_IP) == False: return public.returnMsg(False, 'The permission format is illegal')
            password = public.M('databases').where("name=?",(name,)).getField('password')
            mysql.mysql().execute("delete from mysql.user where User='" + name + "' AND Host!='localhost'")
            mysql.mysql().execute("grant all privileges on " + name + ".* to '" + name + "'@'" + access + "' identified by '" + password + "'")
            mysql.mysql().execute("flush privileges")
            return public.returnMsg(True, 'Successful setup!')
        except Exception,ex:
            public.WriteLog("Database management", "Set database permissions [" + name + "] failure => "  +  str(ex))
            return public.returnMsg(False,'Setting database permissions failed!')


    def GetMySQLInfo(self,get):
        data = {}
        try:
            public.CheckMyCnf();
            myfile = '/etc/my.cnf';
            mycnf = public.readFile(myfile);
            rep = "datadir\s*=\s*(.+)\n"
            data['datadir'] = re.search(rep,mycnf).groups()[0];
            rep = "port\s*=\s*([0-9]+)\s*\n"
            data['port'] = re.search(rep,mycnf).groups()[0];
        except:
            data['datadir'] = '/opt/slemp/server/data';
            data['port'] = '3306';
        return data;

    def SetDataDir(self,get):
        if get.datadir[-1] == '/': get.datadir = get.datadir[0:-1];
        if os.path.exists(get.datadir): os.system('mkdir -p ' + get.datadir);
        mysqlInfo = self.GetMySQLInfo(get);
        if mysqlInfo['datadir'] == get.datadir: return public.returnMsg(False,'The same as the current storage directory, the file cannot be migrated!');

        os.system('/etc/init.d/mysqld stop');
        os.system('\cp -a -r ' + mysqlInfo['datadir'] + '/* ' + get.datadir + '/');
        os.system('chown -R mysql.mysql ' + get.datadir);
        os.system('chmod -R 755 ' + get.datadir);
        os.system('rm -f ' + get.datadir + '/*.pid');
        os.system('rm -f ' + get.datadir + '/*.err');

        public.CheckMyCnf();
        myfile = '/etc/my.cnf';
        mycnf = public.readFile(myfile);
        public.writeFile('/etc/my_backup.cnf',mycnf);
        mycnf = mycnf.replace(mysqlInfo['datadir'],get.datadir);
        public.writeFile(myfile,mycnf);
        os.system('/etc/init.d/mysqld start');
        result = public.ExecShell('/etc/init.d/mysqld status');
        if result[0].find('SUCCESS') != -1:
            public.writeFile('data/datadir.pl',get.datadir);
            return public.returnMsg(True,'Storage directory migration succeeded!');
        else:
            os.system('pkill -9 mysqld');
            public.writeFile(myfile,public.readFile('/etc/my_backup.cnf'));
            os.system('/etc/init.d/mysqld start');
            return public.returnMsg(False,'File migration failed!');

    def SetMySQLPort(self,get):
        myfile = '/etc/my.cnf';
        mycnf = public.readFile(myfile);
        rep = "port\s*=\s*([0-9]+)\s*\n"
        mycnf = re.sub(rep,'port = ' + get.port + '\n',mycnf);
        public.writeFile(myfile,mycnf);
        os.system('/etc/init.d/mysqld restart');
        return public.returnMsg(True,'Successfully modified!');
