#ifndef incl_PHP_INTL_UCHAR_H
#define incl_PHP_INTL_UCHAR_H

#include "php.h"

int php_uchar_minit(INIT_FUNC_ARGS);

#endif // incl_PHP_INTL_UCHAR_H
